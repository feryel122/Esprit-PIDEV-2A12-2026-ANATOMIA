<?php
// Migration pour une base DÉJÀ installée (sans perdre vos données) :  php database/add_availability.php
// Crée la table doctor_schedules et donne un emploi du temps par défaut aux médecins qui n'en ont pas
// (lundi–vendredi 8h–12h / 14h–18h, samedi 8h–12h). Chaque médecin peut ensuite le modifier dans le back office.
require __DIR__ . '/../app/Models/Database.php';
Database::pdo()->exec("CREATE TABLE IF NOT EXISTS doctor_schedules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  doctor_id INT NOT NULL,
  weekday TINYINT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  KEY idx_schedule_doctor_day (doctor_id, weekday),
  FOREIGN KEY (doctor_id) REFERENCES doctors(user_id) ON DELETE CASCADE
) ENGINE=InnoDB");

$n = 0;
foreach (Database::all('SELECT user_id FROM doctors') as $d) {
    if (Database::one('SELECT id FROM doctor_schedules WHERE doctor_id=? LIMIT 1', [$d['user_id']])) continue;
    foreach ([1, 2, 3, 4, 5, 6] as $day) {
        $ranges = $day < 6 ? [['08:00', '12:00'], ['14:00', '18:00']] : [['08:00', '12:00']];
        foreach ($ranges as [$from, $to])
            Database::insert('INSERT INTO doctor_schedules(doctor_id,weekday,start_time,end_time) VALUES(?,?,?,?)', [$d['user_id'], $day, "$from:00", "$to:00"]);
    }
    $n++;
}
echo "Table doctor_schedules prête. Emploi du temps par défaut créé pour $n médecin(s).\n";
