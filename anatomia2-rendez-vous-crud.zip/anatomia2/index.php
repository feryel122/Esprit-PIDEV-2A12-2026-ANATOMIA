<?php
// Contrôleur frontal : index.php?page=<clé>  (les clés sont déclarées dans app/routes.php)
declare(strict_types=1);
session_start();
$app = __DIR__ . '/app';
require "$app/helpers.php";
foreach (glob("$app/Models/*.php") as $m) require_once $m;
require "$app/Controllers/Controller.php";

$routes = require "$app/routes.php";
$page = $_GET['page'] ?? 'body';
if (!isset($routes[$page])) { http_response_code(404); exit('Page introuvable.'); }

[$class, $method] = $routes[$page];
require "$app/Controllers/$class.php";
(new $class())->$method();
