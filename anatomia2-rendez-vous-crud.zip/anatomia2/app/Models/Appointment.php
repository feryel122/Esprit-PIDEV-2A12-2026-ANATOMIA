<?php
class Appointment {
    // LEFT JOIN : une proposition ouverte n'a pas encore de médecin (doctor_id NULL)
    private const SELECT = 'SELECT a.*, p.name AS patient_name, p.email AS patient_email, p.phone AS patient_phone,
            d.name AS doctor_name, COALESCE(s.name, rs.name) AS specialty, b.name AS body_part
        FROM appointments a
        JOIN users p ON p.id=a.patient_id
        LEFT JOIN users d ON d.id=a.doctor_id
        LEFT JOIN doctors dd ON dd.user_id=a.doctor_id
        LEFT JOIN specialties s ON s.id=dd.specialty_id
        LEFT JOIN specialties rs ON rs.id=a.specialty_id
        LEFT JOIN body_parts b ON b.id=a.body_part_id ';

    public static function find(int $id): ?array { return Database::one(self::SELECT . 'WHERE a.id=?', [$id]); }
    public static function forPatient(int $uid): array { return Database::all(self::SELECT . 'WHERE a.patient_id=? ORDER BY a.scheduled_at DESC', [$uid]); }
    public static function forDoctor(int $uid, ?string $status = null): array {
        return $status
            ? Database::all(self::SELECT . 'WHERE a.doctor_id=? AND a.status=? ORDER BY a.scheduled_at', [$uid, $status])
            : Database::all(self::SELECT . 'WHERE a.doctor_id=? ORDER BY a.scheduled_at', [$uid]);
    }
    public static function all(?string $status = null): array {
        return $status
            ? Database::all(self::SELECT . 'WHERE a.status=? ORDER BY a.scheduled_at', [$status])
            : Database::all(self::SELECT . 'ORDER BY a.scheduled_at');
    }

    /** Propositions ouvertes des AUTRES utilisateurs (futures), éventuellement limitées à une spécialité. */
    public static function openProposals(int $exceptUserId, ?int $specialtyId = null): array {
        $sql = self::SELECT . "WHERE a.status='open' AND a.doctor_id IS NULL AND a.scheduled_at >= NOW() AND a.patient_id<>?";
        $p = [$exceptUserId];
        if ($specialtyId) { $sql .= ' AND a.specialty_id=?'; $p[] = $specialtyId; }
        return Database::all($sql . ' ORDER BY a.scheduled_at', $p);
    }
    public static function openCount(int $exceptUserId, ?int $specialtyId = null): int {
        $sql = "SELECT COUNT(*) n FROM appointments WHERE status='open' AND doctor_id IS NULL AND scheduled_at >= NOW() AND patient_id<>?";
        $p = [$exceptUserId];
        if ($specialtyId) { $sql .= ' AND specialty_id=?'; $p[] = $specialtyId; }
        return (int)(Database::one($sql, $p)['n'] ?? 0);
    }

    /**
     * Règle métier : un médecin ne peut pas avoir deux rendez-vous en même temps.
     * Un rendez-vous occupe un créneau de Availability::SLOT minutes : tout chevauchement est refusé
     * (pas seulement la même heure exacte). $exceptId = rendez-vous en cours de modification.
     */
    public static function isFree(int $doctorId, string $dt, ?int $exceptId = null): bool {
        $slot = Availability::SLOT * 60; $t = strtotime($dt);
        return !Database::one("SELECT id FROM appointments WHERE doctor_id=? AND status<>'cancelled' AND id<>?
            AND scheduled_at > ? AND scheduled_at < ?",
            [$doctorId, $exceptId ?? 0, date('Y-m-d H:i:s', $t - $slot), date('Y-m-d H:i:s', $t + $slot)]);
    }
    /** L'heure tombe-t-elle sur un début de créneau (08:00, 08:30…) ? */
    public static function isAligned(int $ts): bool { return (int)date('i', $ts) % Availability::SLOT === 0; }
    /** Contrôles communs d'un créneau chez un médecin : il consulte à cette heure + il est libre. Renvoie les erreurs. */
    public static function slotErrors(int $doctorId, int $ts, ?int $exceptId = null): array {
        $errors = [];
        if (!Availability::isWorking($doctorId, $ts))
            $errors[] = 'Ce médecin ne consulte pas à cette date/heure : choisissez un créneau dans ses disponibilités.';
        elseif (!self::isFree($doctorId, date('Y-m-d H:i:00', $ts), $exceptId))
            $errors[] = 'Ce créneau est déjà pris pour ce médecin, choisissez une autre heure.';
        return $errors;
    }
    public static function create(int $patient, int $doctor, ?int $bodyPart, string $dt, string $reason): int {
        Database::run("DELETE FROM appointments WHERE doctor_id=? AND scheduled_at=? AND status='cancelled'", [$doctor, $dt]);
        return Database::insert('INSERT INTO appointments(patient_id,doctor_id,body_part_id,scheduled_at,reason) VALUES(?,?,?,?,?)',
            [$patient, $doctor, $bodyPart, $dt, $reason]);
    }
    /** Proposition ouverte : pas de médecin choisi, on indique seulement la spécialité. */
    public static function createOpen(int $patient, int $specialty, ?int $bodyPart, string $dt, string $reason): int {
        return Database::insert("INSERT INTO appointments(patient_id,doctor_id,specialty_id,body_part_id,scheduled_at,reason,status) VALUES(?,NULL,?,?,?,?,'open')",
            [$patient, $specialty, $bodyPart, $dt, $reason]);
    }
    /** Un médecin prend une proposition ouverte. UPDATE conditionnel : un seul médecin peut la prendre. */
    public static function claim(int $id, int $doctorId): bool {
        return Database::run("UPDATE appointments SET doctor_id=?, status='confirmed' WHERE id=? AND doctor_id IS NULL AND status='open'", [$doctorId, $id]) === 1;
    }
    /** Le patient reporte / corrige son rendez-vous (date + motif). */
    public static function reschedule(int $id, ?int $doctor, string $dt, string $reason): void {
        if ($doctor) Database::run("DELETE FROM appointments WHERE doctor_id=? AND scheduled_at=? AND status='cancelled' AND id<>?", [$doctor, $dt, $id]);
        Database::run('UPDATE appointments SET scheduled_at=?, reason=? WHERE id=?', [$dt, $reason, $id]);
    }
    /** Back office : création (id null) ou modification complète d'un rendez-vous. */
    public static function save(?int $id, array $d): int {
        if ($d['doctor_id']) Database::run("DELETE FROM appointments WHERE doctor_id=? AND scheduled_at=? AND status='cancelled' AND id<>?",
            [$d['doctor_id'], $d['scheduled_at'], $id ?? 0]);
        $p = [$d['patient_id'], $d['doctor_id'], $d['specialty_id'], $d['body_part_id'], $d['scheduled_at'], $d['reason'], $d['status']];
        if ($id) { Database::run('UPDATE appointments SET patient_id=?,doctor_id=?,specialty_id=?,body_part_id=?,scheduled_at=?,reason=?,status=? WHERE id=?', [...$p, $id]); return $id; }
        return Database::insert('INSERT INTO appointments(patient_id,doctor_id,specialty_id,body_part_id,scheduled_at,reason,status) VALUES(?,?,?,?,?,?,?)', $p);
    }
    public static function delete(int $id): void { Database::run('DELETE FROM appointments WHERE id=?', [$id]); }
    public static function setStatus(int $id, string $status): void {
        Database::run('UPDATE appointments SET status=? WHERE id=?', [$status, $id]);
    }
    public static function counts(?int $doctorId = null): array {
        $sql = 'SELECT status, COUNT(*) n FROM appointments' . ($doctorId ? ' WHERE doctor_id=?' : '') . ' GROUP BY status';
        $out = ['open' => 0, 'pending' => 0, 'confirmed' => 0, 'cancelled' => 0, 'done' => 0];
        foreach (Database::all($sql, $doctorId ? [$doctorId] : []) as $r) $out[$r['status']] = (int)$r['n'];
        return $out;
    }
}
