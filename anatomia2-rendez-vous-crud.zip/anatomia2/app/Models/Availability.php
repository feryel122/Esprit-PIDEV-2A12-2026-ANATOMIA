<?php
/**
 * Disponibilités des médecins = emploi du temps hebdomadaire (table doctor_schedules)
 * croisé avec les rendez-vous déjà pris (table appointments).
 */
class Availability {
    public const DAYS  = [1 => 'Lundi', 2 => 'Mardi', 3 => 'Mercredi', 4 => 'Jeudi', 5 => 'Vendredi', 6 => 'Samedi'];
    public const SHORT = [1 => 'Lun', 2 => 'Mar', 3 => 'Mer', 4 => 'Jeu', 5 => 'Ven', 6 => 'Sam'];
    public const SLOT  = 30;        // durée d'un créneau, en minutes
    public const OPEN  = '08:00';   // mêmes bornes que AppointmentController::checkDate()
    public const CLOSE = '18:00';

    // ---------- emploi du temps (plages horaires) ----------
    private static function clean(array $r): array {
        $r['start_time'] = substr($r['start_time'], 0, 5);
        $r['end_time']   = substr($r['end_time'], 0, 5);
        return $r;
    }
    /** @return array<int, array<int, array>> [jour => [plages]] pour un médecin */
    public static function byDay(int $doctorId): array {
        $out = [];
        foreach (Database::all('SELECT * FROM doctor_schedules WHERE doctor_id=? ORDER BY weekday, start_time', [$doctorId]) as $r)
            $out[(int)$r['weekday']][] = self::clean($r);
        return $out;
    }
    /** @return array<int, array<int, array<int, array>>> [médecin => [jour => [plages]]] */
    public static function allByDoctor(): array {
        $out = [];
        foreach (Database::all('SELECT * FROM doctor_schedules ORDER BY doctor_id, weekday, start_time') as $r)
            $out[(int)$r['doctor_id']][(int)$r['weekday']][] = self::clean($r);
        return $out;
    }
    public static function find(int $id): ?array {
        return Database::one('SELECT * FROM doctor_schedules WHERE id=?', [$id]);
    }
    public static function overlaps(int $doctorId, int $day, string $from, string $to): bool {
        return (bool)Database::one('SELECT id FROM doctor_schedules WHERE doctor_id=? AND weekday=? AND start_time < ? AND end_time > ?',
            [$doctorId, $day, $to . ':00', $from . ':00']);
    }
    public static function add(int $doctorId, int $day, string $from, string $to): int {
        return Database::insert('INSERT INTO doctor_schedules(doctor_id,weekday,start_time,end_time) VALUES(?,?,?,?)',
            [$doctorId, $day, $from . ':00', $to . ':00']);
    }
    public static function delete(int $id): void {
        Database::run('DELETE FROM doctor_schedules WHERE id=?', [$id]);
    }
    /** Vérifie une plage saisie : renvoie la liste des erreurs. */
    public static function validate(int $day, string $from, string $to): array {
        $errors = [];
        $okTime = fn($t) => (bool)preg_match('/^(0\d|1\d):(00|30)$/', $t) && $t >= self::OPEN && $t <= self::CLOSE;
        if (!isset(self::DAYS[$day])) $errors[] = 'Choisissez un jour du lundi au samedi.';
        if (!$okTime($from) || !$okTime($to)) $errors[] = 'Les horaires doivent être entre ' . self::OPEN . ' et ' . self::CLOSE . ', par pas de 30 minutes.';
        elseif ($from >= $to) $errors[] = 'L\'heure de fin doit être après l\'heure de début.';
        return $errors;
    }
    /** "08:00–12:00, 14:00–18:00" (ou « Repos » si aucun horaire ce jour-là). */
    public static function dayText(array $ranges): string {
        return $ranges ? implode(', ', array_map(fn($r) => $r['start_time'] . '–' . $r['end_time'], $ranges)) : 'Repos';
    }
    /** Le médecin consulte-t-il à cet instant ? (un créneau entier doit tenir dans une plage) */
    public static function isWorking(int $doctorId, int $ts): bool {
        $row = Database::one('SELECT id FROM doctor_schedules WHERE doctor_id=? AND weekday=? AND start_time <= ? AND end_time >= ?',
            [$doctorId, (int)date('N', $ts), date('H:i:00', $ts), date('H:i:00', $ts + self::SLOT * 60)]);
        return (bool)$row;
    }

    // ---------- créneaux (emploi du temps + rendez-vous) ----------
    /** Lundi de la semaine contenant $date (Y-m-d), borné entre cette semaine et +12 semaines. */
    public static function mondayOf(?string $date): DateTimeImmutable {
        $min = new DateTimeImmutable('monday this week 00:00');
        $d = $date ? DateTimeImmutable::createFromFormat('!Y-m-d', $date) : false;
        $d = $d ? $d->modify('monday this week') : $min;
        return max($min, min($d, $min->modify('+12 weeks')));
    }

    /**
     * Grille d'une semaine : ['days' => [[n, label, date, slots[HH:MM => [status, ts, patient]]]], 'times' => [HH:MM...], 'outside' => [...]]
     * status : free (libre) · busy (occupé) · past (trop proche / passé).
     * $withPatients (espace médecin) : ajoute le nom du patient et liste les rendez-vous hors horaires.
     */
    public static function weekGrid(int $doctorId, DateTimeImmutable $monday, bool $withPatients = false): array {
        $ranges = self::byDay($doctorId);
        $taken = Database::all("SELECT a.scheduled_at, p.name AS patient FROM appointments a JOIN users p ON p.id=a.patient_id
            WHERE a.doctor_id=? AND a.status<>'cancelled' AND a.scheduled_at>=? AND a.scheduled_at<? ORDER BY a.scheduled_at",
            [$doctorId, $monday->format('Y-m-d 00:00:00'), $monday->modify('+7 days')->format('Y-m-d 00:00:00')]);
        foreach ($taken as &$t) { $t['ts'] = strtotime($t['scheduled_at']); $t['used'] = false; } unset($t);

        $days = []; $times = []; $step = self::SLOT * 60;
        foreach (self::DAYS as $n => $label) {
            $date = $monday->modify('+' . ($n - 1) . ' days');
            $slots = [];
            foreach ($ranges[$n] ?? [] as $r) {
                $end = strtotime($date->format('Y-m-d ') . $r['end_time']);
                for ($ts = strtotime($date->format('Y-m-d ') . $r['start_time']); $ts + $step <= $end; $ts += $step) {
                    $status = 'free'; $patient = null;
                    foreach ($taken as &$t) if ($t['ts'] >= $ts && $t['ts'] < $ts + $step) { $status = 'busy'; $patient = $t['patient']; $t['used'] = true; break; }
                    unset($t);
                    if ($status === 'free' && $ts < time() + 3600) $status = 'past';
                    $slots[date('H:i', $ts)] = ['status' => $status, 'ts' => $ts, 'patient' => $withPatients ? $patient : null];
                    $times[date('H:i', $ts)] = true;
                }
            }
            $days[] = ['n' => $n, 'label' => $label, 'date' => $date, 'slots' => $slots];
        }
        ksort($times);
        $outside = $withPatients ? array_values(array_filter($taken, fn($t) => !$t['used'])) : [];
        return ['days' => $days, 'times' => array_keys($times), 'outside' => $outside];
    }

    /** Les prochains créneaux libres (timestamps) d'un médecin, sur les 4 prochaines semaines. */
    public static function nextFree(int $doctorId, int $limit = 3): array {
        $free = []; $monday = new DateTimeImmutable('monday this week 00:00');
        for ($w = 0; $w < 4 && count($free) < $limit; $w++) {
            foreach (self::weekGrid($doctorId, $monday->modify("+$w weeks"))['days'] as $d)
                foreach ($d['slots'] as $s) if ($s['status'] === 'free') $free[] = $s['ts'];
        }
        sort($free);
        return array_slice($free, 0, $limit);
    }
    /** Nombre de rendez-vous à venir (hors annulés) d'un médecin : indicateur de charge. */
    public static function upcomingCount(int $doctorId): int {
        return (int)(Database::one("SELECT COUNT(*) n FROM appointments WHERE doctor_id=? AND status IN ('pending','confirmed') AND scheduled_at>=NOW()", [$doctorId])['n'] ?? 0);
    }
}
