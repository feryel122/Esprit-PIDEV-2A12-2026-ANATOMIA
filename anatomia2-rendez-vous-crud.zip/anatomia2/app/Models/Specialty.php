<?php
class Specialty {
    public static function all(): array { return Database::all('SELECT id,name FROM specialties ORDER BY name'); }
    public static function find(int $id): ?array { return Database::one('SELECT id,name FROM specialties WHERE id=?', [$id]); }
}
