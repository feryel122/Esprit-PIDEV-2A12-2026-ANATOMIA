<?php
class Auth {
    public static function user(): ?array {
        if (empty($_SESSION['uid'])) return null;
        static $u = null;
        return $u ??= User::find((int)$_SESSION['uid']);
    }
    public static function login(array $u): void {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$u['id'];
    }
    public static function logout(): void { $_SESSION = []; session_destroy(); }
    public static function is(string ...$roles): bool {
        $u = self::user(); return $u && in_array($u['role'], $roles, true);
    }
}
