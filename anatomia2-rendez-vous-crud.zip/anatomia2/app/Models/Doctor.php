<?php
/** CRUD des médecins : un médecin = une ligne `users` (role='doctor') + son profil 1-1 dans `doctors`. */
class Doctor {
    public static function all(): array {
        return Database::all("SELECT u.id,u.name,u.email,u.phone,d.city,d.specialty_id,s.name AS specialty,
                (SELECT COUNT(*) FROM appointments a WHERE a.doctor_id=u.id AND a.status IN ('pending','confirmed') AND a.scheduled_at>=NOW()) AS upcoming
            FROM doctors d JOIN users u ON u.id=d.user_id JOIN specialties s ON s.id=d.specialty_id ORDER BY s.name, u.name");
    }
    public static function find(int $id): ?array {
        return Database::one('SELECT u.id,u.name,u.email,u.phone,d.city,d.bio,d.photo,d.specialty_id
            FROM doctors d JOIN users u ON u.id=d.user_id WHERE u.id=?', [$id]);
    }
    /** Création (id null) ou modification ; mot de passe laissé vide = inchangé. */
    public static function save(?int $id, array $d): int {
        $pdo = Database::pdo(); $pdo->beginTransaction();
        try {
            if ($id) {
                Database::run('UPDATE users SET name=?,email=?,phone=? WHERE id=?', [$d['name'], $d['email'], $d['phone'] ?: null, $id]);
                if ($d['password'] !== '') Database::run('UPDATE users SET password=? WHERE id=?', [password_hash($d['password'], PASSWORD_DEFAULT), $id]);
                Database::run('UPDATE doctors SET specialty_id=?,city=?,bio=? WHERE user_id=?', [$d['specialty_id'], $d['city'], $d['bio'] ?: null, $id]);
            } else {
                $id = Database::insert("INSERT INTO users(name,email,password,phone,role) VALUES(?,?,?,?,'doctor')",
                    [$d['name'], $d['email'], password_hash($d['password'], PASSWORD_DEFAULT), $d['phone'] ?: null]);
                Database::run('INSERT INTO doctors(user_id,specialty_id,city,bio) VALUES(?,?,?,?)', [$id, $d['specialty_id'], $d['city'], $d['bio'] ?: null]);
            }
            $pdo->commit();
        } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
        return $id;
    }
    public static function upcomingCount(int $id): int {
        return (int)(Database::one("SELECT COUNT(*) n FROM appointments WHERE doctor_id=? AND status IN ('pending','confirmed') AND scheduled_at>=NOW()", [$id])['n'] ?? 0);
    }
    public static function delete(int $id): void { Database::run("DELETE FROM users WHERE id=? AND role='doctor'", [$id]); }
}
