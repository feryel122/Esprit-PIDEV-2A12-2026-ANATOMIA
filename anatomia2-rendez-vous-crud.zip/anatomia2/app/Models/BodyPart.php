<?php
class BodyPart {
    public static function all(): array { return Database::all('SELECT * FROM body_parts ORDER BY id'); }
    public static function find(int $id): ?array { return Database::one('SELECT * FROM body_parts WHERE id=?', [$id]); }
    public static function findBySlug(string $s): ?array { return Database::one('SELECT * FROM body_parts WHERE slug=?', [$s]); }
    public static function allSpecialties(): array { return Database::all('SELECT * FROM specialties ORDER BY name'); }
    public static function specialtyIds(int $id): array {
        return array_column(Database::all('SELECT specialty_id FROM body_part_specialty WHERE body_part_id=?', [$id]), 'specialty_id');
    }
    public static function save(?int $id, array $d, array $specialties): int {
        $p = [$d['slug'], $d['name'], $d['summary'], $d['description'], $d['common_issues'], $d['prevention']];
        if ($id) { Database::run('UPDATE body_parts SET slug=?,name=?,summary=?,description=?,common_issues=?,prevention=? WHERE id=?', [...$p, $id]); }
        else     { $id = Database::insert('INSERT INTO body_parts(slug,name,summary,description,common_issues,prevention) VALUES(?,?,?,?,?,?)', $p); }
        Database::run('DELETE FROM body_part_specialty WHERE body_part_id=?', [$id]);
        foreach ($specialties as $s) Database::run('INSERT INTO body_part_specialty VALUES(?,?)', [$id, (int)$s]);
        return $id;
    }
    public static function delete(int $id): void { Database::run('DELETE FROM body_parts WHERE id=?', [$id]); }
}
