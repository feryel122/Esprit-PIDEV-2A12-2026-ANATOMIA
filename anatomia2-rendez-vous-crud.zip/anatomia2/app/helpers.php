<?php
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function url(string $page = 'body', array $params = []): string {
    return 'index.php?' . http_build_query(['page' => $page] + $params);
}
function front_asset(string $p): string { return 'app/Views/assets/front/' . ltrim($p, '/'); }
function back_asset(string $p): string  { return 'app/Views/assets/back/' . ltrim($p, '/'); }
/** Renvoie 'active' si $page correspond à la page courante (ou commence par $page avec $prefix = true). */
function navActive(string $page, string $currentPage, bool $prefix = false): string {
    return ($prefix ? str_starts_with($currentPage, $page) : $page === $currentPage) ? 'active' : '';
}

function flash(?string $msg = null, string $type = 'success') {
    if ($msg !== null) { $_SESSION['flash'] = ['msg' => $msg, 'type' => $type]; return null; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}
function csrf_token(): string {
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(16));
}
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
function status_label(string $s): array {
    return [
        'open'      => ['Proposition ouverte', 'info'],
        'pending'   => ['En attente', 'warning'],
        'confirmed' => ['Confirmé',   'success'],
        'cancelled' => ['Annulé',     'danger'],
        'done'      => ['Terminé',    'secondary'],
    ][$s] ?? [$s, 'light'];
}

/** Coupe proprement une chaîne UTF-8 (sans dépendre de mbstring). */
function str_limit(string $s, int $max): string {
    return preg_match('/^.{0,' . $max . '}/us', $s, $m) ? $m[0] : substr($s, 0, $max);
}
