<?php
class AdminDashboardController extends Controller {
    public function index(): void {
        $me = $this->requireRole('doctor', 'admin');
        $isDoctor = $me['role'] === 'doctor';
        $counts = Appointment::counts($isDoctor ? (int)$me['id'] : null);
        $upcoming = array_slice(array_filter(
            $isDoctor ? Appointment::forDoctor((int)$me['id']) : Appointment::all(),
            fn($a) => in_array($a['status'], ['pending', 'confirmed'], true) && strtotime($a['scheduled_at']) >= time()
        ), 0, 5);
        $nbParts = count(BodyPart::all());
        $this->page = 'admin-dashboard'; $this->title = $isDoctor ? 'Espace médecin' : 'Tableau de bord';
        $this->render('dashboard', compact('counts', 'upcoming', 'nbParts', 'isDoctor'), 'back');
    }
}
