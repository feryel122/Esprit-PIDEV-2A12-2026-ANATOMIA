<?php
class AuthController extends Controller {
    public function login(): void {
        $error = null;
        if ($this->isPost()) {
            $this->checkCsrf();
            $u = User::findByEmail(trim($_POST['email'] ?? ''));
            if ($u && password_verify($_POST['password'] ?? '', $u['password'])) {
                Auth::login($u);
                flash('Bienvenue ' . $u['name'] . ' !');
                $this->redirect(in_array($u['role'], ['doctor', 'admin'], true) ? 'admin-dashboard' : 'body');
            }
            $error = 'Email ou mot de passe incorrect.';
        }
        $this->page = 'login'; $this->title = 'Connexion';
        $this->render('front/auth/login', compact('error'));
    }
    public function register(): void {
        $errors = []; $old = $_POST;
        if ($this->isPost()) {
            $this->checkCsrf();
            $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? ''); $pass = $_POST['password'] ?? '';
            if ($name === '') $errors[] = 'Le nom est obligatoire.';
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email invalide.';
            elseif (User::findByEmail($email)) $errors[] = 'Cet email est déjà utilisé.';
            if (strlen($pass) < 6) $errors[] = 'Mot de passe : 6 caractères minimum.';
            if (!$errors) {
                $id = User::create($name, $email, $pass, trim($_POST['phone'] ?? ''));
                Auth::login(['id' => $id]);
                flash('Compte créé, bienvenue !');
                $this->redirect('body');
            }
        }
        $this->page = 'register'; $this->title = 'Inscription';
        $this->render('front/auth/register', compact('errors', 'old'));
    }
    public function logout(): void { Auth::logout(); session_start(); flash('Vous êtes déconnecté.'); $this->redirect('body'); }
}
