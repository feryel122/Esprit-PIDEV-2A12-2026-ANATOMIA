<?php
class AdminAppointmentsController extends Controller {
    /** Le médecin voit SES rendez-vous ; l'admin voit tous les rendez-vous du site. */
    public function index(): void {
        $me = $this->requireRole('doctor', 'admin');
        $status = $_GET['status'] ?? null;
        if (!in_array($status, ['open', 'pending', 'confirmed', 'cancelled', 'done'], true)) $status = null;
        $appointments = $me['role'] === 'doctor' ? Appointment::forDoctor((int)$me['id'], $status) : Appointment::all($status);
        $this->page = 'admin-appointments'; $this->title = $me['role'] === 'admin' ? 'Tous les rendez-vous du site' : 'Mes rendez-vous (patients)';
        $this->render('appointments/index', compact('appointments', 'status'), 'back');
    }
    public function status(): void {
        $me = $this->requireRole('doctor', 'admin');
        $this->checkCsrf();
        $a = Appointment::find((int)($_POST['id'] ?? 0));
        $new = $_POST['status'] ?? '';
        $allowed = ['confirmed', 'cancelled', 'done'];
        if ($a && !in_array($a['status'], ['open', 'cancelled'], true) && in_array($new, $allowed, true)
            && ($me['role'] === 'admin' || (int)$a['doctor_id'] === (int)$me['id'])) {
            Appointment::setStatus((int)$a['id'], $new);
            flash('Rendez-vous mis à jour.');
        }
        $this->redirect('admin-appointments');
    }

    /** Propositions ouvertes des autres utilisateurs : visibles par les médecins (et l'admin, en lecture). */
    public function proposals(): void {
        $me = $this->requireRole('doctor', 'admin');
        $doctor = $me['role'] === 'doctor' ? User::doctor((int)$me['id']) : null;
        $specialtyId = $doctor ? (int)$doctor['specialty_id'] : null;
        $scope = ($_GET['scope'] ?? 'mine') === 'all' || !$doctor ? 'all' : 'mine';
        $proposals = Appointment::openProposals((int)$me['id'], $scope === 'mine' ? $specialtyId : null);
        $this->page = 'admin-proposals'; $this->title = 'Propositions des utilisateurs';
        $this->render('appointments/proposals', compact('proposals', 'scope', 'doctor', 'specialtyId'), 'back');
    }
    public function claim(): void {
        $me = $this->requireRole('doctor');
        $this->checkCsrf();
        $doctor = User::doctor((int)$me['id']);
        $a = Appointment::find((int)($_POST['id'] ?? 0));
        if (!$a || $a['status'] !== 'open' || $a['doctor_id'] !== null) {
            flash('Cette proposition n\'est plus disponible.', 'warning');
        } elseif ((int)$a['patient_id'] === (int)$me['id']) {
            flash('Vous ne pouvez pas accepter votre propre proposition.', 'warning');
        } elseif ((int)$a['specialty_id'] !== (int)$doctor['specialty_id']) {
            flash('Cette proposition concerne une autre spécialité.', 'warning');
        } elseif (!Appointment::isFree((int)$me['id'], $a['scheduled_at'])) {
            flash('Vous avez déjà un rendez-vous à cette heure-là.', 'warning');
        } else {
            try {
                if (Appointment::claim((int)$a['id'], (int)$me['id'])) flash('Rendez-vous accepté : ' . $a['patient_name'] . ' est prévenu(e).');
                else flash('Un autre médecin vient de prendre cette proposition.', 'warning');
            } catch (PDOException $e) {
                flash('Ce créneau est déjà occupé dans votre agenda.', 'warning');
            }
        }
        $this->redirect('admin-proposals', ($_POST['scope'] ?? '') === 'all' ? ['scope' => 'all'] : []);
    }

    // ---------- CRUD complet des rendez-vous (admin) ----------
    public function create(): void {
        $this->requireRole('admin');
        $this->form(null, ['status' => 'pending'], []);
    }
    public function edit(): void {
        $this->requireRole('admin');
        $a = Appointment::find((int)($_GET['id'] ?? 0)) ?? exit('Introuvable.');
        $old = $a;
        $old['scheduled_at'] = date('Y-m-d\TH:i', strtotime($a['scheduled_at']));
        if (!$a['doctor_id']) $old['specialty_id'] = $a['specialty_id'];
        $this->form($a, $old, []);
    }
    public function save(): void {
        $this->requireRole('admin');
        if (!$this->isPost()) $this->redirect('admin-appointments');
        $this->checkCsrf();
        $id = (int)($_POST['id'] ?? 0) ?: null;
        $d = [
            'patient_id'   => (int)($_POST['patient_id'] ?? 0),
            'doctor_id'    => (int)($_POST['doctor_id'] ?? 0) ?: null,
            'specialty_id' => (int)($_POST['specialty_id'] ?? 0) ?: null,
            'body_part_id' => (int)($_POST['body_part_id'] ?? 0) ?: null,
            'reason'       => str_limit(trim($_POST['reason'] ?? ''), 255),
            'status'       => $_POST['status'] ?? 'pending',
        ];
        $errors = [];
        $ts = strtotime($_POST['scheduled_at'] ?? '');
        if (!User::find($d['patient_id'])) $errors[] = 'Choisissez un patient.';
        if (!$ts) $errors[] = 'Date et heure invalides.';
        elseif (!Appointment::isAligned($ts)) $errors[] = 'Les rendez-vous commencent toutes les 30 minutes (ex. 09:00, 09:30).';
        if ($d['reason'] === '') $errors[] = 'Indiquez le motif de la consultation.';
        if (!in_array($d['status'], ['open', 'pending', 'confirmed', 'cancelled', 'done'], true)) $errors[] = 'Statut invalide.';
        $d['scheduled_at'] = $ts ? date('Y-m-d H:i:00', $ts) : '';

        if ($d['doctor_id']) {
            if (!User::doctor($d['doctor_id'])) $errors[] = 'Médecin introuvable.';
            elseif ($d['doctor_id'] === $d['patient_id']) $errors[] = 'Un médecin ne peut pas prendre rendez-vous avec lui-même.';
            if ($d['status'] === 'open') $errors[] = 'Une proposition ouverte n\'a pas de médecin : retirez le médecin ou changez le statut.';
            // Règle métier : pas de chevauchement dans l'agenda du médecin (un rendez-vous annulé ne bloque rien)
            if (!$errors && $d['status'] !== 'cancelled') $errors = Appointment::slotErrors($d['doctor_id'], $ts, $id);
            $d['specialty_id'] = null;
        } else {
            if (!Specialty::find((int)$d['specialty_id'])) $errors[] = 'Sans médecin, indiquez la spécialité demandée.';
            if ($d['status'] !== 'open' && $d['status'] !== 'cancelled') $errors[] = 'Sans médecin, le rendez-vous est une proposition ouverte (ou annulé).';
        }
        if (!$errors) {
            try {
                Appointment::save($id, $d);
                flash('Rendez-vous enregistré.');
                $this->redirect('admin-appointments');
            } catch (PDOException $e) { $errors[] = 'Un autre rendez-vous occupe déjà ce créneau pour ce médecin.'; }
        }
        $this->form($id ? Appointment::find($id) : null, $_POST, $errors);
    }
    public function delete(): void {
        $this->requireRole('admin');
        $this->checkCsrf();
        Appointment::delete((int)($_POST['id'] ?? 0));
        flash('Rendez-vous supprimé.');
        $this->redirect('admin-appointments');
    }
    private function form(?array $a, array $old, array $errors): void {
        $patients = User::all(); $doctors = User::doctors(); $specialties = Specialty::all(); $parts = BodyPart::all();
        $this->page = 'admin-appointments';
        $this->title = $a ? 'Modifier le rendez-vous #' . (int)$a['id'] : 'Nouveau rendez-vous';
        $this->render('appointments/form', compact('a', 'old', 'errors', 'patients', 'doctors', 'specialties', 'parts'), 'back');
    }
}
