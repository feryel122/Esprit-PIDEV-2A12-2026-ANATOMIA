<?php
class AdminBodyController extends Controller {
    public function index(): void {
        $this->requireRole('admin');
        $parts = BodyPart::all();
        $this->page = 'admin-body'; $this->title = 'Parties du corps';
        $this->render('body/index', compact('parts'), 'back');
    }
    public function create(): void {
        $this->requireRole('admin');
        $this->form(null, [], [], []);
    }
    public function edit(): void {
        $this->requireRole('admin');
        $p = BodyPart::find((int)($_GET['id'] ?? 0)) ?? exit('Introuvable.');
        $this->form($p, $p, BodyPart::specialtyIds((int)$p['id']), []);
    }
    public function save(): void {
        $this->requireRole('admin');
        if (!$this->isPost()) $this->redirect('admin-body');
        $this->checkCsrf();
        $id = (int)($_POST['id'] ?? 0) ?: null;
        $d = [];
        foreach (['slug', 'name', 'summary', 'description', 'common_issues', 'prevention'] as $k) $d[$k] = trim($_POST[$k] ?? '');
        $d['slug'] = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $d['slug'] ?: $d['name']));
        $errors = [];
        if ($d['name'] === '' || $d['summary'] === '' || $d['description'] === '') $errors[] = 'Nom, résumé et description sont obligatoires.';
        $dup = Database::one('SELECT id FROM body_parts WHERE slug=? AND id<>?', [$d['slug'], $id ?? 0]);
        if ($dup) $errors[] = 'Ce slug existe déjà.';
        $sp = array_map('intval', $_POST['specialties'] ?? []);
        if ($errors) { $this->form($id ? ['id' => $id] + $d : null, $d, $sp, $errors); return; }
        BodyPart::save($id, $d, $sp);
        flash('Partie du corps enregistrée.');
        $this->redirect('admin-body');
    }
    public function delete(): void {
        $this->requireRole('admin');
        $this->checkCsrf();
        BodyPart::delete((int)($_POST['id'] ?? 0));
        flash('Partie du corps supprimée.');
        $this->redirect('admin-body');
    }
    private function form(?array $part, array $old, array $selected, array $errors): void {
        $specialties = BodyPart::allSpecialties();
        $this->page = 'admin-body'; $this->title = !empty($part['id']) ? 'Modifier : ' . ($part['name'] ?? '') : 'Nouvelle partie du corps';
        $this->render('body/form', compact('part', 'old', 'selected', 'errors', 'specialties'), 'back');
    }
}
