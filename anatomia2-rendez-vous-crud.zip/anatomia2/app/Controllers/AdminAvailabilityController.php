<?php
/** Back office : tableau « Disponibilités » — le médecin gère son emploi du temps, l'admin voit/gère tous les médecins. */
class AdminAvailabilityController extends Controller {

    public function index(): void {
        $me = $this->requireRole('doctor', 'admin');
        $isAdmin = $me['role'] === 'admin';
        $doctors = $isAdmin ? User::doctors() : [];
        $doctorId = $isAdmin ? (int)($_GET['doctor'] ?? ($doctors[0]['id'] ?? 0)) : (int)$me['id'];
        $doctor = User::doctor($doctorId);

        $overview = [];   // tableau récapitulatif (admin) : tous les médecins
        if ($isAdmin) {
            $schedules = Availability::allByDoctor();
            foreach ($doctors as $d) {
                $overview[] = $d + ['week' => $schedules[(int)$d['id']] ?? [],
                    'next' => Availability::nextFree((int)$d['id'], 1), 'upcoming' => Availability::upcomingCount((int)$d['id'])];
            }
        }
        $monday = Availability::mondayOf($_GET['week'] ?? null);
        $week = $doctor ? Availability::byDay($doctorId) : [];
        $grid = $doctor ? Availability::weekGrid($doctorId, $monday, true) : null;
        $this->page = 'admin-availability'; $this->title = $isAdmin ? 'Disponibilités des médecins' : 'Mes disponibilités';
        $this->render('availability/index', compact('isAdmin', 'overview', 'doctor', 'week', 'grid', 'monday'), 'back');
    }

    /** Médecin : toujours lui-même. Admin : le médecin passé en POST. */
    private function targetDoctorId(array $me): int {
        return $me['role'] === 'doctor' ? (int)$me['id'] : (int)($_POST['doctor_id'] ?? 0);
    }
    private function back(array $me, int $doctorId): never {
        $this->redirect('admin-availability', $me['role'] === 'admin' ? ['doctor' => $doctorId] : []);
    }

    public function add(): void {
        $me = $this->requireRole('doctor', 'admin');
        $this->checkCsrf();
        $doctorId = $this->targetDoctorId($me);
        if (!User::doctor($doctorId)) { flash('Médecin introuvable.', 'warning'); $this->redirect('admin-availability'); }
        $day = (int)($_POST['weekday'] ?? 0); $from = (string)($_POST['start_time'] ?? ''); $to = (string)($_POST['end_time'] ?? '');
        $errors = Availability::validate($day, $from, $to);
        if (!$errors && Availability::overlaps($doctorId, $day, $from, $to)) $errors[] = 'Cette plage chevauche un horaire déjà défini ce jour-là.';
        if ($errors) flash(implode(' ', $errors), 'warning');
        else { Availability::add($doctorId, $day, $from, $to); flash('Horaire ajouté : ' . Availability::DAYS[$day] . " {$from}–{$to}."); }
        $this->back($me, $doctorId);
    }

    public function delete(): void {
        $me = $this->requireRole('doctor', 'admin');
        $this->checkCsrf();
        $r = Availability::find((int)($_POST['id'] ?? 0));
        if ($r && ($me['role'] === 'admin' || (int)$r['doctor_id'] === (int)$me['id'])) {
            Availability::delete((int)$r['id']);
            flash('Horaire supprimé. Les rendez-vous déjà pris restent valables.');
            $this->back($me, (int)$r['doctor_id']);
        }
        $this->redirect('admin-availability');
    }
}
