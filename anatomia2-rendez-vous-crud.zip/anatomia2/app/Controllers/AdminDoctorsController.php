<?php
/** CRUD des médecins (admin uniquement). */
class AdminDoctorsController extends Controller {
    public function index(): void {
        $this->requireRole('admin');
        $doctors = Doctor::all();
        $this->page = 'admin-doctors'; $this->title = 'Médecins';
        $this->render('doctors/index', compact('doctors'), 'back');
    }
    public function create(): void {
        $this->requireRole('admin');
        $this->form(null, [], []);
    }
    public function edit(): void {
        $this->requireRole('admin');
        $d = Doctor::find((int)($_GET['id'] ?? 0)) ?? exit('Introuvable.');
        $this->form($d, $d, []);
    }
    public function save(): void {
        $this->requireRole('admin');
        if (!$this->isPost()) $this->redirect('admin-doctors');
        $this->checkCsrf();
        $id = (int)($_POST['id'] ?? 0) ?: null;
        $d = [];
        foreach (['name', 'email', 'phone', 'city', 'bio'] as $k) $d[$k] = trim($_POST[$k] ?? '');
        $d['password'] = $_POST['password'] ?? '';
        $d['specialty_id'] = (int)($_POST['specialty_id'] ?? 0);
        $errors = [];
        if ($id && !Doctor::find($id)) exit('Introuvable.');
        if ($d['name'] === '') $errors[] = 'Le nom est obligatoire.';
        if ($d['city'] === '') $errors[] = 'La ville est obligatoire.';
        if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Email invalide.';
        elseif (($u = User::findByEmail($d['email'])) && (int)$u['id'] !== (int)$id) $errors[] = 'Cet email est déjà utilisé.';
        if (!$id && strlen($d['password']) < 6) $errors[] = 'Mot de passe : 6 caractères minimum.';
        if ($id && $d['password'] !== '' && strlen($d['password']) < 6) $errors[] = 'Mot de passe : 6 caractères minimum (laisser vide pour ne pas le changer).';
        if (!Specialty::find($d['specialty_id'])) $errors[] = 'Choisissez une spécialité.';
        if ($errors) { $this->form($id ? ['id' => $id] : null, $d, $errors); return; }
        Doctor::save($id, $d);
        flash($id ? 'Médecin modifié.' : 'Médecin ajouté.');
        $this->redirect('admin-doctors');
    }
    public function delete(): void {
        $this->requireRole('admin');
        $this->checkCsrf();
        $id = (int)($_POST['id'] ?? 0);
        if (!Doctor::find($id)) flash('Médecin introuvable.', 'warning');
        elseif (Doctor::upcomingCount($id) > 0) flash('Ce médecin a des rendez-vous à venir : annulez-les avant de le supprimer.', 'warning');
        else { Doctor::delete($id); flash('Médecin supprimé.'); }
        $this->redirect('admin-doctors');
    }
    private function form(?array $doctor, array $old, array $errors): void {
        $specialties = Specialty::all();
        $this->page = 'admin-doctors';
        $this->title = $doctor ? 'Modifier le médecin' : 'Nouveau médecin';
        $this->render('doctors/form', compact('doctor', 'old', 'errors', 'specialties'), 'back');
    }
}
