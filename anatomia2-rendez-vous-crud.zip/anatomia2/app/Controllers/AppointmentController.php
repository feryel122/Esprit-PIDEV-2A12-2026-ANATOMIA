<?php
class AppointmentController extends Controller {

    /** Vérifie la date choisie : renvoie [timestamp|null, erreurs]. */
    private function checkDate(string $raw): array {
        $ts = strtotime($raw); $errors = [];
        if (!$ts || $ts < time() + 3600) $errors[] = 'Choisissez une date future (au moins 1 h à l\'avance).';
        else {
            $h = (int)date('G', $ts);
            if ($h < 8 || $h >= 18 || date('N', $ts) > 6) $errors[] = 'Les consultations ont lieu du lundi au samedi, de 8 h à 18 h.';
            elseif (!Appointment::isAligned($ts)) $errors[] = 'Les rendez-vous commencent toutes les 30 minutes (ex. 09:00, 09:30).';
        }
        return [$ts ?: null, $errors];
    }

    /** Formulaire de prise de rendez-vous avec un médecin précis. */
    public function create(): void {
        $this->requireLogin();
        $doctor = User::doctor((int)($_GET['doctor'] ?? 0));
        if (!$doctor) { http_response_code(404); exit('Médecin introuvable.'); }
        $part = isset($_GET['part']) ? BodyPart::find((int)$_GET['part']) : null;
        $errors = [];
        // Créneau choisi depuis le tableau des disponibilités (?at=2026-11-23T10:00)
        $old = preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $_GET['at'] ?? '') ? ['scheduled_at' => $_GET['at']] : [];
        $this->page = 'appointment-new'; $this->title = 'Prendre rendez-vous';
        $this->render('front/appointment/create', compact('doctor', 'part', 'errors', 'old'));
    }
    public function store(): void {
        $me = $this->requireLogin();
        if (!$this->isPost()) $this->redirect('body');
        $this->checkCsrf();
        $doctor = User::doctor((int)($_POST['doctor_id'] ?? 0));
        if (!$doctor) { http_response_code(404); exit('Médecin introuvable.'); }
        $partId = (int)($_POST['body_part_id'] ?? 0) ?: null;
        $part   = $partId ? BodyPart::find($partId) : null;
        $reason = trim($_POST['reason'] ?? '');
        [$ts, $errors] = $this->checkDate($_POST['scheduled_at'] ?? '');

        if ((int)$doctor['id'] === (int)$me['id']) $errors[] = 'Vous ne pouvez pas prendre rendez-vous avec vous-même.';
        if ($reason === '') $errors[] = 'Indiquez le motif de la consultation.';
        $dt = $ts ? date('Y-m-d H:i:00', $ts) : '';
        // Règle métier : un médecin ne peut pas avoir deux rendez-vous en même temps (créneau + chevauchement)
        if (!$errors) $errors = Appointment::slotErrors((int)$doctor['id'], $ts);
        // Un médecin qui réserve chez un confrère ne doit pas être déjà pris dans son propre agenda
        if (!$errors && $me['role'] === 'doctor' && !Appointment::isFree((int)$me['id'], $dt))
            $errors[] = 'Vous avez déjà un rendez-vous à cette heure-là dans votre agenda de médecin.';

        if (!$errors) {
            try {
                Appointment::create((int)$me['id'], (int)$doctor['id'], $part['id'] ?? null, $dt, str_limit($reason, 255));
                flash('Demande envoyée à ' . $doctor['name'] . '. Vous serez prévenu(e) dès qu\'elle est confirmée.');
                $this->redirect('appointment-mine');
            } catch (PDOException $e) { // deux patients ont réservé en même temps : la contrainte UNIQUE a tranché
                $errors[] = 'Ce créneau vient d\'être pris par un autre patient, choisissez une autre heure.';
            }
        }
        $old = $_POST;
        $this->page = 'appointment-new'; $this->title = 'Prendre rendez-vous';
        $this->render('front/appointment/create', compact('doctor', 'part', 'errors', 'old'));
    }

    /** Proposer un rendez-vous SANS choisir de médecin : tous les médecins de la spécialité le voient. */
    public function propose(): void {
        $this->requireLogin();
        $specialties = Specialty::all();
        $part = isset($_GET['part']) ? BodyPart::find((int)$_GET['part']) : null;
        $errors = []; $old = [];
        $this->page = 'appointment-propose'; $this->title = 'Proposer un rendez-vous';
        $this->render('front/appointment/propose', compact('specialties', 'part', 'errors', 'old'));
    }
    public function storeProposal(): void {
        $me = $this->requireLogin();
        if (!$this->isPost()) $this->redirect('appointment-propose');
        $this->checkCsrf();
        $specialties = Specialty::all();
        $spec   = Specialty::find((int)($_POST['specialty_id'] ?? 0));
        $partId = (int)($_POST['body_part_id'] ?? 0) ?: null;
        $part   = $partId ? BodyPart::find($partId) : null;
        $reason = trim($_POST['reason'] ?? '');
        [$ts, $errors] = $this->checkDate($_POST['scheduled_at'] ?? '');
        if (!$spec) $errors[] = 'Choisissez une spécialité.';
        if ($reason === '') $errors[] = 'Indiquez le motif de la consultation.';

        if ($errors) {
            $old = $_POST;
            $this->page = 'appointment-propose'; $this->title = 'Proposer un rendez-vous';
            $this->render('front/appointment/propose', compact('specialties', 'part', 'errors', 'old'));
            return;
        }
        Appointment::createOpen((int)$me['id'], (int)$spec['id'], $part['id'] ?? null, date('Y-m-d H:i:00', $ts), str_limit($reason, 255));
        flash('Proposition publiée : les médecins en ' . $spec['name'] . ' peuvent maintenant la voir et l\'accepter.');
        $this->redirect('appointment-mine');
    }

    public function mine(): void {
        $me = $this->requireLogin();
        $appointments = Appointment::forPatient((int)$me['id']);
        $this->page = 'appointment-mine'; $this->title = 'Mes rendez-vous';
        $this->render('front/appointment/mine', compact('appointments'));
    }
    public function cancel(): void {
        $me = $this->requireLogin();
        $this->checkCsrf();
        $a = Appointment::find((int)($_POST['id'] ?? 0));
        if ($a && (int)$a['patient_id'] === (int)$me['id'] && in_array($a['status'], ['open', 'pending', 'confirmed'], true)) {
            Appointment::setStatus((int)$a['id'], 'cancelled');
            flash('Rendez-vous annulé.');
        }
        $this->redirect('appointment-mine');
    }

    /** Rendez-vous du patient connecté encore modifiable (proposition ouverte ou en attente). */
    private function editable(array $me): array {
        $a = Appointment::find((int)($_REQUEST['id'] ?? 0));
        if (!$a || (int)$a['patient_id'] !== (int)$me['id'] || !in_array($a['status'], ['open', 'pending'], true)) {
            flash('Ce rendez-vous ne peut plus être modifié.', 'warning'); $this->redirect('appointment-mine');
        }
        return $a;
    }
    public function edit(): void {
        $me = $this->requireLogin(); $a = $this->editable($me);
        $errors = []; $old = ['scheduled_at' => date('Y-m-d\TH:i', strtotime($a['scheduled_at'])), 'reason' => $a['reason']];
        $this->page = 'appointment-mine'; $this->title = 'Modifier mon rendez-vous';
        $this->render('front/appointment/edit', compact('a', 'errors', 'old'));
    }
    public function update(): void {
        $me = $this->requireLogin();
        if (!$this->isPost()) $this->redirect('appointment-mine');
        $this->checkCsrf();
        $a = $this->editable($me);
        $reason = trim($_POST['reason'] ?? '');
        [$ts, $errors] = $this->checkDate($_POST['scheduled_at'] ?? '');
        if ($reason === '') $errors[] = 'Indiquez le motif de la consultation.';
        if (!$errors && $a['doctor_id']) $errors = Appointment::slotErrors((int)$a['doctor_id'], $ts, (int)$a['id']);
        if (!$errors) {
            try {
                Appointment::reschedule((int)$a['id'], $a['doctor_id'] ? (int)$a['doctor_id'] : null, date('Y-m-d H:i:00', $ts), str_limit($reason, 255));
                flash('Rendez-vous modifié.');
                $this->redirect('appointment-mine');
            } catch (PDOException $e) { $errors[] = 'Ce créneau vient d\'être pris, choisissez une autre heure.'; }
        }
        $old = $_POST;
        $this->page = 'appointment-mine'; $this->title = 'Modifier mon rendez-vous';
        $this->render('front/appointment/edit', compact('a', 'errors', 'old'));
    }
    /** Suppression définitive d'un rendez-vous annulé (nettoie l'historique du patient). */
    public function delete(): void {
        $me = $this->requireLogin();
        $this->checkCsrf();
        $a = Appointment::find((int)($_POST['id'] ?? 0));
        if ($a && (int)$a['patient_id'] === (int)$me['id'] && $a['status'] === 'cancelled') {
            Appointment::delete((int)$a['id']);
            flash('Rendez-vous supprimé.');
        }
        $this->redirect('appointment-mine');
    }
}
