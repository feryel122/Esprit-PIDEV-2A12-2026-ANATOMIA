<?php
/** Front office : tableau public « Disponibilités » (emploi du temps + créneaux libres des médecins). */
class AvailabilityController extends Controller {

    /** Tableau de tous les médecins : emploi du temps de la semaine + prochains créneaux libres. */
    public function index(): void {
        $specialties = Specialty::all();
        $specialtyId = (int)($_GET['specialty'] ?? 0) ?: null;
        $schedules = Availability::allByDoctor();
        $rows = [];
        foreach (User::doctors($specialtyId) as $d) {
            $rows[] = $d + ['week' => $schedules[(int)$d['id']] ?? [], 'next' => Availability::nextFree((int)$d['id'], 3)];
        }
        $this->page = 'availability'; $this->title = 'Disponibilités des médecins';
        $this->render('front/availability/index', compact('specialties', 'specialtyId', 'rows'));
    }

    /** Planning détaillé d'un médecin pour une semaine (créneaux libres cliquables). */
    public function show(): void {
        $doctor = User::doctor((int)($_GET['doctor'] ?? 0));
        if (!$doctor) { http_response_code(404); exit('Médecin introuvable.'); }
        $monday = Availability::mondayOf($_GET['week'] ?? null);
        $grid = Availability::weekGrid((int)$doctor['id'], $monday);
        $week = Availability::byDay((int)$doctor['id']);
        $this->page = 'availability'; $this->title = 'Disponibilités — ' . $doctor['name'];
        $this->render('front/availability/show', compact('doctor', 'monday', 'grid', 'week'));
    }
}
