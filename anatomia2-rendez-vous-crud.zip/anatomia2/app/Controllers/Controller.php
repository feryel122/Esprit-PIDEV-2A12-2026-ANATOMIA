<?php
abstract class Controller {
    /** Clé de la page courante : sert à marquer le lien actif (navbar / sidebar). */
    protected string $page = 'body';
    /** Titre affiché dans <title>. */
    protected string $title = 'Anatomia';

    /**
     * 'front' : la vue (Views/front/...) assemble elle-même ses includes/ (require_once).
     * 'back'  : la vue de contenu (Views/back/pages/...) est capturée dans $content,
     *           puis Views/back/layout.php assemble head / sidebar / header / footer / scripts.
     */
    protected function render(string $view, array $data = [], string $layout = 'front'): void {
        $u = Auth::user();
        // Badge « propositions ouvertes » (sidebar du médecin) : celles de sa spécialité, hors les siennes
        $openProposals = ($u && $u['role'] === 'doctor' && ($d = User::doctor((int)$u['id'])))
            ? Appointment::openCount((int)$u['id'], (int)$d['specialty_id']) : 0;
        $data += ['user' => $u, 'flash' => flash(), 'pageTitle' => $this->title, 'currentPage' => $this->page, 'openProposals' => $openProposals];
        if ($layout === 'front') {
            extract($data);
            require __DIR__ . "/../Views/$view.php";
            return;
        }
        $content = $this->capture(__DIR__ . "/../Views/back/pages/$view.php", $data);
        extract($data);
        require __DIR__ . '/../Views/back/layout.php';
    }
    private function capture(string $file, array $data): string {
        extract($data);
        ob_start();
        require $file;
        return ob_get_clean();
    }
    protected function redirect(string $page, array $params = []): never {
        header('Location: ' . url($page, $params)); exit;
    }
    protected function requireLogin(): array {
        $u = Auth::user();
        if (!$u) { flash('Connectez-vous pour continuer.', 'warning'); $this->redirect('login'); }
        return $u;
    }
    protected function requireRole(string ...$roles): array {
        $u = $this->requireLogin();
        if (!in_array($u['role'], $roles, true)) { http_response_code(403); exit('Accès refusé.'); }
        return $u;
    }
    protected function checkCsrf(): void {
        if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['_csrf'] ?? '')) {
            http_response_code(419); exit('Session expirée, rechargez la page.');
        }
    }
    protected function isPost(): bool { return $_SERVER['REQUEST_METHOD'] === 'POST'; }
}
