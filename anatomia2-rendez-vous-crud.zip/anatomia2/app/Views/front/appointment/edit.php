<?php
require_once __DIR__ . '/../includes/head.php';
require_once __DIR__ . '/../includes/spinner.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<main class="main">
<section class="page-head"><div class="container">
  <h1>Modifier mon rendez-vous</h1>
  <p><?= $a['doctor_name'] ? 'Avec ' . e($a['doctor_name']) . ' — ' . e($a['specialty']) : 'Proposition ouverte — ' . e($a['specialty']) ?></p>
</div></section>
<section class="pb-5"><div class="container"><div class="row"><div class="col-lg-7">
  <?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
  <form method="post" action="<?= url('appointment-update') ?>" class="bg-white p-4 rounded-4 border">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
    <div class="mb-3"><label class="form-label" for="scheduled_at">Date et heure</label>
      <input type="datetime-local" class="form-control" id="scheduled_at" name="scheduled_at" step="1800" required
             min="<?= date('Y-m-d\TH:i', time() + 3600) ?>" value="<?= e($old['scheduled_at'] ?? '') ?>"></div>
    <div class="mb-3"><label class="form-label" for="reason">Motif de la consultation</label>
      <textarea class="form-control" id="reason" name="reason" rows="3" maxlength="255" required><?= e($old['reason'] ?? '') ?></textarea></div>
    <button class="btn text-white" style="background:var(--accent-color)">Enregistrer</button>
    <a class="btn btn-link" href="<?= url('appointment-mine') ?>">Annuler</a>
  </form>
</div></div></div></section>
</main>
<?php
require_once __DIR__ . '/../includes/footer.php';
require_once __DIR__ . '/../includes/scripts.php';
?>
