<?php
require_once __DIR__ . '/../includes/head.php';
require_once __DIR__ . '/../includes/spinner.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<main class="main">
<section class="page-head"><div class="container d-flex flex-wrap justify-content-between align-items-center gap-2">
  <h1 class="mb-0">Mes rendez-vous</h1>
  <a class="btn text-white" style="background:var(--accent-color)" href="<?= url('appointment-propose') ?>">Proposer un rendez-vous</a>
</div></section>
<section class="pb-5"><div class="container">
  <?php if (!$appointments): ?>
    <p>Vous n'avez pas encore de rendez-vous. <a href="<?= url('body') ?>">Choisissez une partie du corps</a> pour trouver un médecin.</p>
  <?php else: ?>
  <div class="table-responsive bg-white rounded-4 border p-2">
    <table class="table align-middle mb-0">
      <thead><tr><th>Date</th><th>Médecin</th><th>Zone</th><th>Motif</th><th>Statut</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($appointments as $a): [$lbl, $cls] = status_label($a['status']); ?>
        <tr>
          <td><?= e(date('d/m/Y H:i', strtotime($a['scheduled_at']))) ?></td>
          <td><?php if ($a['doctor_name']): ?><?= e($a['doctor_name']) ?><?php else: ?><em>Premier médecin disponible</em><?php endif; ?><br><small class="text-muted"><?= e($a['specialty']) ?></small></td>
          <td><?= e($a['body_part'] ?? '—') ?></td>
          <td><?= e($a['reason']) ?></td>
          <td><span class="badge text-bg-<?= $cls ?>"><?= $lbl ?></span></td>
          <td class="text-end">
            <?php if (in_array($a['status'], ['open', 'pending'], true)): ?>
              <a class="btn btn-sm btn-outline-primary" href="<?= url('appointment-edit', ['id' => $a['id']]) ?>">Modifier</a>
            <?php endif; ?>
            <?php if (in_array($a['status'], ['open', 'pending', 'confirmed'], true)): ?>
              <form method="post" action="<?= url('appointment-cancel') ?>" class="d-inline" onsubmit="return confirm('Annuler ce rendez-vous ?')">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                <button class="btn btn-sm btn-outline-danger">Annuler</button></form>
            <?php elseif ($a['status'] === 'cancelled'): ?>
              <form method="post" action="<?= url('appointment-delete') ?>" class="d-inline" onsubmit="return confirm('Supprimer définitivement ce rendez-vous ?')">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                <button class="btn btn-sm btn-outline-secondary">Supprimer</button></form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div></section>
</main>
<?php
require_once __DIR__ . '/../includes/footer.php';
require_once __DIR__ . '/../includes/scripts.php';
?>
