<?php
require_once __DIR__ . '/../includes/head.php';
require_once __DIR__ . '/../includes/spinner.php';
require_once __DIR__ . '/../includes/navbar.php';
$prev = $monday->modify('-1 week'); $next = $monday->modify('+1 week');
$isCurrentWeek = $monday <= new DateTimeImmutable('monday this week 00:00');
$isLastWeek = $monday >= (new DateTimeImmutable('monday this week 00:00'))->modify('+12 weeks');
$linkSlots = true; $showPatients = false;
?>
<main class="main">
<section class="page-head"><div class="container">
  <h1>Disponibilités — <?= e($doctor['name']) ?></h1>
  <p><?= e($doctor['specialty']) ?> — <?= e($doctor['city']) ?>.
    <a href="<?= url('availability') ?>">← Tous les médecins</a></p>
</div></section>
<section class="pb-5"><div class="container">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div class="btn-group">
      <a class="btn btn-outline-secondary <?= $isCurrentWeek ? 'disabled' : '' ?>" href="<?= url('availability-show', ['doctor' => $doctor['id'], 'week' => $prev->format('Y-m-d')]) ?>">← Semaine précédente</a>
      <a class="btn btn-outline-secondary" href="<?= url('availability-show', ['doctor' => $doctor['id']]) ?>">Cette semaine</a>
      <a class="btn btn-outline-secondary <?= $isLastWeek ? 'disabled' : '' ?>" href="<?= url('availability-show', ['doctor' => $doctor['id'], 'week' => $next->format('Y-m-d')]) ?>">Semaine suivante →</a>
    </div>
    <strong>Semaine du <?= e($monday->format('d/m/Y')) ?> au <?= e($monday->modify('+5 days')->format('d/m/Y')) ?></strong>
  </div>
  <div class="bg-white rounded-4 border p-3">
    <?php require __DIR__ . '/../../shared/week_grid.php'; ?>
  </div>
</div></section>
</main>
<?php
require_once __DIR__ . '/../includes/footer.php';
require_once __DIR__ . '/../includes/scripts.php';
?>
