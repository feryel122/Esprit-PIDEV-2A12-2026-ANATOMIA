<?php
require_once __DIR__ . '/../includes/head.php';
require_once __DIR__ . '/../includes/spinner.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<main class="main">
<section class="page-head"><div class="container">
  <h1>Disponibilités des médecins</h1>
  <p>Emploi du temps hebdomadaire et prochains créneaux libres. Cliquez sur un créneau pour réserver.</p>
</div></section>
<section class="pb-5"><div class="container">
  <form method="get" action="index.php" class="row g-2 align-items-end mb-3">
    <input type="hidden" name="page" value="availability">
    <div class="col-sm-6 col-md-4"><label class="form-label" for="specialty">Spécialité</label>
      <select class="form-select" id="specialty" name="specialty" onchange="this.form.submit()">
        <option value="">Toutes les spécialités</option>
        <?php foreach ($specialties as $s): ?>
          <option value="<?= (int)$s['id'] ?>" <?= $specialtyId === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option>
        <?php endforeach; ?>
      </select></div>
    <noscript><div class="col-auto"><button class="btn btn-outline-secondary">Filtrer</button></div></noscript>
  </form>

  <div class="table-responsive bg-white rounded-4 border p-2">
    <table class="table align-middle mb-0">
      <thead><tr><th>Médecin</th><th>Emploi du temps</th><th>Prochains créneaux libres</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($rows as $d): ?>
        <tr>
          <td><strong><?= e($d['name']) ?></strong><br><small class="text-muted"><?= e($d['specialty']) ?> — <?= e($d['city']) ?></small></td>
          <td>
            <?php if (!$d['week']): ?><span class="text-muted small">Aucun horaire défini</span>
            <?php else: ?><ul class="list-unstyled small mb-0">
              <?php foreach (Availability::DAYS as $n => $label): if (empty($d['week'][$n])) continue; ?>
                <li><span class="fw-semibold"><?= e(Availability::SHORT[$n]) ?>.</span> <?= e(Availability::dayText($d['week'][$n])) ?></li>
              <?php endforeach; ?></ul><?php endif; ?>
          </td>
          <td>
            <?php foreach ($d['next'] as $ts): ?>
              <a class="badge text-bg-success text-decoration-none d-inline-block mb-1" title="Réserver ce créneau"
                 href="<?= url('appointment-new', ['doctor' => $d['id'], 'at' => date('Y-m-d\TH:i', $ts)]) ?>"><?= e(date('d/m H:i', $ts)) ?></a><br>
            <?php endforeach; if (!$d['next']): ?><span class="text-muted small">Aucun créneau libre prochainement</span><?php endif; ?>
          </td>
          <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="<?= url('availability-show', ['doctor' => $d['id']]) ?>">Voir le planning</a></td>
        </tr>
      <?php endforeach; if (!$rows): ?>
        <tr><td colspan="4" class="text-center text-muted py-4">Aucun médecin pour cette spécialité.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div></section>
</main>
<?php
require_once __DIR__ . '/../includes/footer.php';
require_once __DIR__ . '/../includes/scripts.php';
?>
