<script src="<?= front_asset('vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= front_asset('vendor/aos/aos.js') ?>"></script>
<script src="<?= front_asset('js/main.js') ?>"></script>
<?php if (!empty($extraScripts)) echo $extraScripts; ?>
</body>
</html>
