<!-- Preloader (MediLab : retiré par js/main.js au chargement) -->
<div id="preloader"></div>
