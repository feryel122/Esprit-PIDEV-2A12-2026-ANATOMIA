<footer id="footer" class="footer light-background">
  <div class="container copyright text-center mt-4">
    <p>© Anatomia — Projet intégré. Templates : MediLab (BootstrapMade) &amp; AdminLTE 4.</p>
  </div>
</footer>
<!-- Back to top -->
<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
