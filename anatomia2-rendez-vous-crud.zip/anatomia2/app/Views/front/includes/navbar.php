<?php
// $currentPage et $user sont fournis par le Controller (Controller::render)
$currentPage = $currentPage ?? '';
$user = $user ?? Auth::user();
?>
<header id="header" class="header sticky-top">
  <div class="branding d-flex align-items-center">
    <div class="container position-relative d-flex align-items-center justify-content-between">
      <a href="<?= url('body') ?>" class="logo d-flex align-items-center me-auto"><h1 class="sitename">Anatomia</h1></a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?= url('body') ?>" class="<?= navActive('body', $currentPage) ?>">Corps humain</a></li>
          <li><a href="<?= url('availability') ?>" class="<?= navActive('availability', $currentPage) ?>">Disponibilités</a></li>
          <?php if ($user): ?>
            <li><a href="<?= url('appointment-mine') ?>" class="<?= navActive('appointment-mine', $currentPage) ?>">Mes rendez-vous</a></li>
            <li><a href="<?= url('appointment-propose') ?>" class="<?= navActive('appointment-propose', $currentPage) ?>">Proposer</a></li>
            <?php if (in_array($user['role'], ['doctor', 'admin'], true)): ?>
              <li><a href="<?= url('admin-dashboard') ?>"><?= $user['role'] === 'admin' ? 'Administration' : 'Espace médecin' ?></a></li>
            <?php endif; ?>
            <li><a href="<?= url('logout') ?>">Déconnexion (<?= e(explode(' ', $user['name'])[0]) ?>)</a></li>
          <?php else: ?>
            <li><a href="<?= url('login') ?>" class="<?= navActive('login', $currentPage) ?>">Connexion</a></li>
            <li><a href="<?= url('register') ?>" class="<?= navActive('register', $currentPage) ?>">Inscription</a></li>
          <?php endif; ?>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
      <a class="cta-btn d-none d-sm-block" href="<?= url('body') ?>">Prendre rendez-vous</a>
    </div>
  </div>
</header>
<?php if (!empty($flash)): ?>
  <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible mb-0 rounded-0 text-center flash-bar" role="alert">
    <?= e($flash['msg']) ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
  </div>
<?php endif; ?>
