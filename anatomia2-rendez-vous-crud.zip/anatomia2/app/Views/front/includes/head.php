<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($pageTitle ?? 'Anatomia') ?> — Anatomia</title>
  <link href="<?= front_asset('img/favicon.png') ?>" rel="icon">
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Poppins:wght@300;400;500;600;700&family=Raleway:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="<?= front_asset('vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
  <link href="<?= front_asset('vendor/bootstrap-icons/bootstrap-icons.css') ?>" rel="stylesheet">
  <link href="<?= front_asset('vendor/aos/aos.css') ?>" rel="stylesheet">
  <link href="<?= front_asset('css/main.css') ?>" rel="stylesheet">
  <link href="<?= front_asset('css/anatomia.css') ?>" rel="stylesheet">
</head>
<body class="index-page">
