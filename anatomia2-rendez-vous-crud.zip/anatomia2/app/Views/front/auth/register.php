<?php
require_once __DIR__ . '/../includes/head.php';
require_once __DIR__ . '/../includes/spinner.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<main class="main">
<section class="page-head"><div class="container"><h1>Créer un compte</h1></div></section>
<section class="pb-5"><div class="container"><div class="row"><div class="col-md-6 col-lg-5">
  <?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
  <form method="post" class="bg-white p-4 rounded-4 border">
    <?= csrf_field() ?>
    <div class="mb-3"><label class="form-label" for="name">Nom complet</label><input class="form-control" id="name" name="name" value="<?= e($old['name'] ?? '') ?>" required></div>
    <div class="mb-3"><label class="form-label" for="email">Email</label><input class="form-control" type="email" id="email" name="email" value="<?= e($old['email'] ?? '') ?>" required></div>
    <div class="mb-3"><label class="form-label" for="phone">Téléphone (facultatif)</label><input class="form-control" id="phone" name="phone" value="<?= e($old['phone'] ?? '') ?>"></div>
    <div class="mb-3"><label class="form-label" for="password">Mot de passe</label><input class="form-control" type="password" id="password" name="password" minlength="6" required></div>
    <button class="btn text-white" style="background:var(--accent-color)">S'inscrire</button>
  </form>
</div></div></div></section>
</main>
<?php
require_once __DIR__ . '/../includes/footer.php';
require_once __DIR__ . '/../includes/scripts.php';
?>
