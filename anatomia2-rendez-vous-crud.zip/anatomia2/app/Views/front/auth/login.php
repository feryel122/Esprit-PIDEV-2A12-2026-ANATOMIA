<?php
require_once __DIR__ . '/../includes/head.php';
require_once __DIR__ . '/../includes/spinner.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<main class="main">
<section class="page-head"><div class="container"><h1>Connexion</h1><p>Patients et médecins se connectent ici.</p></div></section>
<section class="pb-5"><div class="container"><div class="row"><div class="col-md-6 col-lg-5">
  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="bg-white p-4 rounded-4 border">
    <?= csrf_field() ?>
    <div class="mb-3"><label class="form-label" for="email">Email</label><input class="form-control" type="email" id="email" name="email" required></div>
    <div class="mb-3"><label class="form-label" for="password">Mot de passe</label><input class="form-control" type="password" id="password" name="password" required></div>
    <button class="btn text-white" style="background:var(--accent-color)">Se connecter</button>
    <a class="ms-2" href="<?= url('register') ?>">Créer un compte</a>
  </form>
</div></div></div></section>
</main>
<?php
require_once __DIR__ . '/../includes/footer.php';
require_once __DIR__ . '/../includes/scripts.php';
?>
