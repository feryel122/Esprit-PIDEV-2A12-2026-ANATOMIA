<?php
require_once __DIR__ . '/../includes/head.php';
require_once __DIR__ . '/../includes/spinner.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<main class="main">
<section class="page-head">
  <div class="container">
    <a href="<?= url('body') ?>" class="text-decoration-none"><i class="bi bi-arrow-left"></i> Retour au corps humain</a>
    <h1 class="mt-2"><?= e($part['name']) ?></h1>
    <p><?= e($part['summary']) ?></p>
  </div>
</section>

<section class="pb-4">
  <div class="container">
    <div class="row gy-3">
      <div class="col-lg-8">
        <div class="info-block"><h2 class="h5">À quoi ça sert ?</h2><p class="mb-0"><?= nl2br(e($part['description'])) ?></p></div>
        <?php if ($part['common_issues']): ?>
          <div class="info-block warn"><h2 class="h5">Petits maux fréquents</h2><p class="mb-0"><?= nl2br(e($part['common_issues'])) ?></p></div>
        <?php endif; ?>
        <?php if ($part['prevention']): ?>
          <div class="info-block"><h2 class="h5">Bons réflexes</h2><p class="mb-0"><?= nl2br(e($part['prevention'])) ?></p></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<section class="pb-5">
  <div class="container">
    <h2 class="h4 mb-3">Consulter un médecin pour cette zone</h2>
    <?php if (!$doctors): ?>
      <p>Aucun médecin n'est encore référencé pour cette partie du corps.</p>
    <?php else: ?>
      <div class="row gy-4">
        <?php foreach ($doctors as $d): ?>
          <div class="col-md-6 col-lg-4">
            <div class="doctor-card d-flex flex-column">
              <div class="d-flex gap-3 align-items-center mb-2">
                <img src="<?= front_asset('img/' . ($d['photo'] ?: 'doctors/doctors-1.jpg')) ?>" alt="">
                <div><strong><?= e($d['name']) ?></strong><br><span class="text-success"><?= e($d['specialty']) ?></span><br>
                  <small><i class="bi bi-geo-alt"></i> <?= e($d['city']) ?></small></div>
              </div>
              <p class="small flex-grow-1"><?= e($d['bio']) ?></p>
              <?php if ($user && (int)$user['id'] === (int)$d['id']): ?>
                <span class="small text-muted">C'est votre profil.</span>
              <?php else: ?>
                <a class="btn btn-sm text-white" style="background:var(--accent-color)"
                   href="<?= url('appointment-new', ['doctor' => $d['id'], 'part' => $part['id']]) ?>">Prendre rendez-vous</a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
</main>
<?php
require_once __DIR__ . '/../includes/footer.php';
require_once __DIR__ . '/../includes/scripts.php';
?>
