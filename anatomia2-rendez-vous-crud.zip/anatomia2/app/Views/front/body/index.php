<?php
require_once __DIR__ . '/../includes/head.php';
require_once __DIR__ . '/../includes/spinner.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<main class="main">
<?php
// Zones cliquables du SVG : slug => formes. Seules les parties présentes en base sont cliquables.
$zones = [
  'tete'    => ['<circle cx="120" cy="52" r="34"/>'],
  'cou'     => ['<rect x="105" y="84" width="30" height="22" rx="6"/>'],
  'thorax'  => ['<rect x="72" y="108" width="96" height="86" rx="26"/>'],
  'abdomen' => ['<rect x="78" y="196" width="84" height="76" rx="22"/>'],
  'bras'    => ['<rect x="28" y="112" width="34" height="150" rx="17"/>', '<rect x="178" y="112" width="34" height="150" rx="17"/>'],
  'mains'   => ['<circle cx="45" cy="282" r="17"/>', '<circle cx="195" cy="282" r="17"/>'],
  'jambes'  => ['<rect x="80" y="278" width="36" height="170" rx="16"/>', '<rect x="124" y="278" width="36" height="170" rx="16"/>'],
  'pieds'   => ['<ellipse cx="94" cy="472" rx="24" ry="13"/>', '<ellipse cx="146" cy="472" rx="24" ry="13"/>'],
];
$bySlug = array_column($parts, null, 'slug');
?>
<section class="page-head">
  <div class="container">
    <h1>Explorez le corps humain</h1>
    <p>Cliquez sur une partie du corps pour la comprendre, trouver des conseils, puis consulter un médecin spécialisé et prendre rendez-vous.</p>
  </div>
</section>

<section class="pb-5">
  <div class="container">
    <div class="row gy-4 align-items-start">
      <div class="col-lg-5">
        <svg class="body-map" viewBox="0 0 240 500" role="img" aria-label="Schéma du corps humain cliquable">
          <?php foreach ($zones as $slug => $shapes): if (!isset($bySlug[$slug])) continue; ?>
            <a href="<?= url('body-show', ['slug' => $slug]) ?>" aria-label="<?= e($bySlug[$slug]['name']) ?>">
              <title><?= e($bySlug[$slug]['name']) ?></title>
              <?= implode('', array_map(fn($s) => preg_replace('/^<(\w+)/', '<$1 class="zone"', $s), $shapes)) ?>
            </a>
          <?php endforeach; ?>
        </svg>
      </div>
      <div class="col-lg-7">
        <h2 class="h4 mb-3">Toutes les parties du corps</h2>
        <?php foreach ($parts as $p): ?>
          <a class="part-card" href="<?= url('body-show', ['slug' => $p['slug']]) ?>">
            <strong><?= e($p['name']) ?></strong><span><?= e($p['summary']) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>
</main>
<?php
require_once __DIR__ . '/../includes/footer.php';
require_once __DIR__ . '/../includes/scripts.php';
?>
