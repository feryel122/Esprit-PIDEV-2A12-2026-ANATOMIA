<?php
/**
 * Grille « emploi du temps » d'une semaine (partagée front / back).
 * Variables : $grid (Availability::weekGrid), $doctor, $linkSlots (bool : créneaux libres cliquables), $showPatients (bool)
 */
$linkSlots = $linkSlots ?? false; $showPatients = $showPatients ?? false;
?>
<?php if (!$grid['times']): ?>
  <p class="text-center text-secondary py-4 mb-0">Aucun horaire défini pour ce médecin.</p>
<?php else: ?>
<div class="table-responsive">
  <table class="table table-bordered text-center align-middle mb-0">
    <thead><tr class="table-light">
      <th style="width:70px">Heure</th>
      <?php foreach ($grid['days'] as $d): ?>
        <th><?= e($d['label']) ?><br><small class="fw-normal text-secondary"><?= e($d['date']->format('d/m')) ?></small></th>
      <?php endforeach; ?>
    </tr></thead>
    <tbody>
    <?php foreach ($grid['times'] as $t): ?>
      <tr>
        <th class="text-nowrap small"><?= e($t) ?></th>
        <?php foreach ($grid['days'] as $d): $s = $d['slots'][$t] ?? null; ?>
          <td class="p-1">
          <?php if (!$s): ?>
            <span class="text-secondary">·</span>
          <?php elseif ($s['status'] === 'free'): ?>
            <?php if ($linkSlots): ?>
              <a class="badge text-bg-success text-decoration-none w-100 py-2" title="Réserver ce créneau"
                 href="<?= url('appointment-new', ['doctor' => $doctor['id'], 'at' => date('Y-m-d\TH:i', $s['ts'])]) ?>">Libre</a>
            <?php else: ?><span class="badge text-bg-success w-100 py-2">Libre</span><?php endif; ?>
          <?php elseif ($s['status'] === 'busy'): ?>
            <span class="badge text-bg-danger w-100 py-2 text-truncate" style="max-width:120px"
                  title="<?= e($showPatients && $s['patient'] ? $s['patient'] : 'Occupé') ?>"><?= $showPatients && $s['patient'] ? e($s['patient']) : 'Occupé' ?></span>
          <?php else: ?>
            <span class="badge text-bg-light border text-secondary w-100 py-2">—</span>
          <?php endif; ?>
          </td>
        <?php endforeach; ?>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<div class="d-flex flex-wrap gap-3 small text-secondary mt-2">
  <span><span class="badge text-bg-success">Libre</span> créneau disponible (30 min)</span>
  <span><span class="badge text-bg-danger">Occupé</span> déjà réservé</span>
  <span><span class="badge text-bg-light border text-secondary">—</span> passé ou trop proche (&lt; 1 h)</span>
  <span><span class="text-secondary">·</span> le médecin ne consulte pas</span>
</div>
<?php if (!empty($grid['outside'])): ?>
  <div class="alert alert-warning mt-3 mb-0 small"><strong>Rendez-vous hors de vos horaires :</strong>
    <?php foreach ($grid['outside'] as $o): ?><span class="d-inline-block me-3"><?= e(date('d/m H:i', $o['ts'])) ?> — <?= e($o['patient']) ?></span><?php endforeach; ?></div>
<?php endif; ?>
<?php endif; ?>
