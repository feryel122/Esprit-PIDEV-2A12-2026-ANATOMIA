<div class="card">
  <div class="card-header"><h3 class="card-title">Médecins</h3>
    <div class="card-tools"><a href="<?= url('admin-doctors-create') ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Ajouter</a></div></div>
  <div class="card-body p-0 table-responsive">
    <table class="table table-striped align-middle mb-0">
      <thead><tr><th>#</th><th>Nom</th><th>Email</th><th>Spécialité</th><th>Ville</th><th>RDV à venir</th><th class="text-end">Actions</th></tr></thead>
      <tbody>
      <?php foreach ($doctors as $d): ?>
        <tr><td><?= (int)$d['id'] ?></td><td><?= e($d['name']) ?></td><td><?= e($d['email']) ?></td><td><?= e($d['specialty']) ?></td><td><?= e($d['city']) ?></td>
          <td><span class="badge text-bg-<?= $d['upcoming'] ? 'warning' : 'secondary' ?>"><?= (int)$d['upcoming'] ?></span></td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-primary" href="<?= url('admin-doctors-edit', ['id' => $d['id']]) ?>">Modifier</a>
            <form method="post" action="<?= url('admin-doctors-delete') ?>" class="d-inline" onsubmit="return confirm('Supprimer ce médecin et son compte ?')">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-outline-danger">Supprimer</button></form>
          </td></tr>
      <?php endforeach; if (!$doctors): ?>
        <tr><td colspan="7" class="text-center text-secondary py-4">Aucun médecin.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
