<?php $v = fn($k) => e($old[$k] ?? ''); $isEdit = !empty($doctor['id']); ?>
<?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" action="<?= url('admin-doctors-save') ?>" class="card">
  <div class="card-body">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($doctor['id'] ?? 0) ?>">
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Nom</label><input name="name" class="form-control" value="<?= $v('name') ?>" required></div>
      <div class="col-md-6 mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= $v('email') ?>" required></div>
    </div>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Téléphone</label><input name="phone" class="form-control" value="<?= $v('phone') ?>"></div>
      <div class="col-md-6 mb-3"><label class="form-label">Mot de passe<?= $isEdit ? ' (laisser vide pour ne pas changer)' : '' ?></label>
        <input type="password" name="password" class="form-control" minlength="6" autocomplete="new-password" <?= $isEdit ? '' : 'required' ?>></div>
    </div>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Spécialité</label>
        <select name="specialty_id" class="form-select" required><option value="">—</option>
          <?php foreach ($specialties as $s): ?><option value="<?= (int)$s['id'] ?>" <?= (int)($old['specialty_id'] ?? 0) === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="col-md-6 mb-3"><label class="form-label">Ville</label><input name="city" class="form-control" value="<?= $v('city') ?>" required></div>
    </div>
    <div class="mb-3"><label class="form-label">Présentation</label><textarea name="bio" rows="3" class="form-control"><?= $v('bio') ?></textarea></div>
  </div>
  <div class="card-footer"><button class="btn btn-primary">Enregistrer</button> <a class="btn btn-link" href="<?= url('admin-doctors') ?>">Annuler</a></div>
</form>
