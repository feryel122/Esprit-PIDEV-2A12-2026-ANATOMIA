<?php if (!empty($openProposals)): ?>
  <div class="alert alert-info d-flex justify-content-between align-items-center">
    <span><i class="bi bi-inbox me-2"></i><?= (int)$openProposals ?> proposition(s) de rendez-vous des utilisateurs attendent un médecin dans votre spécialité.</span>
    <a class="btn btn-sm btn-info" href="<?= url('admin-proposals') ?>">Voir les propositions</a>
  </div>
<?php endif; ?>
<div class="row">
  <?php foreach ([
    ['pending',   'En attente', 'warning',   'bi-hourglass-split'],
    ['confirmed', 'Confirmés',  'success',   'bi-check-circle'],
    ['done',      'Terminés',   'secondary', 'bi-clipboard-check'],
    ['cancelled', 'Annulés',    'danger',    'bi-x-circle'],
  ] as [$k, $label, $cls, $icon]): ?>
    <div class="col-6 col-lg-3">
      <div class="small-box text-bg-<?= $cls ?>">
        <div class="inner"><h3><?= (int)$counts[$k] ?></h3><p><?= $label ?></p></div>
        <i class="small-box-icon bi <?= $icon ?>"></i>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<div class="card">
  <div class="card-header"><h3 class="card-title">Prochains rendez-vous</h3></div>
  <div class="card-body p-0">
    <table class="table table-striped mb-0">
      <thead><tr><th>Date</th><th>Patient</th><?php if (!$isDoctor): ?><th>Médecin</th><?php endif; ?><th>Motif</th><th>Statut</th></tr></thead>
      <tbody>
      <?php foreach ($upcoming as $a): [$lbl, $cls] = status_label($a['status']); ?>
        <tr><td><?= e(date('d/m/Y H:i', strtotime($a['scheduled_at']))) ?></td><td><?= e($a['patient_name']) ?></td>
          <?php if (!$isDoctor): ?><td><?= e($a['doctor_name']) ?></td><?php endif; ?>
          <td><?= e($a['reason']) ?></td><td><span class="badge text-bg-<?= $cls ?>"><?= $lbl ?></span></td></tr>
      <?php endforeach; if (!$upcoming): ?>
        <tr><td colspan="5" class="text-center text-secondary py-3">Aucun rendez-vous à venir.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer"><a href="<?= url('admin-appointments') ?>">Voir tous les rendez-vous</a>
    <?php if (!$isDoctor): ?> · <?= (int)$nbParts ?> parties du corps publiées<?php endif; ?></div>
</div>
