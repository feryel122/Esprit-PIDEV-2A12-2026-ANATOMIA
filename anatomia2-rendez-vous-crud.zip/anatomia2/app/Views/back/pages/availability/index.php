<?php /* Disponibilités — contenu seul (layout AdminLTE injecté par Controller::render) */
$prev = $monday->modify('-1 week'); $next = $monday->modify('+1 week');
$isCurrentWeek = $monday <= new DateTimeImmutable('monday this week 00:00');
$isLastWeek = $monday >= (new DateTimeImmutable('monday this week 00:00'))->modify('+12 weeks');
$q = fn(array $extra = []) => ($isAdmin && $doctor ? ['doctor' => $doctor['id']] : []) + $extra;
?>
<?php if ($isAdmin): ?>
<!-- Tableau récapitulatif : tous les médecins (admin) -->
<div class="card mb-4">
  <div class="card-header"><h3 class="card-title">Disponibilité des médecins</h3></div>
  <div class="card-body p-0 table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead><tr><th>Médecin</th><th>Emploi du temps</th><th>RDV à venir</th><th>Prochain créneau libre</th><th class="text-end"></th></tr></thead>
      <tbody>
      <?php foreach ($overview as $d): ?>
        <tr class="<?= $doctor && (int)$doctor['id'] === (int)$d['id'] ? 'table-active' : '' ?>">
          <td><strong><?= e($d['name']) ?></strong><br><small class="text-secondary"><?= e($d['specialty']) ?> — <?= e($d['city']) ?></small></td>
          <td class="small">
            <?php foreach (Availability::DAYS as $n => $label): if (empty($d['week'][$n])) continue; ?>
              <div><span class="fw-semibold"><?= e(Availability::SHORT[$n]) ?>.</span> <?= e(Availability::dayText($d['week'][$n])) ?></div>
            <?php endforeach; if (!$d['week']): ?><span class="text-secondary">Aucun horaire défini</span><?php endif; ?>
          </td>
          <td><span class="badge text-bg-secondary"><?= (int)$d['upcoming'] ?></span></td>
          <td><?php if ($d['next']): ?><span class="badge text-bg-success"><?= e(date('d/m H:i', $d['next'][0])) ?></span>
              <?php else: ?><span class="badge text-bg-danger">Complet / aucun horaire</span><?php endif; ?></td>
          <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="<?= url('admin-availability', ['doctor' => $d['id']]) ?>">Planning</a></td>
        </tr>
      <?php endforeach; if (!$overview): ?>
        <tr><td colspan="5" class="text-center text-secondary py-4">Aucun médecin.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php if ($doctor): ?>
<div class="row g-3 mb-4">
  <!-- Emploi du temps hebdomadaire (plages horaires modifiables) -->
  <div class="col-lg-5">
    <div class="card h-100">
      <div class="card-header"><h3 class="card-title"><?= $isAdmin ? 'Emploi du temps — ' . e($doctor['name']) : 'Mon emploi du temps' ?></h3></div>
      <div class="card-body p-0 table-responsive">
        <table class="table align-middle mb-0">
          <thead><tr><th>Jour</th><th>Horaires de consultation</th></tr></thead>
          <tbody>
          <?php foreach (Availability::DAYS as $n => $label): ?>
            <tr>
              <td class="fw-semibold"><?= e($label) ?></td>
              <td>
                <?php foreach ($week[$n] ?? [] as $r): ?>
                  <form method="post" action="<?= url('admin-availability-delete') ?>" class="d-inline"
                        onsubmit="return confirm('Supprimer cet horaire ? Les rendez-vous déjà pris restent valables.')">
                    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <span class="badge text-bg-primary me-1 py-2"><?= e($r['start_time']) ?>–<?= e($r['end_time']) ?>
                      <button class="btn btn-sm p-0 ms-1 text-white border-0" title="Supprimer" aria-label="Supprimer l'horaire <?= e($r['start_time']) ?>–<?= e($r['end_time']) ?>">&times;</button></span>
                  </form>
                <?php endforeach; if (empty($week[$n])): ?><span class="text-secondary">Repos</span><?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="card-footer">
        <form method="post" action="<?= url('admin-availability-add') ?>" class="row g-2 align-items-end">
          <?= csrf_field() ?><input type="hidden" name="doctor_id" value="<?= (int)$doctor['id'] ?>">
          <div class="col-12 col-sm-4"><label class="form-label small mb-1" for="weekday">Jour</label>
            <select class="form-select form-select-sm" id="weekday" name="weekday" required>
              <?php foreach (Availability::DAYS as $n => $label): ?><option value="<?= $n ?>"><?= e($label) ?></option><?php endforeach; ?>
            </select></div>
          <div class="col-6 col-sm-3"><label class="form-label small mb-1" for="start_time">De</label>
            <input type="time" class="form-control form-control-sm" id="start_time" name="start_time" value="08:00" min="<?= Availability::OPEN ?>" max="<?= Availability::CLOSE ?>" step="1800" required></div>
          <div class="col-6 col-sm-3"><label class="form-label small mb-1" for="end_time">À</label>
            <input type="time" class="form-control form-control-sm" id="end_time" name="end_time" value="12:00" min="<?= Availability::OPEN ?>" max="<?= Availability::CLOSE ?>" step="1800" required></div>
          <div class="col-12 col-sm-2 d-grid"><button class="btn btn-sm btn-primary">Ajouter</button></div>
        </form>
        <div class="form-text">Entre <?= Availability::OPEN ?> et <?= Availability::CLOSE ?>, par pas de 30 min. Plusieurs plages possibles par jour (ex. matin + après-midi).</div>
      </div>
    </div>
  </div>

  <!-- Disponibilités de la semaine : emploi du temps + rendez-vous pris -->
  <div class="col-lg-7">
    <div class="card h-100">
      <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
        <h3 class="card-title mb-0">Semaine du <?= e($monday->format('d/m/Y')) ?> au <?= e($monday->modify('+5 days')->format('d/m/Y')) ?></h3>
        <div class="btn-group btn-group-sm">
          <a class="btn btn-outline-secondary <?= $isCurrentWeek ? 'disabled' : '' ?>" href="<?= url('admin-availability', $q(['week' => $prev->format('Y-m-d')])) ?>">←</a>
          <a class="btn btn-outline-secondary" href="<?= url('admin-availability', $q()) ?>">Cette semaine</a>
          <a class="btn btn-outline-secondary <?= $isLastWeek ? 'disabled' : '' ?>" href="<?= url('admin-availability', $q(['week' => $next->format('Y-m-d')])) ?>">→</a>
        </div>
      </div>
      <div class="card-body">
        <?php $linkSlots = false; $showPatients = true; require __DIR__ . '/../../../shared/week_grid.php'; ?>
      </div>
    </div>
  </div>
</div>
<?php else: ?>
  <div class="alert alert-warning">Aucun médecin à afficher.</div>
<?php endif; ?>
