<?php /* Propositions ouvertes des autres utilisateurs — contenu seul (layout AdminLTE injecté par Controller::render) */ ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
  <p class="mb-0 text-secondary">Rendez-vous proposés par les autres utilisateurs, en attente d'un médecin.</p>
  <?php if ($doctor): ?>
  <div class="btn-group">
    <a class="btn btn-sm <?= $scope === 'mine' ? 'btn-primary' : 'btn-outline-primary' ?>" href="<?= url('admin-proposals') ?>">Ma spécialité (<?= e($doctor['specialty']) ?>)</a>
    <a class="btn btn-sm <?= $scope === 'all' ? 'btn-primary' : 'btn-outline-primary' ?>" href="<?= url('admin-proposals', ['scope' => 'all']) ?>">Toutes</a>
  </div>
  <?php endif; ?>
</div>
<div class="card"><div class="card-body p-0 table-responsive">
  <table class="table table-hover align-middle mb-0">
    <thead><tr><th>Date souhaitée</th><th>Proposé par</th><th>Spécialité</th><th>Zone</th><th>Motif</th><th class="text-end">Action</th></tr></thead>
    <tbody>
    <?php foreach ($proposals as $a): $sameSpec = $doctor && (int)$a['specialty_id'] === (int)$doctor['specialty_id']; ?>
      <tr>
        <td><?= e(date('d/m/Y H:i', strtotime($a['scheduled_at']))) ?></td>
        <td><?= e($a['patient_name']) ?><br><small class="text-secondary"><?= e($a['patient_phone'] ?: $a['patient_email']) ?></small></td>
        <td><span class="badge text-bg-<?= $sameSpec ? 'info' : 'light' ?>"><?= e($a['specialty']) ?></span></td>
        <td><?= e($a['body_part'] ?? '—') ?></td>
        <td><?= e($a['reason']) ?></td>
        <td class="text-end">
          <?php if ($user['role'] === 'doctor' && $sameSpec): ?>
            <form method="post" action="<?= url('admin-proposals-claim') ?>" class="d-inline" onsubmit="return confirm('Accepter ce rendez-vous ?')">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><input type="hidden" name="scope" value="<?= e($scope) ?>">
              <button class="btn btn-sm btn-success">Accepter</button>
            </form>
          <?php else: ?><span class="text-secondary small"><?= $user['role'] === 'admin' ? 'Lecture seule' : 'Autre spécialité' ?></span><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; if (!$proposals): ?>
      <tr><td colspan="6" class="text-center text-secondary py-4">Aucune proposition en attente.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div></div>
