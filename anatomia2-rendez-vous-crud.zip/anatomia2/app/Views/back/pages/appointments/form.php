<?php $v = fn($k) => e($old[$k] ?? ''); $sel = fn($k, $val) => (string)($old[$k] ?? '') === (string)$val ? 'selected' : ''; ?>
<?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" action="<?= url('admin-appointments-save') ?>" class="card">
  <div class="card-body">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($a['id'] ?? 0) ?>">
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Patient</label>
        <select name="patient_id" class="form-select" required><option value="">—</option>
          <?php foreach ($patients as $p): ?><option value="<?= (int)$p['id'] ?>" <?= $sel('patient_id', $p['id']) ?>><?= e($p['name']) ?> (<?= e($p['email']) ?>)</option><?php endforeach; ?></select></div>
      <div class="col-md-6 mb-3"><label class="form-label">Médecin</label>
        <select name="doctor_id" class="form-select"><option value="">— Aucun (proposition ouverte) —</option>
          <?php foreach ($doctors as $d): ?><option value="<?= (int)$d['id'] ?>" <?= $sel('doctor_id', $d['id']) ?>><?= e($d['name']) ?> — <?= e($d['specialty']) ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="row">
      <div class="col-md-4 mb-3"><label class="form-label">Date et heure (créneaux de 30 min)</label>
        <input type="datetime-local" name="scheduled_at" step="1800" class="form-control" value="<?= $v('scheduled_at') ?>" required></div>
      <div class="col-md-4 mb-3"><label class="form-label">Statut</label>
        <select name="status" class="form-select">
          <?php foreach (['open' => 'Proposition ouverte', 'pending' => 'En attente', 'confirmed' => 'Confirmé', 'done' => 'Terminé', 'cancelled' => 'Annulé'] as $k => $l): ?><option value="<?= $k ?>" <?= $sel('status', $k) ?>><?= $l ?></option><?php endforeach; ?></select></div>
      <div class="col-md-4 mb-3"><label class="form-label">Zone du corps</label>
        <select name="body_part_id" class="form-select"><option value="">—</option>
          <?php foreach ($parts as $b): ?><option value="<?= (int)$b['id'] ?>" <?= $sel('body_part_id', $b['id']) ?>><?= e($b['name']) ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="mb-3"><label class="form-label">Spécialité demandée (si aucun médecin)</label>
      <select name="specialty_id" class="form-select"><option value="">—</option>
        <?php foreach ($specialties as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $sel('specialty_id', $s['id']) ?>><?= e($s['name']) ?></option><?php endforeach; ?></select></div>
    <div class="mb-3"><label class="form-label">Motif</label><textarea name="reason" rows="2" maxlength="255" class="form-control" required><?= $v('reason') ?></textarea></div>
  </div>
  <div class="card-footer"><button class="btn btn-primary">Enregistrer</button> <a class="btn btn-link" href="<?= url('admin-appointments') ?>">Annuler</a></div>
</form>
