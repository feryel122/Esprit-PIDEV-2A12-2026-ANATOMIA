<?php $v = fn($k) => e($old[$k] ?? ''); ?>
<?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" action="<?= url('admin-body-save') ?>" class="card">
  <div class="card-body">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($part['id'] ?? 0) ?>">
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Nom</label><input name="name" class="form-control" value="<?= $v('name') ?>" required></div>
      <div class="col-md-6 mb-3"><label class="form-label">Slug (zone du schéma : tete, thorax…)</label><input name="slug" class="form-control" value="<?= $v('slug') ?>"></div>
    </div>
    <div class="mb-3"><label class="form-label">Résumé</label><input name="summary" class="form-control" maxlength="255" value="<?= $v('summary') ?>" required></div>
    <div class="mb-3"><label class="form-label">Description</label><textarea name="description" rows="4" class="form-control" required><?= $v('description') ?></textarea></div>
    <div class="mb-3"><label class="form-label">Petits maux fréquents</label><textarea name="common_issues" rows="2" class="form-control"><?= $v('common_issues') ?></textarea></div>
    <div class="mb-3"><label class="form-label">Bons réflexes</label><textarea name="prevention" rows="2" class="form-control"><?= $v('prevention') ?></textarea></div>
    <div class="mb-3"><label class="form-label d-block">Spécialités à consulter</label>
      <?php foreach ($specialties as $s): ?>
        <div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="specialties[]" id="sp<?= (int)$s['id'] ?>" value="<?= (int)$s['id'] ?>" <?= in_array((int)$s['id'], array_map('intval', $selected), true) ? 'checked' : '' ?>>
          <label class="form-check-label" for="sp<?= (int)$s['id'] ?>"><?= e($s['name']) ?></label></div>
      <?php endforeach; ?></div>
  </div>
  <div class="card-footer"><button class="btn btn-primary">Enregistrer</button> <a class="btn btn-link" href="<?= url('admin-body') ?>">Annuler</a></div>
</form>
