<footer class="app-footer"><strong>Anatomia</strong> — back office (AdminLTE 4).</footer>
</div><!-- /.app-wrapper -->
