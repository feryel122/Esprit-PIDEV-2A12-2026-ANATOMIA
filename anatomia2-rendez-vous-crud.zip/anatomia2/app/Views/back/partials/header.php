<nav class="app-header navbar navbar-expand bg-body">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item"><a class="nav-link" data-lte-toggle="sidebar" href="#" role="button"><i class="bi bi-list"></i></a></li>
      <li class="nav-item d-none d-md-block"><a href="<?= url('body') ?>" class="nav-link">Voir le site</a></li>
    </ul>
    <ul class="navbar-nav ms-auto">
      <li class="nav-item"><span class="nav-link"><i class="bi bi-person-circle"></i>
        <?= e($user['name']) ?> <span class="badge text-bg-secondary"><?= e($user['role']) ?></span></span></li>
      <li class="nav-item"><a class="nav-link" href="<?= url('logout') ?>" title="Déconnexion"><i class="bi bi-box-arrow-right"></i></a></li>
    </ul>
  </div>
</nav>
