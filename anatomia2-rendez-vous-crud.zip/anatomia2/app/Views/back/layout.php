<?php
/**
 * Layout principal du back office — inclut tous les blocs communs et injecte
 * le contenu propre à chaque page ($content) au milieu.
 *
 * Variables fournies par Controller::render() :
 *   $pageTitle   string  titre de l'onglet <title>
 *   $currentPage string  clé de la page courante (lien actif de la sidebar)
 *   $content     string  HTML de la page, déjà rendu
 *   $user, $flash        utilisateur connecté / message flash
 */
require_once __DIR__ . '/partials/head.php';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/sidebar.php';
?>
<main class="app-main">
  <div class="app-content-header"><div class="container-fluid"><h3 class="mb-0"><?= e($pageTitle) ?></h3></div></div>
  <div class="app-content"><div class="container-fluid">
    <?php if (!empty($flash)): ?>
      <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible" role="alert"><?= e($flash['msg']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button></div>
    <?php endif; ?>
    <?= $content ?>
  </div></div>
</main>
<?php
require_once __DIR__ . '/partials/footer.php';
require_once __DIR__ . '/partials/scripts.php';
