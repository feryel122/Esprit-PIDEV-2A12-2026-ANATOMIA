/**
 * Page « Rendez-vous » — comportement côté navigateur.
 *   #reserver          Étape 1 : spécialité → 2 : médecin (ou « premier médecin disponible »)
 *                      → 3 : jour + créneau → 4 : motif + confirmation
 *   #mes-rendez-vous   Liste, filtres et annulation
 *
 * Source des données (au choix) :
 *   - window.RDV_DATA        → aperçu statique (rendez-vous.html + rendez-vous-data.js)
 *   - sinon fetch(data-api)  → JSON fourni par PHP
 * Aperçu statique : les rendez-vous créés sont gardés dans le localStorage du navigateur.
 * Pré-remplissage possible depuis la page « Corps humain » :  rendez-vous.html?doctor=4&part=1
 *
 * Règles reprises du back-end : lundi → samedi, 8 h → 18 h, créneaux de 30 min,
 * pas de réservation à moins d'une heure, un médecin ne peut pas se réserver lui-même.
 */
(function () {
  'use strict';

  const root = document.getElementById('rdv-app');
  if (!root) return;

  const cfg = {
    api: root.dataset.api || '',
    img: root.dataset.img || 'app/Views/assets/front/img/'
  };
  const STORE_KEY = 'anatomia.rdv.v1';

  const $ = (sel, ctx = root) => ctx.querySelector(sel);
  const $$ = (sel, ctx = root) => Array.from(ctx.querySelectorAll(sel));
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pad = (n) => String(n).padStart(2, '0');
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  const plural = (n, one, many) => `${n} ${n > 1 ? many : one}`;

  /* ---------- dates ---------- */
  const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  /** « 2026-11-24 10:30 » (ou avec T) → Date locale. */
  function parseAt(s) {
    const [d, t] = String(s).split(/[ T]/);
    const [y, m, da] = d.split('-').map(Number);
    const [h, mi] = (t || '00:00').split(':').map(Number);
    return new Date(y, m - 1, da, h, mi);
  }
  const fmtLong = (d) => cap(new Intl.DateTimeFormat('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }).format(d));
  const fmtWd = (d) => new Intl.DateTimeFormat('fr-FR', { weekday: 'short' }).format(d).replace('.', '');
  const fmtMo = (d) => new Intl.DateTimeFormat('fr-FR', { month: 'short' }).format(d).replace('.', '');
  const fmtTime = (d) => `${pad(d.getHours())} h ${pad(d.getMinutes())}`.replace(' 00', '');
  const fmtNumeric = (d) => `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
  const fmtHM = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;

  /* ---------- état ---------- */
  let DATA = null;
  let APPTS = [];
  const blank = () => ({ step: 1, specId: null, mode: null, doctorId: null, date: null, time: null, partId: '', reason: '', done: null, error: '' });
  let S = blank();
  let cancelId = null;

  const doctorById = (id) => DATA.doctors.find((d) => d.id === Number(id)) || null;
  const specById = (id) => DATA.specialties.find((s) => s.id === Number(id)) || null;
  const partById = (id) => DATA.parts.find((p) => p.id === Number(id)) || null;
  const doctorsOf = (specId) => DATA.doctors.filter((d) => d.specialty_id === Number(specId));
  const isMe = (d) => DATA.me && Number(DATA.me.id) === Number(d.id);

  /* ---------- stockage (aperçu statique) ---------- */
  function loadAppts() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) { /* stockage indisponible : on repart des données d'exemple */ }
    return JSON.parse(JSON.stringify(DATA.appointments || []));
  }
  function saveAppts() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(APPTS)); } catch (e) { /* ignoré */ }
  }

  /* ---------- créneaux ---------- */
  function hash(str) {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return Math.abs(h);
  }
  function slotTimes() {
    const { open, close, step } = DATA.hours;
    const out = [];
    for (let m = open * 60; m < close * 60; m += step) out.push(`${pad(Math.floor(m / 60))}:${pad(m % 60)}`);
    return out;
  }
  /** 'free' | 'taken' | 'past' — en aperçu, une part des créneaux d'un médecin est occupée (valeur stable). */
  function slotState(doctorId, dateStr, time) {
    if (parseAt(`${dateStr} ${time}`) < new Date(Date.now() + 3600e3)) return 'past';
    if (doctorId) {
      const key = `${dateStr} ${time}`;
      const clash = APPTS.some((a) => Number(a.doctor_id) === Number(doctorId) && a.status !== 'cancelled'
        && ymd(parseAt(a.scheduled_at)) + ' ' + fmtHM(parseAt(a.scheduled_at)) === key);
      if (clash || hash(`${doctorId}|${key}`) % 100 < 30) return 'taken';
    }
    return 'free';
  }
  const freeCount = (doctorId, dateStr) => slotTimes().filter((t) => slotState(doctorId, dateStr, t) === 'free').length;
  function upcomingDays(n) {
    const out = [];
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    while (out.length < n) {
      if (d.getDay() !== 0) out.push(new Date(d));   // pas de dimanche
      d.setDate(d.getDate() + 1);
    }
    return out;
  }

  /* ---------- validation ---------- */
  function valid(step) {
    if (step === 1) return !!S.specId;
    if (step === 2) return S.mode === 'open' || (S.mode === 'doctor' && !!S.doctorId);
    if (step === 3) return !!S.date && !!S.time;
    return true;
  }

  /* ---------- morceaux d'HTML ---------- */
  function renderSteps() {
    const labels = ['Spécialité', 'Médecin', 'Créneau', 'Confirmation'];
    $('#steps').innerHTML = labels.map((l, i) => {
      const n = i + 1;
      const cls = [S.done || S.step > n ? 'done' : '', !S.done && S.step === n ? 'active' : ''].join(' ');
      const canGo = !S.done && S.step > n;
      return `<li class="${cls}"><button type="button" ${canGo ? `data-go="${n}"` : 'tabindex="-1"'} ${!S.done && S.step === n ? 'aria-current="step"' : ''}><span>${S.done || S.step > n ? '<i class="bi bi-check-lg"></i>' : n}</span> ${l}</button></li>`;
    }).join('');
  }

  function renderSummary() {
    const spec = specById(S.specId);
    const doc = S.mode === 'doctor' ? doctorById(S.doctorId) : null;
    const d = S.date ? parseAt(`${S.date} 00:00`) : null;
    const row = (icon, label, value, extra) =>
      `<li class="${value ? '' : 'todo'}"><i class="bi ${icon}"></i><div><small>${label}</small><strong>${value ? esc(value) : 'À choisir'}</strong>${extra || ''}</div></li>`;

    let docRow;
    if (S.mode === 'open') docRow = row('bi-hourglass-split', 'Médecin', 'Premier médecin disponible');
    else if (doc) docRow = `<li><i class="bi bi-person-circle"></i><div><small>Médecin</small><div class="sum-doc"><img src="${esc(cfg.img + (doc.photo || 'doctors/doctors-1.jpg'))}" alt=""><strong>${esc(doc.name)}</strong></div></div></li>`;
    else docRow = row('bi-person-circle', 'Médecin', '');

    $('#summary').innerHTML = `
      <h2>Votre rendez-vous</h2>
      <ul class="sum-list" aria-live="polite">
        ${row('bi-clipboard2-pulse', 'Spécialité', spec && spec.name)}
        ${docRow}
        ${row('bi-calendar-event', 'Date', d && fmtLong(d))}
        ${row('bi-clock', 'Heure', S.time && fmtTime(parseAt(`2000-01-01 ${S.time}`)))}
      </ul>
      <div class="sum-rules">
        <p><i class="bi bi-info-circle"></i> Du lundi au samedi, de 8 h à 18 h.</p>
        <p>Annulation possible depuis « Mes rendez-vous ».</p>
      </div>`;
  }

  function stepSpecialty() {
    const cards = DATA.specialties.map((s) => {
      const n = doctorsOf(s.id).length;
      return `<div><button type="button" class="spec-card ${S.specId === s.id ? 'selected' : ''}" data-spec="${s.id}" aria-pressed="${S.specId === s.id}">
        <i class="bi ${esc(s.icon || 'bi-heart-pulse')}"></i>
        <span><strong>${esc(s.name)}</strong><small>${n ? plural(n, 'médecin', 'médecins') : 'Sur proposition'}</small></span>
      </button></div>`;
    }).join('');
    return `<h2 tabindex="-1">Quelle spécialité cherchez-vous ?</h2>
      <p class="rdv-lead">Pas sûr ? Un médecin généraliste peut vous orienter.</p>
      <div class="spec-grid">${cards}</div>`;
  }

  function stepDoctor() {
    const spec = specById(S.specId);
    const docs = doctorsOf(S.specId);
    const cards = docs.map((d) => {
      const me = isMe(d);
      return `<button type="button" class="doctor-pick ${S.mode === 'doctor' && S.doctorId === d.id ? 'selected' : ''}" data-doctor="${d.id}"
          aria-pressed="${S.mode === 'doctor' && S.doctorId === d.id}" ${me ? 'disabled' : ''}>
        <img src="${esc(cfg.img + (d.photo || 'doctors/doctors-1.jpg'))}" alt="">
        <span><strong>${esc(d.name)}</strong><span class="spec">${esc(d.spec)}</span> · <small><i class="bi bi-geo-alt"></i> ${esc(d.city)}</small>
        <p>${esc(d.bio || '')}${me ? ' <em>C\'est votre profil.</em>' : ''}</p></span>
      </button>`;
    }).join('');
    const openCard = `<button type="button" class="doctor-pick open-card ${S.mode === 'open' ? 'selected' : ''}" data-open="1" aria-pressed="${S.mode === 'open'}">
        <span class="doc-icon"><i class="bi bi-hourglass-split"></i></span>
        <span><strong>Premier médecin disponible</strong>
        <p>Publiez une proposition de créneau : le premier médecin en ${esc(spec.name)} qui l'accepte la confirme.</p></span>
      </button>`;
    return `<h2 tabindex="-1">Avec quel médecin ?</h2>
      <p class="rdv-lead">${docs.length ? `Spécialité : <strong>${esc(spec.name)}</strong>.` : `Aucun médecin n'est encore référencé en ${esc(spec.name)}, mais vous pouvez publier une proposition.`}</p>
      <div class="doc-list">${cards}${openCard}</div>`;
  }

  function stepSlot() {
    const docId = S.mode === 'doctor' ? S.doctorId : null;
    const days = upcomingDays(12);
    if (!S.date || !days.some((d) => ymd(d) === S.date)) {
      const first = days.find((d) => freeCount(docId, ymd(d)) > 0);
      S.date = first ? ymd(first) : null;
      S.time = null;
    }
    const strip = days.map((d) => {
      const key = ymd(d);
      const n = freeCount(docId, key);
      return `<button type="button" class="day-btn ${S.date === key ? 'selected' : ''}" data-day="${key}" ${n ? '' : 'disabled'} aria-pressed="${S.date === key}"
          aria-label="${esc(fmtLong(d))}, ${n ? plural(n, 'créneau libre', 'créneaux libres') : 'complet'}">
        <span class="wd">${esc(fmtWd(d))}</span><span class="num">${d.getDate()}</span><span class="mo">${esc(fmtMo(d))}</span>
        <span class="free">${n ? plural(n, 'libre', 'libres') : 'complet'}</span></button>`;
    }).join('');

    const times = slotTimes();
    const group = (title, list) => `<div class="slot-group"><h3>${title}</h3><div class="slot-grid">${list.map((t) => {
      const st = S.date ? slotState(docId, S.date, t) : 'past';
      return `<button type="button" class="slot" data-time="${t}" aria-pressed="${S.time === t}" ${st === 'free' ? '' : 'disabled'}
        ${st === 'taken' ? 'title="Déjà réservé"' : ''}>${t}</button>`;
    }).join('')}</div></div>`;

    const body = S.date
      ? `${group('Matin', times.filter((t) => t < '12:00'))}${group('Après-midi', times.filter((t) => t >= '12:00'))}
         <div class="slot-legend"><span><i></i>Libre</span><span><i class="sel"></i>Votre choix</span><span><i class="off"></i>Réservé ou passé</span></div>`
      : '<div class="rdv-empty mt-3"><i class="bi bi-calendar-x"></i><p>Aucun créneau libre dans les deux prochaines semaines.</p></div>';

    const who = S.mode === 'open' ? 'Les médecins de la spécialité verront votre proposition.' : `Créneaux de ${esc(doctorById(S.doctorId).name)}.`;
    return `<h2 tabindex="-1">Choisissez un jour et une heure</h2>
      <p class="rdv-lead">${who}</p>
      <div class="day-strip" role="group" aria-label="Jours disponibles">${strip}</div>${body}`;
  }

  function stepConfirm() {
    const spec = specById(S.specId);
    const doc = S.mode === 'doctor' ? doctorById(S.doctorId) : null;
    const when = parseAt(`${S.date} ${S.time}`);
    const parts = DATA.parts.map((p) => `<option value="${p.id}" ${String(S.partId) === String(p.id) ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    return `<h2 tabindex="-1">Dites-nous pourquoi vous consultez</h2>
      <p class="rdv-lead">Quelques mots suffisent, le médecin les verra avant la consultation.</p>
      <form id="rdv-form" novalidate>
        <div class="mb-3"><label class="form-label" for="part">Zone concernée <span class="text-muted fw-normal">(facultatif)</span></label>
          <select class="form-select" id="part" name="part"><option value="">— Aucune —</option>${parts}</select></div>
        <div class="mb-1"><label class="form-label" for="reason">Motif de la consultation</label>
          <textarea class="form-control ${S.error ? 'is-invalid' : ''}" id="reason" name="reason" rows="3" maxlength="255" required
            aria-describedby="reason-help">${esc(S.reason)}</textarea>
          <div class="invalid-feedback" id="reason-err">${esc(S.error)}</div></div>
        <div class="char-count" id="reason-help"><span id="count">${S.reason.length}</span> / 255</div>
        <div class="recap">
          <p><strong>${doc ? esc(doc.name) : 'Premier médecin disponible'}</strong> — ${esc(spec.name)}</p>
          <p><i class="bi bi-calendar-event"></i> ${esc(fmtLong(when))} à ${esc(fmtTime(when))}</p>
        </div>
      </form>`;
  }

  function stepSuccess() {
    const a = S.done;
    const when = parseAt(a.scheduled_at);
    const open = a.status === 'open';
    return `<div class="rdv-success">
      <i class="bi bi-check-circle-fill"></i>
      <h2 tabindex="-1">${open ? 'Proposition publiée' : 'Demande envoyée'}</h2>
      <p class="rdv-lead mb-0">${open ? 'Un médecin de la spécialité va l\'accepter. Vous la retrouvez dans « Mes rendez-vous ».'
        : `${esc(a.doctor_name)} doit maintenant confirmer votre demande.`}</p>
      <div class="recap">
        <p><strong>${a.doctor_name ? esc(a.doctor_name) : 'Premier médecin disponible'}</strong> — ${esc(a.specialty)}</p>
        <p><i class="bi bi-calendar-event"></i> ${esc(fmtLong(when))} à ${esc(fmtTime(when))}</p>
        <p><i class="bi bi-chat-left-text"></i> ${esc(a.reason)}</p>
      </div>
      <div class="actions">
        <a class="btn-anat text-decoration-none" href="#mes-rendez-vous">Voir mes rendez-vous</a>
        <button type="button" class="btn-ghost" data-act="ics"><i class="bi bi-calendar-plus"></i> Ajouter à mon agenda</button>
        <button type="button" class="btn-ghost" data-act="again">Prendre un autre rendez-vous</button>
      </div>
    </div>`;
  }

  /* ---------- assistant ---------- */
  function renderBook(focus) {
    renderSteps();
    renderSummary();
    let html;
    if (S.done) html = stepSuccess();
    else {
      html = [stepSpecialty, stepDoctor, stepSlot, stepConfirm][S.step - 1]();
      if (S.step < 4) {
        html += `<div class="rdv-nav">
          ${S.step > 1 ? '<button type="button" class="btn-ghost" data-act="back"><i class="bi bi-arrow-left"></i> Retour</button>' : '<span></span>'}
          <button type="button" class="btn-anat" data-act="next" ${valid(S.step) ? '' : 'disabled'}>Continuer</button></div>`;
      } else {
        html += `<div class="rdv-nav">
          <button type="button" class="btn-ghost" data-act="back"><i class="bi bi-arrow-left"></i> Retour</button>
          <button type="submit" class="btn-anat" form="rdv-form">${S.mode === 'open' ? 'Publier la proposition' : 'Envoyer la demande'}</button></div>`;
      }
    }
    $('#panel').innerHTML = html;
    if (focus) { const h = $('#panel h2'); if (h) h.focus({ preventScroll: true }); }
  }

  function goTo(step, focus = true) {
    S.step = step;
    S.error = '';
    renderBook(focus);
    if (focus) $('#panel').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'nearest' });
  }

  function submit() {
    const reason = $('#reason').value.trim();
    S.reason = $('#reason').value;
    S.partId = $('#part').value;
    if (!reason) {
      S.error = 'Indiquez le motif de la consultation.';
      renderBook(false);
      $('#reason').focus();
      return;
    }
    const doc = S.mode === 'doctor' ? doctorById(S.doctorId) : null;
    const part = partById(S.partId);
    const a = {
      id: APPTS.reduce((m, x) => Math.max(m, x.id), 0) + 1,
      doctor_id: doc ? doc.id : null,
      doctor_name: doc ? doc.name : null,
      specialty: specById(S.specId).name,
      body_part: part ? part.name : null,
      scheduled_at: `${S.date} ${S.time}`,
      reason: reason.slice(0, 255),
      status: doc ? 'pending' : 'open'
    };
    APPTS.push(a);
    saveAppts();
    S.done = a;
    renderBook(true);
    updateMineBadge();
  }

  function downloadIcs(a) {
    const s = parseAt(a.scheduled_at);
    const e = new Date(s.getTime() + DATA.hours.step * 60000);
    const f = (d) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}00`;
    const txt = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Anatomia//Rendez-vous//FR', 'BEGIN:VEVENT',
      `UID:rdv-${a.id}@anatomia`, `DTSTAMP:${f(new Date())}`, `DTSTART:${f(s)}`, `DTEND:${f(e)}`,
      `SUMMARY:Consultation ${a.specialty}${a.doctor_name ? ' - ' + a.doctor_name : ''}`,
      `DESCRIPTION:${String(a.reason).replace(/[\r\n]+/g, ' ')}`, 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
    const url = URL.createObjectURL(new Blob([txt], { type: 'text/calendar' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'rendez-vous-anatomia.ics';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  /* ---------- Mes rendez-vous ---------- */
  let filter = 'all';
  const ACTIVE = ['open', 'pending', 'confirmed'];
  const FILTERS = {
    all:       { label: 'Tous',      test: () => true },
    upcoming:  { label: 'À venir',   test: (a) => ACTIVE.includes(a.status) && parseAt(a.scheduled_at) >= new Date() },
    past:      { label: 'Passés',    test: (a) => a.status === 'done' || (a.status !== 'cancelled' && parseAt(a.scheduled_at) < new Date()) },
    cancelled: { label: 'Annulés',   test: (a) => a.status === 'cancelled' }
  };
  const STATUS = {
    open: ['Proposition ouverte', 'info'], pending: ['En attente', 'warning'], confirmed: ['Confirmé', 'success'],
    cancelled: ['Annulé', 'danger'], done: ['Terminé', 'secondary']
  };

  function renderMine() {
    const sorted = APPTS.slice().sort((a, b) => parseAt(b.scheduled_at) - parseAt(a.scheduled_at));
    $('#mine-filters').innerHTML = Object.keys(FILTERS).map((k) =>
      `<button type="button" class="rdv-chip ${filter === k ? 'active' : ''}" data-filter="${k}" aria-pressed="${filter === k}">${FILTERS[k].label}<small>${sorted.filter(FILTERS[k].test).length}</small></button>`).join('');

    const list = sorted.filter(FILTERS[filter].test);
    if (!APPTS.length) {
      $('#mine-panel').innerHTML = `<div class="rdv-empty"><i class="bi bi-calendar2-x"></i>
        <h2 class="h5 mt-2">Aucun rendez-vous pour le moment</h2>
        <p>Choisissez une spécialité et un créneau en quelques clics.</p>
        <a class="btn-anat d-inline-block text-decoration-none mt-3" href="#reserver">Prendre rendez-vous</a></div>`;
      return;
    }
    if (!list.length) {
      $('#mine-panel').innerHTML = `<div class="rdv-empty"><i class="bi bi-inbox"></i><p>Aucun rendez-vous dans cette catégorie.</p></div>`;
      return;
    }
    const rows = list.map((a) => {
      const w = parseAt(a.scheduled_at);
      const [lbl, cls] = STATUS[a.status] || [a.status, 'light'];
      return `<tr class="${a.status === 'cancelled' ? 'is-cancelled' : ''}">
        <td class="when">${fmtNumeric(w)}<small>${fmtHM(w)}</small></td>
        <td>${a.doctor_name ? esc(a.doctor_name) : '<em>Premier médecin disponible</em>'}<br><small class="text-muted">${esc(a.specialty)}</small></td>
        <td>${esc(a.body_part || '—')}</td>
        <td>${esc(a.reason)}</td>
        <td><span class="badge text-bg-${cls}">${lbl}</span></td>
        <td class="text-end">${ACTIVE.includes(a.status) && w >= new Date() ? `<button type="button" class="btn btn-sm btn-outline-danger" data-cancel="${a.id}">Annuler</button>` : ''}</td>
      </tr>`;
    }).join('');
    $('#mine-panel').innerHTML = `<div class="table-responsive mine-table"><table class="table align-middle">
      <thead><tr><th>Date</th><th>Médecin</th><th>Zone</th><th>Motif</th><th>Statut</th><th></th></tr></thead>
      <tbody>${rows}</tbody></table></div>`;
  }

  function updateMineBadge() {
    const n = APPTS.filter(FILTERS.upcoming.test).length;
    const el = document.getElementById('mine-count');
    if (el) el.textContent = n ? `(${n})` : '';
  }

  function flash(msg, type) {
    const box = document.getElementById('flash');
    if (!box) return;
    box.innerHTML = `<div class="alert alert-${type || 'success'} alert-dismissible mb-0 rounded-0 text-center flash-bar" role="alert">
      ${esc(msg)}<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button></div>`;
  }

  /* ---------- navigation ---------- */
  function route() {
    const view = location.hash === '#mes-rendez-vous' ? 'mine' : 'book';
    $$('[data-view]').forEach((el) => { el.hidden = el.dataset.view !== view; });
    document.querySelectorAll('#navmenu a[data-nav]').forEach((a) => a.classList.toggle('active', a.dataset.nav === view));
    $('#steps').hidden = view !== 'book';
    $('#page-title').textContent = view === 'book' ? 'Prendre rendez-vous' : 'Mes rendez-vous';
    $('#page-sub').textContent = view === 'book'
      ? 'Choisissez une spécialité, un médecin et un créneau libre. Consultations du lundi au samedi, de 8 h à 18 h.'
      : 'Retrouvez vos demandes, leur statut et annulez celles que vous ne pouvez plus honorer.';
    document.title = (view === 'book' ? 'Prendre rendez-vous' : 'Mes rendez-vous') + ' — Anatomia';
    if (view === 'book') renderBook(false); else renderMine();
  }

  function prefillFromUrl() {
    const q = new URLSearchParams(location.search);
    const doc = doctorById(q.get('doctor'));
    if (doc && !isMe(doc)) {
      S.specId = doc.specialty_id; S.mode = 'doctor'; S.doctorId = doc.id; S.step = 3;
    } else if (specById(q.get('specialty'))) {
      S.specId = Number(q.get('specialty')); S.step = 2;
    }
    if (partById(q.get('part'))) S.partId = String(q.get('part'));
  }

  /* ---------- événements ---------- */
  root.addEventListener('click', (e) => {
    const t = e.target.closest('button, a');
    if (!t) return;

    if (t.dataset.go) return goTo(Number(t.dataset.go));
    if (t.dataset.spec) {
      const id = Number(t.dataset.spec);
      if (S.specId !== id) { S.specId = id; S.mode = null; S.doctorId = null; S.date = null; S.time = null; }
      return goTo(2);
    }
    if (t.dataset.doctor) {
      const id = Number(t.dataset.doctor);
      if (S.mode !== 'doctor' || S.doctorId !== id) { S.mode = 'doctor'; S.doctorId = id; S.date = null; S.time = null; }
      return goTo(3);
    }
    if (t.dataset.open) {
      if (S.mode !== 'open') { S.mode = 'open'; S.doctorId = null; S.date = null; S.time = null; }
      return goTo(3);
    }
    if (t.dataset.day) { S.date = t.dataset.day; S.time = null; return renderBook(false); }
    if (t.dataset.time) { S.time = t.dataset.time; renderBook(false); const n = $('[data-act="next"]'); if (n) n.focus({ preventScroll: true }); return; }
    if (t.dataset.filter) { filter = t.dataset.filter; return renderMine(); }
    if (t.dataset.cancel) {
      cancelId = Number(t.dataset.cancel);
      const a = APPTS.find((x) => x.id === cancelId);
      document.getElementById('cancel-what').textContent = a ? `${fmtNumeric(parseAt(a.scheduled_at))} à ${fmtHM(parseAt(a.scheduled_at))} — ${a.doctor_name || a.specialty}` : '';
      return bootstrap.Modal.getOrCreateInstance(document.getElementById('cancelModal')).show();
    }

    switch (t.dataset.act) {
      case 'next':  if (valid(S.step)) goTo(S.step + 1); break;
      case 'back':  goTo(Math.max(1, S.step - 1)); break;
      case 'again': S = blank(); goTo(1); break;
      case 'ics':   downloadIcs(S.done); break;
    }
  });

  // Lien « réinitialiser la démo » (dans le pied de page, hors de #rdv-app)
  document.addEventListener('click', (e) => {
    if (!e.target.closest('[data-act="reset"]')) return;
    e.preventDefault();
    try { localStorage.removeItem(STORE_KEY); } catch (err) { /* ignoré */ }
    location.hash = '#reserver';
    location.reload();
  });

  root.addEventListener('submit', (e) => {
    if (e.target.id === 'rdv-form') { e.preventDefault(); submit(); }
  });
  root.addEventListener('input', (e) => {
    if (e.target.id !== 'reason') return;
    S.reason = e.target.value;
    $('#count').textContent = S.reason.length;
    if (S.error && S.reason.trim()) {
      S.error = '';
      e.target.classList.remove('is-invalid');
    }
  });
  root.addEventListener('change', (e) => { if (e.target.id === 'part') S.partId = e.target.value; });

  document.getElementById('cancel-confirm').addEventListener('click', () => {
    const a = APPTS.find((x) => x.id === cancelId);
    if (a) { a.status = 'cancelled'; saveAppts(); }
    bootstrap.Modal.getOrCreateInstance(document.getElementById('cancelModal')).hide();
    cancelId = null;
    renderMine();
    updateMineBadge();
    flash('Le rendez-vous a été annulé.', 'success');
  });
  window.addEventListener('hashchange', route);

  /* ---------- démarrage ---------- */
  function start(data) {
    DATA = data;
    APPTS = loadAppts();
    prefillFromUrl();
    updateMineBadge();
    route();
  }

  if (window.RDV_DATA) {
    start(window.RDV_DATA);
  } else if (cfg.api) {
    fetch(cfg.api, { headers: { Accept: 'application/json' } })
      .then((r) => { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(start)
      .catch(() => {
        $('#panel').innerHTML = '<div class="rdv-empty"><p class="mb-0">Impossible de charger les données. Réessayez dans un instant.</p></div>';
      });
  }
})();
