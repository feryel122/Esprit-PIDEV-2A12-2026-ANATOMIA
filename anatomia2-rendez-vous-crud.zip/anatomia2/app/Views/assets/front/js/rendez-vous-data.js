/* Données d'exemple pour l'aperçu statique (rendez-vous.html).
   Dans l'application PHP, ces données viendraient d'une route JSON (attribut data-api de #rdv-app).
   Les identifiants reprennent ceux de database/install.php (Sana = 2, Dr Amel = 4, …). */
(function () {
  'use strict';

  const pad = (n) => String(n).padStart(2, '0');
  /** « YYYY-MM-DD HH:MM » à J+jours, à l'heure h:m (même format que la colonne scheduled_at). */
  function at(days, h, m) {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(h)}:${pad(m || 0)}`;
  }

  window.RDV_DATA = {
    me: { id: 2, name: 'Sana Ben Ali' },

    // Consultations du lundi au samedi, de 8 h à 18 h, créneaux de 30 min.
    hours: { open: 8, close: 18, step: 30 },

    specialties: [
      { id: 1,  name: 'Médecine générale',  icon: 'bi-clipboard2-pulse' },
      { id: 2,  name: 'Neurologie',         icon: 'bi-lightning-charge' },
      { id: 3,  name: 'Cardiologie',        icon: 'bi-heart-pulse' },
      { id: 4,  name: 'Pneumologie',        icon: 'bi-lungs' },
      { id: 5,  name: 'Gastro-entérologie', icon: 'bi-cup-hot' },
      { id: 6,  name: 'ORL',                icon: 'bi-ear' },
      { id: 7,  name: 'Orthopédie',         icon: 'bi-person-walking' },
      { id: 8,  name: 'Dermatologie',       icon: 'bi-bandaid' },
      { id: 9,  name: 'Podologie',          icon: 'bi-person-standing' },
      { id: 10, name: 'Ophtalmologie',      icon: 'bi-eye' }
    ],

    doctors: [
      { id: 4, name: 'Dr Amel Gharbi',   specialty_id: 2, spec: 'Neurologie',         city: 'Tunis',  bio: 'Neurologue, migraines et troubles du sommeil.', photo: 'doctors/doctors-1.jpg' },
      { id: 5, name: 'Dr Karim Mansour', specialty_id: 3, spec: 'Cardiologie',        city: 'Tunis',  bio: 'Cardiologue, prévention cardiovasculaire.',     photo: 'doctors/doctors-2.jpg' },
      { id: 6, name: 'Dr Leila Jaziri',  specialty_id: 5, spec: 'Gastro-entérologie', city: 'Ariana', bio: 'Digestion, reflux, intestin irritable.',        photo: 'doctors/doctors-3.jpg' },
      { id: 7, name: 'Dr Walid Chaouch', specialty_id: 7, spec: 'Orthopédie',         city: 'Sousse', bio: 'Douleurs articulaires et sport.',               photo: 'doctors/doctors-4.jpg' },
      { id: 8, name: 'Dr Nour Haddad',   specialty_id: 1, spec: 'Médecine générale',  city: 'Tunis',  bio: 'Médecin généraliste, suivi de famille.',        photo: 'doctors/doctors-1.jpg' }
    ],

    parts: [
      { id: 1, name: 'Tête' },
      { id: 2, name: 'Cou et gorge' },
      { id: 3, name: 'Thorax' },
      { id: 4, name: 'Abdomen' },
      { id: 5, name: 'Bras' },
      { id: 6, name: 'Mains et poignets' },
      { id: 7, name: 'Jambes' },
      { id: 8, name: 'Pieds' }
    ],

    // Rendez-vous déjà pris par l'utilisateur connecté (reprend les données de démo de install.php).
    appointments: [
      { id: 1, doctor_id: 4,    doctor_name: 'Dr Amel Gharbi', specialty: 'Neurologie',         body_part: 'Tête',    scheduled_at: at(3, 10, 0),  reason: 'Migraines fréquentes',      status: 'pending' },
      { id: 2, doctor_id: null, doctor_name: null,             specialty: 'Gastro-entérologie', body_part: 'Abdomen', scheduled_at: at(5, 15, 30), reason: 'Reflux après les repas',    status: 'open' },
      { id: 3, doctor_id: 8,    doctor_name: 'Dr Nour Haddad', specialty: 'Médecine générale',  body_part: null,      scheduled_at: at(-12, 9, 0), reason: 'Bilan annuel',              status: 'done' },
      { id: 4, doctor_id: 5,    doctor_name: 'Dr Karim Mansour', specialty: 'Cardiologie',      body_part: 'Thorax',  scheduled_at: at(-30, 11, 30), reason: 'Palpitations à l\'effort', status: 'cancelled' }
    ]
  };
})();
