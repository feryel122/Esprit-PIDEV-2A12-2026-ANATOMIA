<?php
// Configuration — adapter à votre XAMPP/WAMP (ou variables d'environnement).
return [
    'db' => [
        'dsn'  => getenv('ANATOMIA_DSN')  ?: 'mysql:host=127.0.0.1;dbname=anatomia;charset=utf8mb4',
        'user' => getenv('ANATOMIA_USER') ?: 'root',
        'pass' => getenv('ANATOMIA_PASS') ?: '',
    ],
];
