# Anatomia — module « Corps humain » + Rendez-vous (module 07)

PHP MVC suivant l'atelier « Intégration Template » · Front Office **MediLab** · Back Office **AdminLTE 4** · MySQL/MariaDB.

## Lancer
1. Adapter `app/config.php` (MySQL), puis : `php database/install.php` (tables + données de démo).
   *Base déjà installée ?* ne relancez pas `install.php` (il efface les données) : lancez `php database/add_availability.php` (ajoute la table des disponibilités + un emploi du temps par défaut).
2. `php -S localhost:8000` à la racine, ouvrir `http://localhost:8000/index.php?page=body`
   (ou copier le dossier dans `htdocs` : `http://localhost/anatomia/index.php?page=body`).

| Rôle | Email | Mot de passe |
|---|---|---|
| Admin | admin@anatomia.tn | admin123 |
| Patient | sana@anatomia.tn | user123 |
| Médecin | amel@anatomia.tn (aussi karim@, leila@, walid@, nour@) | doctor123 |

## Structure (conforme à l'atelier)
```
index.php                      contrôleur frontal  (?page=<clé>)
app/routes.php                 clé de page -> [Controller, méthode]
app/helpers.php                url(), navActive(), flash(), csrf…
app/Controllers/               Controller.php (render + layout), Body, Appointment, Auth, Admin*
app/Models/                    Database, Auth, User, BodyPart, Appointment
app/Views/front/               pages MediLab : chaque page fait require_once includes/*
app/Views/front/includes/      head, spinner, navbar (lien .active via navActive), footer (+ back to top), scripts
app/Views/back/layout.php      assemble les partials et injecte $content (AdminLTE)
app/Views/back/partials/       head, header, sidebar (lien actif via $currentPage), footer, scripts
app/Views/back/pages/          contenu seul des pages back office
app/Views/assets/{front,back}  assets MediLab / AdminLTE
```

## Fonctionnalités
- **Corps humain** : schéma SVG cliquable → fiche (rôle, petits maux, bons réflexes) → médecins des spécialités concernées.
- **Rendez-vous** : réservation chez un médecin (créneau libre, lun–sam 8 h–18 h, pas d'auto-réservation), liste et annulation.
- **Propositions ouvertes** : un utilisateur (médecin compris) propose un rendez-vous sans choisir de médecin (`?page=appointment-propose`, statut `open`, `doctor_id` NULL, `specialty_id` renseigné).
  Les médecins voient les propositions des **autres** utilisateurs dans le back office (`?page=admin-proposals`, sa spécialité par défaut, bouton « Toutes ») et un seul peut l'**accepter** (UPDATE conditionnel -> statut `confirmed`).
- **Médecins = utilisateurs** : `users.role='doctor'` + profil 1-1 dans `doctors`. Le médecin voit ses rendez-vous reçus dans le back office
  (confirmer / annuler / terminer) et peut aussi réserver chez un confrère. L'admin voit tous les rendez-vous et gère les fiches du corps.
- **Disponibilités** (tableau ajouté au module) : emploi du temps hebdomadaire des médecins (table `doctor_schedules`, plusieurs plages par jour) croisé avec les rendez-vous pris pour afficher les créneaux de 30 min **libres / occupés**.
  - Front (public) : `?page=availability` — tableau de tous les médecins (filtre par spécialité, emploi du temps, 3 prochains créneaux libres cliquables) ; `?page=availability-show&doctor=ID` — planning d'une semaine, navigation semaine par semaine, clic sur un créneau libre → formulaire de réservation pré-rempli.
  - Back office : `?page=admin-availability` — le **médecin** gère son emploi du temps (ajout/suppression de plages, 8 h–18 h par pas de 30 min, sans chevauchement) et voit sa semaine avec le nom des patients ; l'**admin** voit le tableau récapitulatif de tous les médecins et peut modifier l'emploi du temps de chacun.
  - La réservation chez un médecin vérifie maintenant que le créneau est dans son emploi du temps.
- **CRUD complet** :
  - *Rendez-vous* : créer (front : `appointment-new` / `appointment-propose` ; back admin : `admin-appointments-create`), lire (`appointment-mine`, `admin-appointments`), **modifier** (patient : date + motif tant que le rendez-vous est en attente ; admin : tous les champs), **supprimer** (patient : ses rendez-vous annulés ; admin : tous) + changement de statut (confirmer / terminer / annuler).
  - *Médecins* (admin) : `?page=admin-doctors` — ajouter, modifier, supprimer (refusé s'il reste des rendez-vous à venir) ; un médecin = ligne `users` (role `doctor`) + profil `doctors`.
- **JOIN** : `Appointment::SELECT` joint `appointments` ↔ `users` (patient et médecin) ↔ `doctors` ↔ `specialties` ↔ `body_parts` ; `Doctor::all()` joint `doctors` ↔ `users` ↔ `specialties`.
- **Règle métier — un médecin ne peut pas avoir deux rendez-vous en même temps** : (1) créneaux de 30 min alignés (`Appointment::isAligned`), (2) chevauchement refusé (`Appointment::isFree`), (3) créneau dans l'emploi du temps (`Availability::isWorking`), (4) un médecin qui réserve chez un confrère ne doit pas être pris dans son propre agenda, (5) filet de sécurité en base : `UNIQUE (doctor_id, scheduled_at)`, l'erreur de course est interceptée et affichée. Appliquée à la réservation, à la modification, à l'acceptation d'une proposition et à la saisie admin.
- Sécurité : mots de passe hachés, PDO préparé, échappement, CSRF, contrôle des rôles.

## Diagrammes
`docs/usecase.puml`, `docs/class.puml` (PlantUML).
