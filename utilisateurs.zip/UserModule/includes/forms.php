<?php
/**
 * Petits générateurs de champs de formulaire (Front Office et Back Office AdminLTE).
 * Chaque champ affiche l'erreur serveur et prévoit un emplacement pour l'erreur JavaScript
 * (<p data-error-for="nom">) ; l'attribut data-rules alimente View/Assets/js/validation.js.
 */

function formUi($ui)
{
    return $ui === 'admin'
        ? ['label' => 'form-label', 'input' => 'form-control', 'select' => 'form-select', 'error' => 'invalid-feedback d-block field-error']
        : ['label' => 'field-label', 'input' => '', 'select' => '', 'error' => 'field-error'];
}

function formWrapClass($o)
{
    if (($o['ui'] ?? 'front') === 'admin') {
        return $o['col'] ?? 'col-md-6';
    }
    return 'field' . (!empty($o['full']) ? ' full' : '');
}

function formAttrs($o)
{
    $attrs = '';
    foreach (['maxlength', 'placeholder', 'step', 'min', 'max', 'autocomplete', 'accept', 'rows', 'id'] as $a) {
        if (isset($o[$a])) {
            $attrs .= ' ' . $a . '="' . e($o[$a]) . '"';
        }
    }
    if (!empty($o['rules'])) {
        $attrs .= ' data-rules="' . e($o['rules']) . '"';
    }
    if (!empty($o['role_toggle'])) {
        $attrs .= ' data-role-select';
    }
    if (!empty($o['required'])) {
        $attrs .= ' required';
    }
    if (!empty($o['disabled'])) {
        $attrs .= ' disabled';
    }
    return $attrs;
}

function formLabel($name, $label, $o, $c)
{
    $star = !empty($o['required']) ? ' <span class="req">*</span>' : '';
    return '<label class="' . $c['label'] . '" for="' . e($o['id'] ?? $name) . '">' . e($label) . $star . '</label>';
}

function formTail($name, $errors, $o, $c)
{
    $hint = isset($o['hint']) ? '<small class="field-hint">' . e($o['hint']) . '</small>' : '';
    return $hint . '<p class="' . $c['error'] . '" data-error-for="' . e($name) . '">'
        . (isset($errors[$name]) ? e($errors[$name]) : '') . '</p></div>';
}

function formClass($base, $name, $errors)
{
    $cls = trim($base . (isset($errors[$name]) ? ' is-invalid' : ''));
    return $cls !== '' ? ' class="' . $cls . '"' : '';
}

function formInput($name, $label, $value, array $errors, array $o = [])
{
    $c = formUi($o['ui'] ?? 'front');
    $type = $o['type'] ?? 'text';
    $o['id'] = $o['id'] ?? $name;
    $val = ($type === 'password' || $type === 'file') ? '' : ' value="' . e($value) . '"';
    return '<div class="' . formWrapClass($o) . '">' . formLabel($name, $label, $o, $c)
        . '<input type="' . e($type) . '" name="' . e($name) . '"' . formClass($c['input'], $name, $errors)
        . formAttrs($o) . $val . '>' . formTail($name, $errors, $o, $c);
}

function formSelect($name, $label, $value, array $errors, array $options, array $o = [])
{
    $c = formUi($o['ui'] ?? 'front');
    $o['id'] = $o['id'] ?? $name;
    $html = '<div class="' . formWrapClass($o) . '">' . formLabel($name, $label, $o, $c)
        . '<select name="' . e($name) . '"' . formClass($c['select'], $name, $errors) . formAttrs($o) . '>';
    if (isset($o['empty'])) {
        $html .= '<option value="">' . e($o['empty']) . '</option>';
    }
    foreach ($options as $optValue => $optLabel) {
        $sel = ((string) $optValue === (string) $value) ? ' selected' : '';
        $html .= '<option value="' . e($optValue) . '"' . $sel . '>' . e($optLabel) . '</option>';
    }
    return $html . '</select>' . formTail($name, $errors, $o, $c);
}

function formTextarea($name, $label, $value, array $errors, array $o = [])
{
    $c = formUi($o['ui'] ?? 'front');
    $o['id'] = $o['id'] ?? $name;
    return '<div class="' . formWrapClass($o) . '">' . formLabel($name, $label, $o, $c)
        . '<textarea name="' . e($name) . '"' . formClass($c['input'], $name, $errors) . formAttrs($o) . '>'
        . e($value) . '</textarea>' . formTail($name, $errors, $o, $c);
}

/** Liste associative valeur => libellé pour la liste des spécialités. */
function specialiteOptions()
{
    return array_combine(SPECIALITES, SPECIALITES);
}

function genreOptions()
{
    return ['femme' => 'Femme', 'homme' => 'Homme', 'autre' => 'Autre'];
}

/** Badge de statut de vérification d'un médecin (Front Office : classes CSS maison). */
function verificationLabel($status)
{
    return ['en_attente' => 'En attente de validation', 'verifie' => 'Vérifié', 'refuse' => 'Refusé'][$status] ?? '—';
}

function fmtDate($value, $withTime = false)
{
    $t = $value ? strtotime($value) : false;
    return $t ? date($withTime ? 'd/m/Y H:i' : 'd/m/Y', $t) : '—';
}

function orDash($value)
{
    return ($value === null || $value === '') ? '—' : $value;
}

function initials($user)
{
    return mb_strtoupper(mb_substr($user['prenom'] ?? '', 0, 1) . mb_substr($user['nom'] ?? '', 0, 1));
}

/* ---------- Badges Back Office (Bootstrap / AdminLTE) ---------- */

function badgeVerification($status)
{
    $map = ['en_attente' => 'text-bg-warning', 'verifie' => 'text-bg-success', 'refuse' => 'text-bg-danger'];
    if (!isset($map[$status])) {
        return '<span class="text-muted">—</span>';
    }
    return '<span class="badge ' . $map[$status] . '">' . e(verificationLabel($status)) . '</span>';
}

function badgeAccount($status)
{
    return $status === 'actif'
        ? '<span class="badge text-bg-success">Actif</span>'
        : '<span class="badge text-bg-secondary">Désactivé</span>';
}

function badgeRole($role)
{
    $map = ['admin' => ['text-bg-dark', 'Administrateur'], 'medecin' => ['text-bg-info', 'Médecin'], 'utilisateur' => ['text-bg-primary', 'Utilisateur']];
    $r = $map[$role] ?? ['text-bg-light', $role];
    return '<span class="badge ' . $r[0] . '">' . e($r[1]) . '</span>';
}
