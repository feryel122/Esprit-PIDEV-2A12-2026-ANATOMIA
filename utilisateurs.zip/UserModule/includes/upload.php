<?php
/**
 * Upload sécurisé des justificatifs (diplôme / carte professionnelle).
 *  - taille limitée, types autorisés : PDF, JPEG, PNG
 *  - le type est détecté sur le CONTENU du fichier (finfo), jamais d'après le nom ou le Content-Type client
 *  - l'extension est déduite du type détecté, le nom stocké est aléatoire
 *  - dossier uploads/justificatifs protégé (.htaccess) ; accès via justificatif.php avec contrôle d'identité
 */

const JUSTIFICATIF_MAX_BYTES = 3145728; // 3 Mo
const JUSTIFICATIF_TYPES = [
    'application/pdf' => 'pdf',
    'image/jpeg'      => 'jpg',
    'image/png'       => 'png',
];

function justificatifDir()
{
    return APP_ROOT . '/uploads/justificatifs';
}

/**
 * Valide le fichier envoyé (champ 'justificatif').
 * Retourne [message d'erreur ou null, mime détecté ou null].
 */
function validateJustificatif($required)
{
    $file = $_FILES['justificatif'] ?? null;

    if (!is_array($file) || !isset($file['error']) || is_array($file['error'])
        || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return [$required ? 'Le justificatif est obligatoire (PDF, JPG ou PNG).' : null, null];
    }
    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
        return ['Le fichier dépasse la taille maximale autorisée (3 Mo).', null];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['Le téléversement du justificatif a échoué. Réessayez.', null];
    }
    if ($file['size'] <= 0 || $file['size'] > JUSTIFICATIF_MAX_BYTES) {
        return ['Le justificatif doit peser moins de 3 Mo.', null];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return ['Fichier invalide.', null];
    }
    if (!function_exists('finfo_open')) {
        return ['Vérification du fichier impossible sur ce serveur (extension fileinfo requise).', null];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset(JUSTIFICATIF_TYPES[$mime])) {
        return ['Format refusé : seuls les fichiers PDF, JPG et PNG sont acceptés.', null];
    }
    if ($mime === 'application/pdf' && file_get_contents($file['tmp_name'], false, null, 0, 5) !== '%PDF-') {
        return ['Le fichier PDF est invalide.', null];
    }
    if ($mime !== 'application/pdf' && @getimagesize($file['tmp_name']) === false) {
        return ['Le fichier image est invalide ou corrompu.', null];
    }
    return [null, $mime];
}

/**
 * Déplace le fichier validé dans le dossier protégé.
 * Retourne [nom stocké, nom d'origine nettoyé, mime] ou null en cas d'échec.
 */
function storeJustificatif($mime)
{
    $file = $_FILES['justificatif'];
    $dir = justificatifDir();
    if (!is_dir($dir) && !mkdir($dir, 0750, true)) {
        return null;
    }

    $stored = bin2hex(random_bytes(16)) . '.' . JUSTIFICATIF_TYPES[$mime];
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $stored)) {
        return null;
    }
    @chmod($dir . '/' . $stored, 0640);

    $original = preg_replace('/[^\p{L}\p{N} ._\-]/u', '', basename((string) $file['name']));
    $original = mb_substr($original === '' ? 'justificatif' : $original, 0, 150);

    return [$stored, $original, $mime];
}

function isValidStoredName($name)
{
    return is_string($name) && preg_match('/^[a-f0-9]{32}\.(pdf|jpg|png)$/', $name) === 1;
}

function deleteJustificatif($stored)
{
    if (isValidStoredName($stored)) {
        $path = justificatifDir() . '/' . $stored;
        if (is_file($path)) {
            @unlink($path);
        }
    }
}
