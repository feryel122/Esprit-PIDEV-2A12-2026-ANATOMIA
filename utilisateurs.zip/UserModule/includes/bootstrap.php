<?php
/**
 * Amorçage commun (Front Office + Back Office) :
 * session durcie, en-têtes de sécurité, CSRF, messages flash, contrôle d'accès.
 */

date_default_timezone_set('Africa/Tunis');

define('APP_ROOT', dirname(__DIR__));
define('SESSION_IDLE_SECONDS', 1800); // déconnexion après 30 min d'inactivité

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

if (!headers_sent()) {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; "
        . "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; "
        . "font-src 'self' data: https://fonts.gstatic.com https://cdn.jsdelivr.net; "
        . "script-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
}

/* ---------- Utilitaires ---------- */

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/** URL absolue (chemin) depuis la racine du projet, quel que soit le dossier d'installation. */
function url($path)
{
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $pos = strpos($script, '/View/');
    $base = $pos === false ? '' : substr($script, 0, $pos);
    return $base . '/' . ltrim($path, '/');
}

function redirect($path)
{
    header('Location: ' . $path);
    exit;
}

/* ---------- CSRF ---------- */

function csrfToken()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField()
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrfToken()) . '">';
}

function verifyCsrf()
{
    $token = $_POST['csrf_token'] ?? '';
    return !empty($_SESSION['csrf_token']) && is_string($token)
        && hash_equals($_SESSION['csrf_token'], $token);
}

/* ---------- Messages flash ---------- */

function setFlash($message, $type = 'success')
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}

function pullFlash()
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

/* ---------- Authentification ---------- */

/** Ouvre la session après une connexion réussie (régénère l'identifiant : anti session-fixation). */
function loginSession(array $user)
{
    unset($user['password']);
    session_regenerate_id(true);
    $_SESSION['user'] = $user;
    $_SESSION['last_activity'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function destroySession()
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/**
 * Utilisateur connecté, relu en base à chaque requête : un compte désactivé
 * ou un rôle modifié par l'admin prend effet immédiatement.
 */
function currentUser()
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $session = $_SESSION['user'] ?? null;
    if (!is_array($session) || empty($session['id'])) {
        return $cache = null;
    }
    if (time() - (int) ($_SESSION['last_activity'] ?? 0) > SESSION_IDLE_SECONDS) {
        unset($_SESSION['user'], $_SESSION['last_activity']);
        setFlash('Session expirée, veuillez vous reconnecter.', 'error');
        return $cache = null;
    }
    require_once APP_ROOT . '/Controller/UserController.php';
    $fresh = (new UserController())->getUserById((int) $session['id']);
    if (!$fresh || $fresh['statut_compte'] !== 'actif') {
        unset($_SESSION['user'], $_SESSION['last_activity']);
        setFlash('Ce compte est introuvable ou désactivé.', 'error');
        return $cache = null;
    }
    $_SESSION['last_activity'] = time();
    $_SESSION['user'] = $fresh;
    return $cache = $fresh;
}

function isLoggedIn()
{
    return currentUser() !== null;
}

function userRole()
{
    $user = currentUser();
    return $user['role'] ?? '';
}

function fullName($user)
{
    return trim(($user['prenom'] ?? '') . ' ' . ($user['nom'] ?? ''));
}

/** Page d'accueil propre à chaque rôle. */
function homeFor($role)
{
    if ($role === 'admin') {
        return url('View/Backoffice/adminlte/dashboard.php');
    }
    if ($role === 'medecin') {
        return url('View/Frontoffice/profil_medecin.php');
    }
    return url('View/Frontoffice/profil_utilisateur.php');
}

/* ---------- Contrôle d'accès ---------- */

function requireLogin()
{
    if (!isLoggedIn()) {
        if (!isset($_SESSION['flash'])) {
            setFlash('Connectez-vous pour continuer.', 'error');
        }
        redirect(url('View/Frontoffice/login.php'));
    }
}

/** Réserve la page aux rôles donnés ; sinon : page 403. */
function requireRole(array $roles)
{
    requireLogin();
    if (!in_array(userRole(), $roles, true)) {
        redirect(url('View/Frontoffice/acces_refuse.php'));
    }
}

/** Réservé aux médecins dont le compte a été validé par l'administrateur. */
function requireVerifiedDoctor()
{
    requireRole(['medecin']);
    if (currentUser()['statut_verification'] !== 'verifie') {
        setFlash('Cette page est réservée aux médecins vérifiés. Votre dossier n\'a pas encore été validé.', 'error');
        redirect(url('View/Frontoffice/profil_medecin.php'));
    }
}

function isVerifiedDoctor($user)
{
    return ($user['role'] ?? '') === 'medecin' && ($user['statut_verification'] ?? '') === 'verifie';
}

/** Exige une requête POST avec jeton CSRF valide, sinon retour avec message d'erreur. */
function requirePostCsrf($backUrl)
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !verifyCsrf()) {
        setFlash('Requête invalide ou session expirée.', 'error');
        redirect($backUrl);
    }
}
