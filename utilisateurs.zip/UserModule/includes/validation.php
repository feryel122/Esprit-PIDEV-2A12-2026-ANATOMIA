<?php
/**
 * Validation CÔTÉ SERVEUR de tous les formulaires du module utilisateur.
 * (Le JavaScript de View/Assets/js/validation.js n'est qu'un confort : ce fichier fait foi.)
 * Chaque fonction retourne des erreurs indexées par nom de champ.
 */

require_once __DIR__ . '/../Model/User.php';

const SPECIALITES = [
    'Médecine générale', 'Cardiologie', 'Dermatologie', 'Endocrinologie', 'Gastro-entérologie',
    'Gynécologie', 'Neurologie', 'Nutrition et diététique', 'Ophtalmologie', 'Orthopédie',
    'Pédiatrie', 'Pneumologie', 'Psychiatrie', 'Rhumatologie', 'Urologie', 'Autre',
];

function postStr($key)
{
    $value = $_POST[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}

function isRealDate($date)
{
    $dt = DateTime::createFromFormat('!Y-m-d', $date);
    return $dt !== false && $dt->format('Y-m-d') === $date;
}

function passwordErrors($password, $confirm, $field = 'password', $confirmField = 'confirm_password')
{
    $errors = [];
    if (strlen($password) < 8) {
        $errors[$field] = 'Le mot de passe doit contenir au moins 8 caractères.';
    } elseif (strlen($password) > 72) {
        $errors[$field] = 'Le mot de passe est trop long (72 caractères maximum).';
    } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        $errors[$field] = 'Le mot de passe doit contenir au moins une lettre et un chiffre.';
    }
    if ($confirm !== $password) {
        $errors[$confirmField] = 'La confirmation ne correspond pas au mot de passe.';
    }
    return $errors;
}

/**
 * Lit et valide $_POST pour un compte du rôle donné.
 * $passwordMode : 'required' | 'optional' | 'none'
 * Retourne [User, erreurs].
 */
function collectUserInput($role, $passwordMode)
{
    $errors = [];
    $user = new User($role);

    $nom = postStr('nom');
    $prenom = postStr('prenom');
    $email = mb_strtolower(postStr('email'));
    $namePattern = '/^\p{L}[\p{L} \'\-]{1,99}$/u';

    if (!preg_match($namePattern, $nom)) {
        $errors['nom'] = 'Nom invalide (lettres uniquement, 2 à 100 caractères).';
    }
    if (!preg_match($namePattern, $prenom)) {
        $errors['prenom'] = 'Prénom invalide (lettres uniquement, 2 à 100 caractères).';
    }
    if ($email === '' || mb_strlen($email) > 190 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Adresse e-mail invalide.';
    }
    $user->setNom($nom)->setPrenom($prenom)->setEmail($email);

    // Téléphone (obligatoire pour un médecin)
    $phone = preg_replace('/[\s.\-]/', '', postStr('telephone'));
    if ($phone === '' && $role === 'medecin') {
        $errors['telephone'] = 'Le téléphone est obligatoire pour un médecin.';
    } elseif ($phone !== '' && !preg_match('/^\+?[0-9]{8,15}$/', $phone)) {
        $errors['telephone'] = 'Numéro de téléphone invalide (8 à 15 chiffres).';
    }
    $user->setTelephone($phone !== '' ? $phone : null);

    // Mot de passe
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
    $confirm = is_string($_POST['confirm_password'] ?? null) ? $_POST['confirm_password'] : '';
    if ($passwordMode === 'required' || ($passwordMode === 'optional' && ($password !== '' || $confirm !== ''))) {
        $errors += passwordErrors($password, $confirm);
    }
    $user->setPassword($password);

    if ($role === 'admin') {
        return [$user, $errors];
    }

    // Date de naissance et genre
    $date = postStr('date_naissance');
    if ($date !== '') {
        if (!isRealDate($date) || $date > date('Y-m-d') || $date < '1900-01-01') {
            $errors['date_naissance'] = 'Date de naissance invalide.';
        }
    }
    $genre = postStr('genre');
    if ($genre !== '' && !in_array($genre, User::GENRES, true)) {
        $errors['genre'] = 'Genre invalide.';
    }
    $user->setDateNaissance($date !== '' ? $date : null)->setGenre($genre !== '' ? $genre : null);

    if ($role === 'medecin') {
        $specialite = postStr('specialite');
        if (!in_array($specialite, SPECIALITES, true)) {
            $errors['specialite'] = 'Choisissez une spécialité dans la liste.';
        }
        $ordre = strtoupper(postStr('numero_ordre'));
        if (!preg_match('/^[A-Z0-9\-\/]{4,20}$/', $ordre)) {
            $errors['numero_ordre'] = 'Numéro d\'ordre invalide (4 à 20 caractères : lettres, chiffres, - ou /).';
        }
        $ville = postStr('ville');
        if ($ville !== '' && !preg_match('/^[\p{L}\p{N} \'\-]{2,100}$/u', $ville)) {
            $errors['ville'] = 'Ville invalide.';
        }
        $bio = postStr('bio');
        if (mb_strlen($bio) > 1000) {
            $errors['bio'] = 'La présentation ne doit pas dépasser 1000 caractères.';
        }
        $user->setSpecialite($specialite)->setNumeroOrdre($ordre)
            ->setVille($ville !== '' ? $ville : null)->setBio($bio !== '' ? $bio : null);
        return [$user, $errors];
    }

    // Utilisateur : données de santé facultatives
    $taille = str_replace(',', '.', postStr('taille'));
    $poids = str_replace(',', '.', postStr('poids'));
    if ($taille !== '' && (!is_numeric($taille) || $taille < 50 || $taille > 250)) {
        $errors['taille'] = 'La taille doit être comprise entre 50 et 250 cm.';
    }
    if ($poids !== '' && (!is_numeric($poids) || $poids < 20 || $poids > 300)) {
        $errors['poids'] = 'Le poids doit être compris entre 20 et 300 kg.';
    }
    $user->setTaille($taille !== '' ? $taille : null)->setPoids($poids !== '' ? $poids : null);

    return [$user, $errors];
}

/** Formulaire de changement de mot de passe (profil) : retourne [nouveau mot de passe, erreurs]. */
function collectPasswordChange()
{
    $errors = [];
    $current = is_string($_POST['current_password'] ?? null) ? $_POST['current_password'] : '';
    $new = is_string($_POST['new_password'] ?? null) ? $_POST['new_password'] : '';
    $confirm = is_string($_POST['confirm_new_password'] ?? null) ? $_POST['confirm_new_password'] : '';

    if ($current === '') {
        $errors['current_password'] = 'Saisissez votre mot de passe actuel.';
    }
    $errors += passwordErrors($new, $confirm, 'new_password', 'confirm_new_password');
    return [$current, $new, $errors];
}

/** Motif de refus d'un médecin (admin). Retourne [motif, erreur|null]. */
function collectRefusalReason()
{
    $reason = postStr('motif_refus');
    if (mb_strlen($reason) < 5 || mb_strlen($reason) > 500) {
        return [$reason, 'Indiquez un motif de refus (5 à 500 caractères).'];
    }
    return [$reason, null];
}
