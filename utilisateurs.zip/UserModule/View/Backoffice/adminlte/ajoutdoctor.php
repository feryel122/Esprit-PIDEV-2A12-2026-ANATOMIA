<?php
$forcedRole = 'medecin';
require __DIR__ . '/ajoutuser.php';
