<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
requireRole(['admin']);
require_once __DIR__ . '/../../../includes/forms.php';
require_once __DIR__ . '/../../../Controller/UserController.php';

$controller = new UserController();
$stats = $controller->stats();
$pending = $controller->getDoctorsByVerification('en_attente', 5);
$latest = $controller->latest(5);

$title = 'ANATOMIA - Tableau de bord';
$currentPage = 'dashboard';
ob_start();
require __DIR__ . '/../Views/pages/dashboard.php';
$content = ob_get_clean();
require __DIR__ . '/../Views/layout.php';
