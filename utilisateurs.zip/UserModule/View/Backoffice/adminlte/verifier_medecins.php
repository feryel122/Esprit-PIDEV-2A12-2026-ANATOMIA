<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
requireRole(['admin']);
require_once __DIR__ . '/../../../includes/forms.php';
require_once __DIR__ . '/../../../Controller/UserController.php';

$controller = new UserController();
$statut = is_string($_GET['statut'] ?? null) ? $_GET['statut'] : 'en_attente';
if (!in_array($statut, ['en_attente', 'refuse', 'verifie'], true)) {
    $statut = 'en_attente';
}
$docs = $controller->getDoctorsByVerification($statut, 100);
$from = 'queue';
$tabs = ['en_attente' => 'En attente', 'refuse' => 'Refusés', 'verifie' => 'Vérifiés'];

$title = 'ANATOMIA - Vérification des médecins';
$currentPage = 'verification';
ob_start();
?>
<div class="app-content-header">
    <div class="container-fluid">
        <h3>Vérification des médecins</h3>
        <p class="mb-0">Examinez le justificatif de chaque médecin avant de valider ou de refuser son dossier.</p>
    </div>
</div>

<ul class="nav nav-pills mb-3">
    <?php foreach ($tabs as $key => $label): ?>
        <li class="nav-item">
            <a class="nav-link <?= $statut === $key ? 'active' : '' ?>" href="?statut=<?= e($key) ?>"><?= e($label) ?></a>
        </li>
    <?php endforeach; ?>
</ul>

<div class="card">
    <div class="card-body table-responsive">
        <table class="table table-bordered align-middle">
            <thead>
                <tr><th>Médecin</th><th>Spécialité</th><th>N° d'ordre</th><th>Ville</th><th>Inscrit le</th><th>Justificatif</th><th style="min-width:200px">Décision</th></tr>
            </thead>
            <tbody>
            <?php if (!$docs): ?>
                <tr><td colspan="7" class="text-center text-muted">Aucun dossier dans cette catégorie.</td></tr>
            <?php endif; ?>
            <?php foreach ($docs as $doc): ?>
                <tr>
                    <td>
                        <a href="afficheruser.php?id=<?= (int) $doc['id'] ?>"><strong><?= e('Dr ' . fullName($doc)) ?></strong></a><br>
                        <small class="text-muted"><?= e($doc['email']) ?></small>
                        <?php if ($doc['statut_compte'] !== 'actif'): ?><br><?= badgeAccount($doc['statut_compte']) ?><?php endif; ?>
                    </td>
                    <td><?= e(orDash($doc['specialite'])) ?></td>
                    <td><?= e(orDash($doc['numero_ordre'])) ?></td>
                    <td><?= e(orDash($doc['ville'])) ?></td>
                    <td><?= e(fmtDate($doc['created_at'])) ?></td>
                    <td>
                        <?php if ($doc['justificatif_fichier']): ?>
                            <a class="btn btn-outline-primary btn-sm" target="_blank" rel="noopener"
                               href="../../Frontoffice/justificatif.php?id=<?= (int) $doc['id'] ?>"><i class="bi bi-file-earmark-text"></i> Ouvrir</a>
                        <?php else: ?><span class="text-muted">Aucun</span><?php endif; ?>
                    </td>
                    <td>
                        <?php if ($doc['statut_verification'] === 'refuse'): ?>
                            <small class="text-danger d-block mb-1">Motif : <?= e(orDash($doc['motif_refus'])) ?></small>
                        <?php endif; ?>
                        <?php require __DIR__ . '/../Views/partials/verify_actions.php'; ?>
                    </td>
                </tr>
                <?php if ($doc['statut_verification'] !== 'refuse'): ?>
                    <tr id="refuse-<?= (int) $doc['id'] ?>-queue" hidden>
                        <td colspan="7" class="bg-light"><?php require __DIR__ . '/../Views/partials/refuse_form.php'; ?></td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php
$content = ob_get_clean();
require __DIR__ . '/../Views/layout.php';
