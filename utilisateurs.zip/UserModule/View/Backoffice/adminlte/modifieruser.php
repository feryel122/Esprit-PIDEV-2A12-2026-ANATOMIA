<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
requireRole(['admin']);
require_once __DIR__ . '/../../../includes/validation.php';
require_once __DIR__ . '/../../../includes/forms.php';
require_once __DIR__ . '/../../../Controller/UserController.php';

$controller = new UserController();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$current = $id ? $controller->getUserById($id) : null;
if (!$current) {
    setFlash('Compte introuvable.', 'error');
    redirect('afficherusers.php');
}

$isDoctor = $current['role'] === 'medecin';
$mode = $isDoctor ? 'doctor' : 'user';
$isEdit = true;
$isSelf = (int) $current['id'] === (int) currentUser()['id'];
$errors = [];
$account = $current;
$formTitle = $isDoctor ? 'Modifier un médecin' : 'Modifier un compte';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $errors['_global'] = 'Jeton de sécurité invalide. Rechargez la page.';
    } else {
        // Le rôle d'un médecin ne change jamais ; un admin ne peut pas modifier son propre rôle.
        if ($isDoctor) {
            $role = 'medecin';
        } elseif ($isSelf) {
            $role = 'admin';
        } else {
            $postedRole = is_string($_POST['role'] ?? null) ? $_POST['role'] : $current['role'];
            $role = in_array($postedRole, ['utilisateur', 'admin'], true) ? $postedRole : $current['role'];
        }

        [$user, $errors] = collectUserInput($role, 'optional');
        $changePassword = $user->getPassword() !== '';
        $account = array_merge($current, $user->toFormArray());

        if (!isset($errors['email']) && $controller->emailTakenByOther($user->getEmail(), $current['id'])) {
            $errors['email'] = 'Cet e-mail est déjà utilisé par un autre compte.';
        }
        if ($isDoctor && !isset($errors['numero_ordre']) && $controller->ordreTakenByOther($user->getNumeroOrdre(), $current['id'])) {
            $errors['numero_ordre'] = 'Ce numéro d\'ordre est déjà enregistré.';
        }
        if (!$errors) {
            if ($controller->adminUpdate($current['id'], $user, $changePassword)) {
                setFlash('Compte modifié avec succès.');
                redirect('afficheruser.php?id=' . (int) $current['id']);
            }
            $errors['_global'] = 'Modification impossible.';
        }
    }
}

$title = 'ANATOMIA - ' . $formTitle;
$currentPage = $isDoctor ? 'doctors' : 'users';
ob_start();
require __DIR__ . '/../Views/pages/user_form.php';
$content = ob_get_clean();
require __DIR__ . '/../Views/layout.php';
