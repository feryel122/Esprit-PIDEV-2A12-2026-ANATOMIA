<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
requireRole(['admin']);
require_once __DIR__ . '/../../../includes/forms.php';
require_once __DIR__ . '/../../../Controller/UserController.php';

$controller = new UserController();
$scope = 'users';
$search = mb_substr(trim(is_string($_GET['q'] ?? null) ? $_GET['q'] : ''), 0, 100);
$filters = [
    'role'   => is_string($_GET['role'] ?? null) ? $_GET['role'] : '',
    'statut' => is_string($_GET['statut'] ?? null) ? $_GET['statut'] : '',
];
$result = $controller->search($scope, $search, $filters, (int) ($_GET['page'] ?? 1), 10);
$baseParams = array_filter(['q' => $search] + $filters, function ($v) { return $v !== ''; });

$title = 'ANATOMIA - Utilisateurs';
$currentPage = 'users';
ob_start();
require __DIR__ . '/../Views/pages/account_list.php';
$content = ob_get_clean();
require __DIR__ . '/../Views/layout.php';
