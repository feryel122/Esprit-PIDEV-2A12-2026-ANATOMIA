<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
requireRole(['admin']);
require_once __DIR__ . '/../../../includes/validation.php';
require_once __DIR__ . '/../../../includes/forms.php';
require_once __DIR__ . '/../../../Controller/UserController.php';

$controller = new UserController();
$forcedRole = $forcedRole ?? null;            // 'medecin' quand inclus par ajoutdoctor.php
$mode = $forcedRole === 'medecin' ? 'doctor' : 'user';
$isEdit = false;
$isSelf = false;
$errors = [];
$account = ['role' => $forcedRole ?? 'utilisateur'];
$formTitle = $mode === 'doctor' ? 'Ajouter un médecin' : 'Ajouter un utilisateur';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $errors['_global'] = 'Jeton de sécurité invalide. Rechargez la page.';
    } else {
        // Rôle fixé par la page (médecin) ou limité à utilisateur / admin.
        $postedRole = is_string($_POST['role'] ?? null) ? $_POST['role'] : 'utilisateur';
        $role = $forcedRole ?? (in_array($postedRole, ['utilisateur', 'admin'], true) ? $postedRole : 'utilisateur');

        [$user, $errors] = collectUserInput($role, 'required');
        $account = $user->toFormArray();
        $account['verifier_maintenant'] = !empty($_POST['verifier_maintenant']);

        if (!isset($errors['email']) && $controller->findByEmail($user->getEmail())) {
            $errors['email'] = 'Cet e-mail est déjà utilisé.';
        }
        if ($role === 'medecin' && !isset($errors['numero_ordre']) && $controller->ordreTakenByOther($user->getNumeroOrdre())) {
            $errors['numero_ordre'] = 'Ce numéro d\'ordre est déjà enregistré.';
        }
        if (!$errors) {
            $newId = $controller->create($user, $role === 'medecin' && $account['verifier_maintenant'], currentUser()['id']);
            if ($newId) {
                setFlash($role === 'medecin' ? 'Médecin ajouté.' : 'Compte ajouté.');
                redirect('afficheruser.php?id=' . (int) $newId);
            }
            $errors['_global'] = 'Création impossible.';
        }
    }
}

$title = 'ANATOMIA - ' . $formTitle;
$currentPage = $mode === 'doctor' ? 'doctors' : 'users';
ob_start();
require __DIR__ . '/../Views/pages/user_form.php';
$content = ob_get_clean();
require __DIR__ . '/../Views/layout.php';
