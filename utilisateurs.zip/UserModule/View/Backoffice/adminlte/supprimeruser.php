<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
requireRole(['admin']);
require_once __DIR__ . '/../../../includes/upload.php';
require_once __DIR__ . '/../../../Controller/UserController.php';

$controller = new UserController();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$account = $id ? $controller->getUserById($id) : null;
$listUrl = ($account && $account['role'] === 'medecin') ? 'afficherdoctors.php' : 'afficherusers.php';

if (!$account) {
    setFlash('Compte introuvable.', 'error');
    redirect('afficherusers.php');
}
if ((int) $account['id'] === (int) currentUser()['id']) {
    setFlash('Vous ne pouvez pas supprimer votre propre compte.', 'error');
    redirect($listUrl);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        setFlash('Jeton de sécurité invalide.', 'error');
    } elseif ($controller->deleteUser($account['id'])) {
        deleteJustificatif($account['justificatif_fichier']);
        setFlash('Compte supprimé définitivement.');
        redirect($listUrl);
    } else {
        setFlash('Suppression impossible.', 'error');
    }
    redirect($listUrl);
}

$title = 'ANATOMIA - Supprimer un compte';
$currentPage = $account['role'] === 'medecin' ? 'doctors' : 'users';
ob_start();
?>
<div class="app-content-header"><div class="container-fluid"><h3>Supprimer un compte</h3></div></div>
<div class="card border-danger">
    <div class="card-body">
        <p class="fs-5">Supprimer définitivement <strong><?= e(fullName($account)) ?></strong> ?</p>
        <p class="text-muted"><?= e($account['email']) ?> — <?= badgeRole($account['role']) ?></p>
        <div class="alert alert-warning">Cette action est irréversible. Pour conserver les données, préférez <strong>désactiver</strong> le compte depuis la liste.</div>
        <form method="post" data-confirm="Confirmer la suppression définitive du compte ?">
            <?= csrfField() ?>
            <input type="hidden" name="id" value="<?= (int) $account['id'] ?>">
            <button class="btn btn-danger" type="submit">Supprimer définitivement</button>
            <a class="btn btn-secondary" href="<?= e($listUrl) ?>">Annuler</a>
        </form>
    </div>
</div>
<?php
$content = ob_get_clean();
require __DIR__ . '/../Views/layout.php';
