<?php
// La fiche est la même pour tous les comptes : le rôle est lu en base (voir afficheruser.php).
require __DIR__ . '/afficheruser.php';
