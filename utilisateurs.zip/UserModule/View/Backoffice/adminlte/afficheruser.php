<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
requireRole(['admin']);
require_once __DIR__ . '/../../../includes/forms.php';
require_once __DIR__ . '/../../../Controller/UserController.php';

$controller = new UserController();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$account = $id ? $controller->getUserById($id) : null;
if (!$account) {
    setFlash('Compte introuvable.', 'error');
    redirect('afficherusers.php');
}

$isDoctor = $account['role'] === 'medecin';
$isSelf = (int) $account['id'] === (int) currentUser()['id'];
$doc = $account;
$from = 'fiche';

$title = 'ANATOMIA - Fiche ' . ($isDoctor ? 'médecin' : 'utilisateur');
$currentPage = $isDoctor ? 'doctors' : 'users';
ob_start();
?>
<div class="app-content-header">
    <div class="container-fluid"><h3>Fiche <?= $isDoctor ? 'médecin' : 'utilisateur' ?></h3></div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title mb-0"><?= e(($isDoctor ? 'Dr ' : '') . fullName($account)) ?>
            <?= badgeRole($account['role']) ?> <?= badgeAccount($account['statut_compte']) ?>
            <?php if ($isDoctor): ?><?= badgeVerification($account['statut_verification']) ?><?php endif; ?></h3>
    </div>
    <div class="card-body">
        <dl class="row mb-0">
            <dt class="col-sm-3">E-mail</dt><dd class="col-sm-9"><?= e($account['email']) ?></dd>
            <dt class="col-sm-3">Téléphone</dt><dd class="col-sm-9"><?= e(orDash($account['telephone'])) ?></dd>
            <?php if ($account['role'] !== 'admin'): ?>
                <dt class="col-sm-3">Date de naissance</dt><dd class="col-sm-9"><?= e(fmtDate($account['date_naissance'])) ?></dd>
                <dt class="col-sm-3">Genre</dt><dd class="col-sm-9"><?= e(orDash(genreOptions()[$account['genre']] ?? '')) ?></dd>
            <?php endif; ?>
            <?php if ($account['role'] === 'utilisateur'): ?>
                <dt class="col-sm-3">Taille</dt><dd class="col-sm-9"><?= $account['taille'] !== null ? e($account['taille']) . ' cm' : '—' ?></dd>
                <dt class="col-sm-3">Poids</dt><dd class="col-sm-9"><?= $account['poids'] !== null ? e($account['poids']) . ' kg' : '—' ?></dd>
            <?php endif; ?>
            <?php if ($isDoctor): ?>
                <dt class="col-sm-3">Spécialité</dt><dd class="col-sm-9"><?= e(orDash($account['specialite'])) ?></dd>
                <dt class="col-sm-3">N° d'ordre</dt><dd class="col-sm-9"><?= e(orDash($account['numero_ordre'])) ?></dd>
                <dt class="col-sm-3">Ville du cabinet</dt><dd class="col-sm-9"><?= e(orDash($account['ville'])) ?></dd>
                <dt class="col-sm-3">Présentation</dt><dd class="col-sm-9"><?= nl2br(e(orDash($account['bio']))) ?></dd>
                <dt class="col-sm-3">Justificatif</dt>
                <dd class="col-sm-9">
                    <?php if ($account['justificatif_fichier']): ?>
                        <a href="../../Frontoffice/justificatif.php?id=<?= (int) $account['id'] ?>" target="_blank" rel="noopener">
                            <i class="bi bi-file-earmark-text"></i> <?= e($account['justificatif_nom']) ?></a>
                    <?php else: ?>Aucun justificatif<?php endif; ?>
                </dd>
                <dt class="col-sm-3">Vérification</dt>
                <dd class="col-sm-9">
                    <?= badgeVerification($account['statut_verification']) ?>
                    <?php if ($account['verifie_le']): ?><span class="text-muted ms-2">le <?= e(fmtDate($account['verifie_le'], true)) ?></span><?php endif; ?>
                    <?php if ($account['statut_verification'] === 'refuse'): ?><div class="mt-1">Motif : <?= e(orDash($account['motif_refus'])) ?></div><?php endif; ?>
                </dd>
            <?php endif; ?>
            <dt class="col-sm-3">Inscrit le</dt><dd class="col-sm-9"><?= e(fmtDate($account['created_at'], true)) ?></dd>
        </dl>
    </div>
    <div class="card-footer d-flex flex-wrap gap-2">
        <a class="btn btn-warning" href="<?= $isDoctor ? 'modifierdoctor.php' : 'modifieruser.php' ?>?id=<?= (int) $account['id'] ?>">Modifier</a>
        <a class="btn btn-secondary" href="<?= $isDoctor ? 'afficherdoctors.php' : 'afficherusers.php' ?>">Retour à la liste</a>
        <?php if ($isDoctor): ?><div class="ms-auto"><?php require __DIR__ . '/../Views/partials/verify_actions.php'; ?></div><?php endif; ?>
    </div>
    <?php if ($isDoctor && $account['statut_verification'] !== 'refuse'): ?>
        <div class="card-footer" id="refuse-<?= (int) $doc['id'] ?>-fiche" hidden>
            <?php require __DIR__ . '/../Views/partials/refuse_form.php'; ?>
        </div>
    <?php endif; ?>
</div>
<?php
$content = ob_get_clean();
require __DIR__ . '/../Views/layout.php';
