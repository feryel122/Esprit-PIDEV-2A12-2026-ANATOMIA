<?php
// Même page que la suppression d'un utilisateur : le rôle est lu en base (voir supprimeruser.php).
require __DIR__ . '/supprimeruser.php';
