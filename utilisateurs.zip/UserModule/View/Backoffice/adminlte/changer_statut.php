<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
requireRole(['admin']);
require_once __DIR__ . '/../../../Controller/UserController.php';

// Activer / désactiver un compte (POST + CSRF uniquement).
$from = is_string($_POST['from'] ?? null) ? $_POST['from'] : 'users';
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$fallback = $from === 'doctors' ? 'afficherdoctors.php' : 'afficherusers.php';
requirePostCsrf($fallback);

$controller = new UserController();
$account = $id ? $controller->getUserById($id) : null;
$target = ($from === 'fiche' && $id) ? 'afficheruser.php?id=' . (int) $id : $fallback;

if (!$account) {
    setFlash('Compte introuvable.', 'error');
    redirect($fallback);
}
if ((int) $account['id'] === (int) currentUser()['id']) {
    setFlash('Vous ne pouvez pas désactiver votre propre compte.', 'error');
    redirect($target);
}

$action = $_POST['action'] ?? '';
if ($action === 'desactiver' && $controller->setAccountStatus($account['id'], 'desactive')) {
    setFlash('Compte de ' . fullName($account) . ' désactivé : la connexion lui est désormais refusée.');
} elseif ($action === 'activer' && $controller->setAccountStatus($account['id'], 'actif')) {
    setFlash('Compte de ' . fullName($account) . ' réactivé.');
} else {
    setFlash('Action impossible.', 'error');
}
redirect($target);
