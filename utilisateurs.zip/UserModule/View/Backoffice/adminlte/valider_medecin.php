<?php
require_once __DIR__ . '/../../../includes/bootstrap.php';
// Seul l'administrateur peut valider ou refuser un médecin.
requireRole(['admin']);
require_once __DIR__ . '/../../../includes/validation.php';
require_once __DIR__ . '/../../../Controller/UserController.php';

$queueUrl = 'verifier_medecins.php';
requirePostCsrf($queueUrl);

$controller = new UserController();
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$account = $id ? $controller->getUserById($id) : null;
if (!$account || $account['role'] !== 'medecin') {
    setFlash('Médecin introuvable.', 'error');
    redirect($queueUrl);
}

$target = (($_POST['from'] ?? '') === 'queue') ? $queueUrl : 'afficheruser.php?id=' . (int) $account['id'];
$adminId = (int) currentUser()['id'];
$name = 'Dr ' . fullName($account);

$decision = $_POST['decision'] ?? '';
if ($decision === 'valider') {
    if ($controller->verifyDoctor($account['id'], $adminId)) {
        setFlash($name . ' a été validé : il est désormais médecin vérifié.');
    } else {
        setFlash('La validation a échoué.', 'error');
    }
} elseif ($decision === 'refuser') {
    [$reason, $error] = collectRefusalReason();
    if ($error) {
        setFlash($error, 'error');
    } elseif ($controller->refuseDoctor($account['id'], $adminId, $reason)) {
        setFlash('Le dossier de ' . $name . ' a été refusé.');
    } else {
        setFlash('Le refus a échoué.', 'error');
    }
} else {
    setFlash('Décision inconnue.', 'error');
}
redirect($target);
