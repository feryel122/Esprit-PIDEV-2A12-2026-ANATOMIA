<?php
// Le formulaire s'adapte au rôle lu en base (voir modifieruser.php).
require __DIR__ . '/modifieruser.php';
