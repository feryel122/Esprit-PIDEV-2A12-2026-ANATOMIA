<?php
// Boutons Valider / Refuser un médecin. Attend : $doc (ligne médecin), $from ('fiche' ou 'queue').
// Seul l'administrateur atteint cette vue ; valider_medecin.php revérifie le rôle et le jeton CSRF.
$refuseId = 'refuse-' . (int) $doc['id'] . '-' . $from;
?>
<div class="d-flex flex-wrap gap-2">
    <?php if ($doc['statut_verification'] !== 'verifie'): ?>
        <form method="post" action="valider_medecin.php" data-confirm="Valider ce médecin ?">
            <?= csrfField() ?>
            <input type="hidden" name="id" value="<?= (int) $doc['id'] ?>">
            <input type="hidden" name="from" value="<?= e($from) ?>">
            <input type="hidden" name="decision" value="valider">
            <button type="submit" class="btn btn-success btn-sm"><i class="bi bi-check-lg"></i> Valider</button>
        </form>
    <?php endif; ?>
    <?php if ($doc['statut_verification'] !== 'refuse'): ?>
        <button type="button" class="btn btn-danger btn-sm" data-toggle-target="<?= e($refuseId) ?>"><i class="bi bi-x-lg"></i> Refuser</button>
    <?php endif; ?>
</div>
