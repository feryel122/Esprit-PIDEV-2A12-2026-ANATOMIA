<?php
require_once __DIR__ . '/../../../../Controller/UserController.php';
require_once __DIR__ . '/../../../../includes/forms.php';
$pendingCount = (new UserController())->countPendingDoctors();
$isUsers = in_array($currentPage, ['users'], true);
$isDoctors = in_array($currentPage, ['doctors'], true);
?>
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">

    <div class="sidebar-brand">
        <a href="dashboard.php" class="brand-link">
            <span class="brand-text fw-light">ANATOMIA</span>
        </a>
    </div>

    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu">

                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-speedometer2"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="afficherusers.php" class="nav-link <?= $isUsers ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-people"></i>
                        <p>Utilisateurs</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="afficherdoctors.php" class="nav-link <?= $isDoctors ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-heart-pulse"></i>
                        <p>Médecins</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="verifier_medecins.php" class="nav-link <?= $currentPage === 'verification' ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-patch-check"></i>
                        <p>Vérification médecins
                            <?php if ($pendingCount > 0): ?><span class="badge text-bg-warning ms-1"><?= (int) $pendingCount ?></span><?php endif; ?>
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="../../Frontoffice/accueil.php" class="nav-link">
                        <i class="nav-icon bi bi-house"></i>
                        <p>Voir le site</p>
                    </a>
                </li>

                <li class="nav-item">
                    <form method="post" action="../../Frontoffice/logout.php">
                        <?= csrfField() ?>
                        <button type="submit" class="nav-link logout-btn">
                            <i class="nav-icon bi bi-box-arrow-right"></i>
                            <p>Déconnexion</p>
                        </button>
                    </form>
                </li>

            </ul>
        </nav>
    </div>

</aside>
