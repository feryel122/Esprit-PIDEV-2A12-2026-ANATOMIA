<?php
// Formulaire de refus avec motif (masqué tant qu'on n'a pas cliqué sur Refuser). Attend : $doc, $from.
$refuseId = 'refuse-' . (int) $doc['id'] . '-' . $from;
?>
<form method="post" action="valider_medecin.php" data-validate novalidate data-confirm="Refuser ce médecin ?">
    <?= csrfField() ?>
    <input type="hidden" name="id" value="<?= (int) $doc['id'] ?>">
    <input type="hidden" name="from" value="<?= e($from) ?>">
    <input type="hidden" name="decision" value="refuser">
    <label class="form-label" for="motif-<?= e($refuseId) ?>">Motif du refus <span class="req">*</span></label>
    <textarea id="motif-<?= e($refuseId) ?>" name="motif_refus" class="form-control mb-1" rows="2" maxlength="500"
              data-rules="required|minlen:5|max:500" placeholder="Ex. : justificatif illisible, numéro d'ordre introuvable…"></textarea>
    <p class="text-danger small field-error" data-error-for="motif_refus"></p>
    <button type="submit" class="btn btn-danger btn-sm">Confirmer le refus</button>
</form>
