
<footer class="app-footer">
    <strong>ANATOMIA</strong> - Administration des comptes
</footer>

</div>
