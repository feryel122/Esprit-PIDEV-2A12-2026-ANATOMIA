<?php
// Attend : $pageData (page, pages, total) et $baseParams (filtres actuels).
if (($pageData['pages'] ?? 1) > 1):
    $link = function ($n) use ($baseParams) {
        return '?' . http_build_query(array_merge($baseParams, ['page' => $n]));
    };
?>
<nav aria-label="Pagination">
    <ul class="pagination justify-content-center mb-0 mt-3">
        <li class="page-item <?= $pageData['page'] <= 1 ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= e($link($pageData['page'] - 1)) ?>">&laquo;</a>
        </li>
        <?php for ($n = 1; $n <= $pageData['pages']; $n++): ?>
            <li class="page-item <?= $n === $pageData['page'] ? 'active' : '' ?>">
                <a class="page-link" href="<?= e($link($n)) ?>"><?= $n ?></a>
            </li>
        <?php endfor; ?>
        <li class="page-item <?= $pageData['page'] >= $pageData['pages'] ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= e($link($pageData['page'] + 1)) ?>">&raquo;</a>
        </li>
    </ul>
</nav>
<?php endif; ?>
