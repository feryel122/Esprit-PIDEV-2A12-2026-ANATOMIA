<?php
// Attend : $scope ('users'|'doctors'), $result (search), $search, $filters, $baseParams
$isDoctors = $scope === 'doctors';
$rows = $result['rows'];
$pageData = $result;
?>
<div class="app-content-header">
    <div class="container-fluid d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
            <h3><?= $isDoctors ? 'Médecins' : 'Utilisateurs' ?></h3>
            <p class="mb-0"><?= (int) $result['total'] ?> compte(s) — recherche, filtres et gestion.</p>
        </div>
        <div class="d-flex gap-2">
            <?php if ($isDoctors): ?>
                <a href="verifier_medecins.php" class="btn btn-warning"><i class="bi bi-patch-check"></i> Vérification</a>
            <?php endif; ?>
            <a href="<?= $isDoctors ? 'ajoutdoctor.php' : 'ajoutuser.php' ?>" class="btn btn-success"><i class="bi bi-plus-lg"></i> Ajouter</a>
        </div>
    </div>
</div>

<form method="get" class="row g-2 mb-3">
    <div class="col-md-5">
        <input class="form-control" type="search" name="q" value="<?= e($search) ?>" maxlength="100"
               placeholder="<?= $isDoctors ? 'Nom, e-mail, spécialité, n° d\'ordre' : 'Nom, prénom, e-mail' ?>">
    </div>
    <?php if ($isDoctors): ?>
        <div class="col-md-3">
            <select class="form-select" name="verification">
                <option value="">Toutes les vérifications</option>
                <?php foreach (['en_attente' => 'En attente', 'verifie' => 'Vérifiés', 'refuse' => 'Refusés'] as $v => $l): ?>
                    <option value="<?= e($v) ?>" <?= ($filters['verification'] ?? '') === $v ? 'selected' : '' ?>><?= e($l) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    <?php else: ?>
        <div class="col-md-3">
            <select class="form-select" name="role">
                <option value="">Tous les rôles</option>
                <option value="utilisateur" <?= ($filters['role'] ?? '') === 'utilisateur' ? 'selected' : '' ?>>Utilisateurs</option>
                <option value="admin" <?= ($filters['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Administrateurs</option>
            </select>
        </div>
    <?php endif; ?>
    <div class="col-md-2">
        <select class="form-select" name="statut">
            <option value="">Tous les comptes</option>
            <option value="actif" <?= ($filters['statut'] ?? '') === 'actif' ? 'selected' : '' ?>>Actifs</option>
            <option value="desactive" <?= ($filters['statut'] ?? '') === 'desactive' ? 'selected' : '' ?>>Désactivés</option>
        </select>
    </div>
    <div class="col-md-2 d-grid"><button class="btn btn-primary" type="submit">Filtrer</button></div>
</form>

<div class="card">
    <div class="card-body table-responsive">
        <table class="table table-bordered table-striped align-middle">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>E-mail</th>
                    <?php if ($isDoctors): ?>
                        <th>Spécialité</th><th>N° d'ordre</th><th>Vérification</th>
                    <?php else: ?>
                        <th>Rôle</th>
                    <?php endif; ?>
                    <th>Compte</th>
                    <th>Inscrit le</th>
                    <th style="min-width:230px">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$rows): ?>
                <tr><td colspan="<?= $isDoctors ? 9 : 7 ?>" class="text-center text-muted">Aucun résultat.</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row):
                $isSelf = (int) $row['id'] === (int) currentUser()['id'];
                $show = $isDoctors ? 'afficherdoctor.php' : 'afficheruser.php';
                $edit = $isDoctors ? 'modifierdoctor.php' : 'modifieruser.php';
                $del = $isDoctors ? 'supprimerdoctor.php' : 'supprimeruser.php';
                $from = $isDoctors ? 'doctors' : 'users'; ?>
                <tr>
                    <td><?= (int) $row['id'] ?></td>
                    <td><?= e(fullName($row)) ?></td>
                    <td><?= e($row['email']) ?></td>
                    <?php if ($isDoctors): ?>
                        <td><?= e(orDash($row['specialite'])) ?></td>
                        <td><?= e(orDash($row['numero_ordre'])) ?></td>
                        <td><?= badgeVerification($row['statut_verification']) ?></td>
                    <?php else: ?>
                        <td><?= badgeRole($row['role']) ?></td>
                    <?php endif; ?>
                    <td><?= badgeAccount($row['statut_compte']) ?></td>
                    <td><?= e(fmtDate($row['created_at'])) ?></td>
                    <td>
                        <div class="d-flex flex-wrap gap-1">
                            <a class="btn btn-info btn-sm" href="<?= $show ?>?id=<?= (int) $row['id'] ?>">Voir</a>
                            <a class="btn btn-warning btn-sm" href="<?= $edit ?>?id=<?= (int) $row['id'] ?>">Modifier</a>
                            <?php if (!$isSelf): ?>
                                <form method="post" action="changer_statut.php"
                                      data-confirm="<?= $row['statut_compte'] === 'actif' ? 'Désactiver ce compte ?' : 'Réactiver ce compte ?' ?>">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                    <input type="hidden" name="from" value="<?= e($from) ?>">
                                    <input type="hidden" name="action" value="<?= $row['statut_compte'] === 'actif' ? 'desactiver' : 'activer' ?>">
                                    <button type="submit" class="btn btn-secondary btn-sm">
                                        <?= $row['statut_compte'] === 'actif' ? 'Désactiver' : 'Activer' ?>
                                    </button>
                                </form>
                                <a class="btn btn-danger btn-sm" href="<?= $del ?>?id=<?= (int) $row['id'] ?>">Supprimer</a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php require __DIR__ . '/../partials/pagination.php'; ?>
    </div>
</div>
