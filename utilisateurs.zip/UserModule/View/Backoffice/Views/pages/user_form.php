<?php
// Attend : $mode ('user'|'doctor'), $account (valeurs), $errors, $formTitle, $isEdit, $isSelf
$ui = ['ui' => 'admin'];
$isDoctor = $mode === 'doctor';
$backUrl = $isDoctor ? 'afficherdoctors.php' : 'afficherusers.php';
$currentRole = $account['role'] ?? 'utilisateur';
?>
<div class="app-content-header">
    <div class="container-fluid"><h3><?= e($formTitle) ?></h3></div>
</div>
<div class="card">
    <div class="card-body">
        <?php if (isset($errors['_global'])): ?><div class="alert alert-danger"><?= e($errors['_global']) ?></div><?php endif; ?>
        <?php if ($errors && !isset($errors['_global'])): ?><div class="alert alert-danger">Veuillez corriger les champs signalés.</div><?php endif; ?>

        <form method="post" class="row g-3" data-validate novalidate>
            <?= csrfField() ?>
            <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= (int) $account['id'] ?>"><?php endif; ?>

            <?= formInput('prenom', 'Prénom', $account['prenom'] ?? '', $errors, $ui + ['required' => 1, 'rules' => 'required|name', 'maxlength' => 100]) ?>
            <?= formInput('nom', 'Nom', $account['nom'] ?? '', $errors, $ui + ['required' => 1, 'rules' => 'required|name', 'maxlength' => 100]) ?>
            <?= formInput('email', 'E-mail', $account['email'] ?? '', $errors, $ui + ['type' => 'email', 'required' => 1, 'rules' => 'required|email', 'maxlength' => 190]) ?>
            <?= formInput('telephone', $isDoctor ? 'Téléphone' : 'Téléphone (facultatif)', $account['telephone'] ?? '', $errors, $ui + ['type' => 'tel', 'required' => $isDoctor ? 1 : 0, 'rules' => ($isDoctor ? 'required|' : '') . 'phone', 'maxlength' => 20]) ?>
            <?= formInput('password', $isEdit ? 'Nouveau mot de passe (laisser vide pour conserver)' : 'Mot de passe', '', $errors, $ui + ['type' => 'password', 'required' => $isEdit ? 0 : 1, 'rules' => ($isEdit ? '' : 'required|') . 'password', 'hint' => '8 caractères minimum, avec une lettre et un chiffre.', 'autocomplete' => 'new-password']) ?>
            <?= formInput('confirm_password', 'Confirmation', '', $errors, $ui + ['type' => 'password', 'required' => $isEdit ? 0 : 1, 'rules' => ($isEdit ? '' : 'required|') . 'match:password', 'autocomplete' => 'new-password']) ?>

            <?php if (!$isDoctor): ?>
                <?= formSelect('role', 'Rôle', $currentRole, $errors,
                    ['utilisateur' => 'Utilisateur', 'admin' => 'Administrateur'],
                    $ui + ['required' => 1, 'disabled' => !empty($isSelf), 'hint' => !empty($isSelf) ? 'Vous ne pouvez pas modifier votre propre rôle.' : null] + ['role_toggle' => 1]) ?>
            <?php endif; ?>

            <?php if ($isDoctor): ?>
                <?= formInput('date_naissance', 'Date de naissance (facultatif)', $account['date_naissance'] ?? '', $errors, $ui + ['type' => 'date', 'rules' => 'pastdate']) ?>
                <?= formSelect('genre', 'Genre (facultatif)', $account['genre'] ?? '', $errors, genreOptions(), $ui + ['empty' => '—']) ?>
                <?= formSelect('specialite', 'Spécialité', $account['specialite'] ?? '', $errors, specialiteOptions(), $ui + ['required' => 1, 'rules' => 'required', 'empty' => '— Choisir —']) ?>
                <?= formInput('numero_ordre', 'N° d\'ordre / d\'inscription', $account['numero_ordre'] ?? '', $errors, $ui + ['required' => 1, 'rules' => 'required|ordre', 'maxlength' => 20]) ?>
                <?= formInput('ville', 'Ville du cabinet (facultatif)', $account['ville'] ?? '', $errors, $ui + ['maxlength' => 100, 'rules' => 'max:100']) ?>
                <div class="col-md-6"></div>
                <?= formTextarea('bio', 'Présentation (facultatif)', $account['bio'] ?? '', $errors, $ui + ['col' => 'col-12', 'maxlength' => 1000, 'rules' => 'max:1000', 'rows' => 3]) ?>
                <?php if (!$isEdit): ?>
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="verifier_maintenant" value="1" id="verifier_maintenant" <?= !empty($account['verifier_maintenant']) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="verifier_maintenant">Marquer ce médecin comme vérifié immédiatement (sinon : « en attente »)</label>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-12">
                        <div class="alert alert-info mb-0">Statut de vérification : <?= badgeVerification($account['statut_verification'] ?? null) ?>
                            — à modifier depuis la fiche du médecin ou la page <a href="verifier_medecins.php">Vérification</a>.</div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="col-12" id="health-fields">
                    <div class="row g-3">
                        <?= formInput('date_naissance', 'Date de naissance (facultatif)', $account['date_naissance'] ?? '', $errors, $ui + ['type' => 'date', 'col' => 'col-md-3', 'rules' => 'pastdate']) ?>
                        <?= formSelect('genre', 'Genre (facultatif)', $account['genre'] ?? '', $errors, genreOptions(), $ui + ['col' => 'col-md-3', 'empty' => '—']) ?>
                        <?= formInput('taille', 'Taille (cm)', $account['taille'] ?? '', $errors, $ui + ['type' => 'number', 'step' => '0.1', 'col' => 'col-md-3', 'rules' => 'range:50:250']) ?>
                        <?= formInput('poids', 'Poids (kg)', $account['poids'] ?? '', $errors, $ui + ['type' => 'number', 'step' => '0.1', 'col' => 'col-md-3', 'rules' => 'range:20:300']) ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="col-12">
                <button class="btn btn-success" type="submit">Enregistrer</button>
                <a class="btn btn-secondary" href="<?= e($backUrl) ?>">Retour</a>
            </div>
        </form>
    </div>
</div>
