<div class="app-content-header">
    <div class="container-fluid">
        <h3 class="mb-0">Tableau de bord</h3>
        <p>Vue d'ensemble des comptes ANATOMIA.</p>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <?php
        $boxes = [
            ['Utilisateurs', $stats['users'], 'text-bg-primary', 'bi-people', 'afficherusers.php'],
            ['Médecins', $stats['doctors'], 'text-bg-info', 'bi-heart-pulse', 'afficherdoctors.php'],
            ['À vérifier', $stats['pending'], 'text-bg-warning', 'bi-hourglass-split', 'verifier_medecins.php'],
            ['Médecins vérifiés', $stats['verified'], 'text-bg-success', 'bi-patch-check', 'afficherdoctors.php?verification=verifie'],
            ['Dossiers refusés', $stats['refused'], 'text-bg-danger', 'bi-x-octagon', 'afficherdoctors.php?verification=refuse'],
            ['Comptes désactivés', $stats['inactive'], 'text-bg-secondary', 'bi-person-slash', 'afficherusers.php?statut=desactive'],
        ];
        foreach ($boxes as [$label, $value, $class, $icon, $href]): ?>
            <div class="col-lg-4 col-md-6">
                <a href="<?= e($href) ?>" class="text-decoration-none">
                    <div class="small-box <?= e($class) ?>">
                        <div class="inner">
                            <h3><?= (int) $value ?></h3>
                            <p><?= e($label) ?></p>
                        </div>
                        <div class="small-box-icon"><i class="bi <?= e($icon) ?>"></i></div>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title mb-0">Médecins en attente de vérification</h3>
                    <a href="verifier_medecins.php" class="btn btn-sm btn-outline-primary">Tout voir</a>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-striped mb-0 align-middle">
                        <thead><tr><th>Médecin</th><th>Spécialité</th><th>Inscrit le</th><th></th></tr></thead>
                        <tbody>
                        <?php if (!$pending): ?>
                            <tr><td colspan="4" class="text-center text-muted">Aucun dossier en attente.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($pending as $doc): ?>
                            <tr>
                                <td><?= e('Dr ' . fullName($doc)) ?></td>
                                <td><?= e(orDash($doc['specialite'])) ?></td>
                                <td><?= e(fmtDate($doc['created_at'])) ?></td>
                                <td><a class="btn btn-sm btn-warning" href="afficheruser.php?id=<?= (int) $doc['id'] ?>">Examiner</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-header"><h3 class="card-title mb-0">Dernières inscriptions</h3></div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-striped mb-0 align-middle">
                        <thead><tr><th>Nom</th><th>Rôle</th><th>Inscrit le</th></tr></thead>
                        <tbody>
                        <?php if (!$latest): ?>
                            <tr><td colspan="3" class="text-center text-muted">Aucun compte.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($latest as $row): ?>
                            <tr>
                                <td><a href="afficheruser.php?id=<?= (int) $row['id'] ?>"><?= e(fullName($row)) ?></a></td>
                                <td><?= badgeRole($row['role']) ?></td>
                                <td><?= e(fmtDate($row['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-2">
        <div class="card-header"><h3 class="card-title mb-0">Répartition des médecins</h3></div>
        <div class="card-body">
            <?php
            $total = max(1, $stats['doctors']);
            $bars = [['En attente', $stats['pending'], 'bg-warning'], ['Vérifiés', $stats['verified'], 'bg-success'], ['Refusés', $stats['refused'], 'bg-danger']];
            foreach ($bars as [$label, $value, $class]):
                $pct = (int) round($value * 100 / $total); ?>
                <div class="mb-3">
                    <div class="d-flex justify-content-between"><span><?= e($label) ?></span><span><?= (int) $value ?></span></div>
                    <div class="progress"><div class="progress-bar <?= e($class) ?>" style="width: <?= $pct ?>%"></div></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
