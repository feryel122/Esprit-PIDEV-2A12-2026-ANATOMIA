/* ANATOMIA — interactions communes (Front Office + Back Office) */
document.addEventListener('DOMContentLoaded', function () {
    // Menu mobile
    var toggle = document.querySelector('.nav-toggle');
    var nav = document.getElementById('mainNav');
    if (toggle && nav) {
        toggle.addEventListener('click', function () { nav.classList.toggle('open'); });
    }

    // Confirmation avant action sensible : <form data-confirm="Message ?">
    Array.prototype.forEach.call(document.querySelectorAll('form[data-confirm]'), function (form) {
        form.addEventListener('submit', function (ev) {
            if (ev.defaultPrevented) { return; } // déjà bloqué par la validation
            if (!window.confirm(form.getAttribute('data-confirm'))) { ev.preventDefault(); }
        });
    });

    // Affiche le champ « motif de refus » seulement quand on clique sur Refuser
    Array.prototype.forEach.call(document.querySelectorAll('[data-toggle-target]'), function (btn) {
        btn.addEventListener('click', function () {
            var box = document.getElementById(btn.getAttribute('data-toggle-target'));
            if (box) { box.hidden = !box.hidden; var f = box.querySelector('textarea,input'); if (f && !box.hidden) { f.focus(); } }
        });
    });

    // Masquer / afficher un mot de passe
    Array.prototype.forEach.call(document.querySelectorAll('[data-show-password]'), function (btn) {
        btn.addEventListener('click', function () {
            var input = document.getElementById(btn.getAttribute('data-show-password'));
            if (input) { input.type = input.type === 'password' ? 'text' : 'password'; }
        });
    });

    // Formulaire admin : masque les champs « santé » quand le rôle choisi est Administrateur
    var roleSelect = document.querySelector('[data-role-select]');
    var health = document.getElementById('health-fields');
    if (roleSelect && health) {
        var sync = function () { health.hidden = roleSelect.value === 'admin'; };
        roleSelect.addEventListener('change', sync);
        sync();
    }
});
