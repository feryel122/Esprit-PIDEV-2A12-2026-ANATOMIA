/* ANATOMIA — validation côté client (confort : le serveur PHP revalide toujours).
   Usage : <form data-validate novalidate> ... <input name="email" data-rules="required|email"> */
(function () {
    'use strict';

    var NAME = /^[A-Za-zÀ-ÖØ-öø-ÿ][A-Za-zÀ-ÖØ-öø-ÿ '\-]{1,99}$/;

    var rules = {
        required: function (v, p, f) {
            if (f.type === 'file') { return f.files.length > 0 ? null : 'Ce champ est obligatoire.'; }
            return v.trim() !== '' ? null : 'Ce champ est obligatoire.';
        },
        email: function (v) {
            return v === '' || (v.length <= 190 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) ? null : 'Adresse e-mail invalide.';
        },
        name: function (v) {
            return v === '' || NAME.test(v.trim()) ? null : 'Lettres uniquement, 2 à 100 caractères.';
        },
        phone: function (v) {
            return v === '' || /^\+?[0-9]{8,15}$/.test(v.replace(/[\s.\-]/g, '')) ? null : 'Numéro invalide (8 à 15 chiffres).';
        },
        max: function (v, p) {
            return v.length <= +p[0] ? null : 'Maximum ' + p[0] + ' caractères.';
        },
        password: function (v) {
            if (v === '') { return null; }
            if (v.length < 8) { return 'Au moins 8 caractères.'; }
            if (v.length > 72) { return 'Maximum 72 caractères.'; }
            return /[A-Za-z]/.test(v) && /\d/.test(v) ? null : 'Au moins une lettre et un chiffre.';
        },
        match: function (v, p, f) {
            var other = f.form.elements[p[0]];
            return !other || v === other.value ? null : 'La confirmation ne correspond pas.';
        },
        range: function (v, p) {
            if (v === '') { return null; }
            var n = parseFloat(v.replace(',', '.'));
            return !isNaN(n) && n >= +p[0] && n <= +p[1] ? null : 'Valeur comprise entre ' + p[0] + ' et ' + p[1] + '.';
        },
        pastdate: function (v) {
            if (v === '') { return null; }
            var today = new Date().toISOString().slice(0, 10);
            return /^\d{4}-\d{2}-\d{2}$/.test(v) && v <= today && v >= '1900-01-01' ? null : 'Date invalide.';
        },
        ordre: function (v) {
            return v === '' || /^[A-Za-z0-9\-\/]{4,20}$/.test(v.trim()) ? null : 'De 4 à 20 caractères : lettres, chiffres, - ou /.';
        },
        file: function (v, p, f) {
            if (!f.files || f.files.length === 0) { return null; }
            var file = f.files[0];
            var ok = /\.(pdf|jpe?g|png)$/i.test(file.name);
            if (!ok) { return 'Formats acceptés : PDF, JPG, PNG.'; }
            return file.size <= (+p[0]) * 1048576 ? null : 'Fichier trop lourd (' + p[0] + ' Mo maximum).';
        },
        minlen: function (v, p) {
            return v.trim().length >= +p[0] ? null : 'Au moins ' + p[0] + ' caractères.';
        }
    };

    function isActive(field) {
        // Ignore les champs désactivés ou dans une zone masquée.
        return !field.disabled && field.closest('[hidden]') === null;
    }

    function check(field) {
        var spec = field.getAttribute('data-rules');
        if (!spec || !isActive(field)) { return null; }
        var parts = spec.split('|');
        for (var i = 0; i < parts.length; i++) {
            var seg = parts[i].split(':');
            var fn = rules[seg[0]];
            if (!fn) { continue; }
            var msg = fn(field.value, seg.slice(1), field);
            if (msg) { return msg; }
        }
        return null;
    }

    function show(field, msg) {
        var holder = field.form.querySelector('[data-error-for="' + field.name + '"]');
        if (holder) { holder.textContent = msg || ''; }
        field.classList.toggle('is-invalid', !!msg);
        field.setAttribute('aria-invalid', msg ? 'true' : 'false');
    }

    function validateForm(form) {
        var first = null;
        Array.prototype.forEach.call(form.querySelectorAll('[data-rules]'), function (f) {
            var msg = check(f);
            show(f, msg);
            if (msg && !first) { first = f; }
        });
        if (first) { first.focus(); }
        return !first;
    }

    document.addEventListener('DOMContentLoaded', function () {
        Array.prototype.forEach.call(document.querySelectorAll('form[data-validate]'), function (form) {
            form.setAttribute('novalidate', 'novalidate');
            form.addEventListener('submit', function (ev) {
                if (!validateForm(form)) { ev.preventDefault(); }
            });
            // Retour immédiat à la saisie / à la sortie du champ.
            form.addEventListener('blur', function (ev) {
                if (ev.target.matches && ev.target.matches('[data-rules]')) { show(ev.target, check(ev.target)); }
            }, true);
            form.addEventListener('input', function (ev) {
                var t = ev.target;
                if (t.matches && t.matches('[data-rules]') && t.classList.contains('is-invalid')) { show(t, check(t)); }
            });
            form.addEventListener('change', function (ev) {
                if (ev.target.matches && ev.target.matches('[data-rules]')) { show(ev.target, check(ev.target)); }
            });
        });
    });
})();
