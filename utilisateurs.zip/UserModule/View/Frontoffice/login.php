<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/forms.php';
require_once __DIR__ . '/../../Controller/UserController.php';

if (isLoggedIn()) {
    redirect(homeFor(userRole()));
}

$controller = new UserController();
$errors = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mb_strtolower(trim(is_string($_POST['email'] ?? null) ? $_POST['email'] : ''));
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';

    if (!verifyCsrf()) {
        $errors['_global'] = 'La session a expiré. Rechargez la page et réessayez.';
    } elseif ($email === '' || $password === '') {
        $errors['_global'] = 'Saisissez votre e-mail et votre mot de passe.';
    } else {
        $result = $controller->authenticate($email, $password);
        if ($result['user']) {
            loginSession($result['user']);
            setFlash('Connexion réussie. Bienvenue ' . $result['user']['prenom'] . ' !');
            redirect(homeFor($result['user']['role']));
        }
        $errors['_global'] = $result['error'];
    }
}

$pageTitle = 'Connexion - ANATOMIA';
$currentPage = 'login';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>
<main class="community">
    <?php require __DIR__ . '/includes/flash.php'; ?>
    <div class="section-heading">
        <h2>Connexion</h2>
        <p>Accédez à votre espace personnel.</p>
    </div>
    <section class="auth-card narrow">
        <?php if (isset($errors['_global'])): ?><div class="notice notice-error"><?= e($errors['_global']) ?></div><?php endif; ?>
        <form method="post" class="stack" data-validate novalidate>
            <?= csrfField() ?>
            <?= formInput('email', 'E-mail', $email, [], ['type' => 'email', 'required' => 1, 'rules' => 'required|email', 'autocomplete' => 'username']) ?>
            <?= formInput('password', 'Mot de passe', '', [], ['type' => 'password', 'required' => 1, 'rules' => 'required', 'autocomplete' => 'current-password']) ?>
            <div class="form-actions" style="margin-top:6px"><button type="submit">Se connecter</button></div>
        </form>
        <p style="margin-top:18px">Pas encore de compte ? <a href="inscription_utilisateur.php"><strong>Inscription utilisateur</strong></a> · <a href="inscription_medecin.php"><strong>Inscription médecin</strong></a></p>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
