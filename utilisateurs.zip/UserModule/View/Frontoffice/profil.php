<?php
require_once __DIR__ . '/../../includes/bootstrap.php';

// Aiguillage vers la page de profil adaptée au rôle.
requireLogin();
redirect(homeFor(userRole()));
