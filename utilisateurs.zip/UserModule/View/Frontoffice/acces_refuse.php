<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/forms.php';

http_response_code(403);
$me = currentUser();
$pageTitle = 'Accès refusé - ANATOMIA';
$currentPage = '';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>
<main class="community">
    <section class="auth-card narrow error-page">
        <div class="code">403</div>
        <h3>Accès refusé</h3>
        <p>Vous n'avez pas l'autorisation d'accéder à cette page.</p>
        <div class="inline-actions" style="justify-content:center">
            <?php if ($me): ?>
                <a href="<?= e(homeFor($me['role'])) ?>">Retour à mon espace</a>
            <?php else: ?>
                <a href="login.php">Se connecter</a>
            <?php endif; ?>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
