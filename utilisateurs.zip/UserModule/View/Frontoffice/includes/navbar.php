<?php $me = currentUser(); ?>
<header class="header">
    <div class="logo">
        <a href="accueil.php">
            <img src="../Assets/images/logo.png" alt="ANATOMIA">
        </a>
    </div>

    <button type="button" class="nav-toggle" aria-label="Ouvrir le menu">Menu</button>

    <nav class="navigation" id="mainNav">
        <a href="accueil.php" class="<?= ($currentPage ?? '') === 'accueil' ? 'active' : '' ?>">Accueil</a>
        <?php if ($me && $me['role'] === 'utilisateur'): ?>
            <a href="profil_utilisateur.php" class="<?= ($currentPage ?? '') === 'profil' ? 'active' : '' ?>">Mon profil</a>
        <?php elseif ($me && $me['role'] === 'medecin'): ?>
            <a href="profil_medecin.php" class="<?= ($currentPage ?? '') === 'profil' ? 'active' : '' ?>">Mon profil</a>
            <a href="espace_medecin.php" class="<?= ($currentPage ?? '') === 'espace' ? 'active' : '' ?>">Espace médecin</a>
        <?php elseif ($me && $me['role'] === 'admin'): ?>
            <a href="../Backoffice/adminlte/dashboard.php">Administration</a>
        <?php endif; ?>
        <?php if ($me && $me['role'] !== 'admin'): ?>
            <a href="modifier_profil.php" class="<?= ($currentPage ?? '') === 'modifier' ? 'active' : '' ?>">Modifier mon profil</a>
        <?php endif; ?>
        <a href="#" title="Module Recettes — autre membre de l'équipe">Recettes</a>
        <a href="#" title="Module Articles — autre membre de l'équipe">Articles</a>
        <a href="#" title="Module Forum — autre membre de l'équipe">Forum</a>
    </nav>

    <div class="header-icons">
        <?php if ($me): ?>
            <span><?= e(fullName($me)) ?><?php if (isVerifiedDoctor($me)): ?><span class="badge-role">Médecin vérifié</span><?php endif; ?></span>
            <form method="post" action="logout.php" class="logout-form">
                <?= csrfField() ?>
                <button type="submit">Déconnexion</button>
            </form>
        <?php else: ?>
            <a href="login.php">Connexion</a>
            <a href="inscription_utilisateur.php">Inscription</a>
        <?php endif; ?>
    </div>
</header>
