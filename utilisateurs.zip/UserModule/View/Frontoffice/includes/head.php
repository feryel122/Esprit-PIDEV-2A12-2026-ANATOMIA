<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'ANATOMIA') ?></title>
    <link rel="stylesheet" href="../Assets/css/forum.css">
    <link rel="stylesheet" href="../Assets/css/user.css">
</head>
