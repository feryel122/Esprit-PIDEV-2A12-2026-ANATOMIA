<script src="../Assets/js/validation.js"></script>
<script src="../Assets/js/app.js"></script>
