<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/forms.php';
$me = currentUser();
$pageTitle = 'Accueil - ANATOMIA';
$currentPage = 'accueil';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>

<section class="hero">
    <div class="hero-content">
        <p class="hero-label">SANTÉ NATURELLE</p>
        <h1>Bienvenue sur ANATOMIA</h1>
        <p class="hero-description">
            Un espace pour comprendre le corps et trouver des conseils adaptés à votre profil,
            avec des professionnels de santé vérifiés.
        </p>
        <?php if ($me): ?>
            <a href="<?= e(homeFor($me['role'])) ?>" class="hero-button">Accéder à mon espace</a>
        <?php else: ?>
            <a href="inscription_utilisateur.php" class="hero-button">Créer mon compte</a>
        <?php endif; ?>
    </div>
</section>

<main class="community">
    <?php require __DIR__ . '/includes/flash.php'; ?>
    <?php if (!$me): ?>
    <div class="section-heading">
        <h2>Rejoindre ANATOMIA</h2>
        <p>Choisissez le type de compte qui vous correspond.</p>
    </div>
    <div class="cards-3">
        <section class="profile-card">
            <h3>Je suis un utilisateur</h3>
            <p>Créez votre profil santé et profitez de la communauté.</p>
            <div class="inline-actions"><a href="inscription_utilisateur.php">Inscription utilisateur</a></div>
        </section>
        <section class="profile-card">
            <h3>Je suis médecin</h3>
            <p>Inscrivez-vous avec votre justificatif : un administrateur vérifiera votre dossier.</p>
            <div class="inline-actions"><a href="inscription_medecin.php">Inscription médecin</a></div>
        </section>
        <section class="profile-card">
            <h3>J'ai déjà un compte</h3>
            <p>Connectez-vous pour accéder à votre profil.</p>
            <div class="inline-actions"><a href="login.php" class="ghost-button">Connexion</a></div>
        </section>
    </div>
    <?php endif; ?>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
