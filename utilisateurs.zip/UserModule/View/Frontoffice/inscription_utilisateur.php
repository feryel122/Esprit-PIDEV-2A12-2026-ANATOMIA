<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/validation.php';
require_once __DIR__ . '/../../includes/forms.php';
require_once __DIR__ . '/../../Controller/UserController.php';

if (isLoggedIn()) {
    redirect(homeFor(userRole()));
}

$controller = new UserController();
$errors = [];
$old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $errors['_global'] = 'La session a expiré. Rechargez la page et réessayez.';
    } else {
        // Le rôle est imposé côté serveur : aucun champ du formulaire ne peut le modifier.
        [$user, $errors] = collectUserInput('utilisateur', 'required');
        $old = $user->toFormArray();
        if (!isset($errors['email']) && $controller->findByEmail($user->getEmail())) {
            $errors['email'] = 'Cet e-mail est déjà utilisé.';
        }
        if (!$errors) {
            if ($controller->create($user)) {
                setFlash('Compte créé avec succès. Vous pouvez maintenant vous connecter.');
                redirect('login.php');
            }
            $errors['_global'] = 'Impossible de créer le compte pour le moment.';
        }
    }
}

$pageTitle = 'Inscription utilisateur - ANATOMIA';
$currentPage = 'inscription';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>
<main class="community">
    <div class="section-heading">
        <h2>Inscription utilisateur</h2>
        <p>Créez votre compte membre. Vous êtes médecin ? <a href="inscription_medecin.php"><strong>Inscription médecin</strong></a></p>
    </div>
    <section class="auth-card wide">
        <?php if (isset($errors['_global'])): ?><div class="notice notice-error"><?= e($errors['_global']) ?></div><?php endif; ?>
        <?php if ($errors && !isset($errors['_global'])): ?><div class="notice notice-error">Veuillez corriger les champs signalés.</div><?php endif; ?>
        <form method="post" data-validate novalidate>
            <?= csrfField() ?>
            <div class="form-grid">
                <?= formInput('prenom', 'Prénom', $old['prenom'] ?? '', $errors, ['required' => 1, 'rules' => 'required|name', 'maxlength' => 100, 'autocomplete' => 'given-name']) ?>
                <?= formInput('nom', 'Nom', $old['nom'] ?? '', $errors, ['required' => 1, 'rules' => 'required|name', 'maxlength' => 100, 'autocomplete' => 'family-name']) ?>
                <?= formInput('email', 'E-mail', $old['email'] ?? '', $errors, ['type' => 'email', 'full' => 1, 'required' => 1, 'rules' => 'required|email', 'maxlength' => 190, 'autocomplete' => 'email']) ?>
                <?= formInput('password', 'Mot de passe', '', $errors, ['type' => 'password', 'required' => 1, 'rules' => 'required|password', 'hint' => '8 caractères minimum, avec une lettre et un chiffre.', 'autocomplete' => 'new-password']) ?>
                <?= formInput('confirm_password', 'Confirmer le mot de passe', '', $errors, ['type' => 'password', 'required' => 1, 'rules' => 'required|match:password', 'autocomplete' => 'new-password']) ?>
                <?= formInput('telephone', 'Téléphone (facultatif)', $old['telephone'] ?? '', $errors, ['type' => 'tel', 'rules' => 'phone', 'maxlength' => 20, 'autocomplete' => 'tel']) ?>
                <?= formInput('date_naissance', 'Date de naissance (facultatif)', $old['date_naissance'] ?? '', $errors, ['type' => 'date', 'rules' => 'pastdate']) ?>
                <?= formSelect('genre', 'Genre (facultatif)', $old['genre'] ?? '', $errors, genreOptions(), ['empty' => '— Non précisé —']) ?>
                <?= formInput('taille', 'Taille en cm (facultatif)', $old['taille'] ?? '', $errors, ['type' => 'number', 'step' => '0.1', 'rules' => 'range:50:250']) ?>
                <?= formInput('poids', 'Poids en kg (facultatif)', $old['poids'] ?? '', $errors, ['type' => 'number', 'step' => '0.1', 'rules' => 'range:20:300']) ?>
            </div>
            <div class="form-actions">
                <button type="submit">Créer mon compte</button>
                <a class="btn-ghost" href="login.php">J'ai déjà un compte</a>
            </div>
        </form>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
