<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/validation.php';
require_once __DIR__ . '/../../includes/upload.php';
require_once __DIR__ . '/../../includes/forms.php';
require_once __DIR__ . '/../../Controller/UserController.php';

if (isLoggedIn()) {
    redirect(homeFor(userRole()));
}

$controller = new UserController();
$errors = [];
$old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $errors['_global'] = 'La session a expiré (ou le fichier est trop volumineux). Rechargez la page et réessayez.';
    } else {
        [$user, $errors] = collectUserInput('medecin', 'required');
        $old = $user->toFormArray();

        [$fileError, $mime] = validateJustificatif(true);
        if ($fileError) {
            $errors['justificatif'] = $fileError;
        }
        if (!isset($errors['email']) && $controller->findByEmail($user->getEmail())) {
            $errors['email'] = 'Cet e-mail est déjà utilisé.';
        }
        if (!isset($errors['numero_ordre']) && $controller->ordreTakenByOther($user->getNumeroOrdre())) {
            $errors['numero_ordre'] = 'Ce numéro d\'ordre est déjà enregistré.';
        }

        if (!$errors) {
            $stored = storeJustificatif($mime);
            if ($stored === null) {
                $errors['_global'] = 'Impossible d\'enregistrer le justificatif.';
            } else {
                $user->setJustificatif($stored[0], $stored[1], $stored[2]);
                if ($controller->create($user)) {
                    setFlash('Demande envoyée. Votre compte médecin sera vérifié par un administrateur : vous pouvez vous connecter, mais vous ne serez pas considéré comme médecin vérifié avant la validation.');
                    redirect('login.php');
                }
                deleteJustificatif($stored[0]);
                $errors['_global'] = 'Impossible de créer le compte pour le moment.';
            }
        }
    }
}

$pageTitle = 'Inscription médecin - ANATOMIA';
$currentPage = 'inscription';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>
<main class="community">
    <div class="section-heading">
        <h2>Inscription médecin</h2>
        <p>Votre dossier sera examiné par l'administration avant d'obtenir le statut « vérifié ».</p>
    </div>
    <section class="auth-card wide">
        <?php if (isset($errors['_global'])): ?><div class="notice notice-error"><?= e($errors['_global']) ?></div><?php endif; ?>
        <?php if ($errors && !isset($errors['_global'])): ?><div class="notice notice-error">Veuillez corriger les champs signalés.</div><?php endif; ?>
        <form method="post" enctype="multipart/form-data" data-validate novalidate>
            <?= csrfField() ?>
            <div class="form-grid">
                <h4 class="form-section-title" style="border-top:0;margin-top:0">Identité</h4>
                <?= formInput('prenom', 'Prénom', $old['prenom'] ?? '', $errors, ['required' => 1, 'rules' => 'required|name', 'maxlength' => 100, 'autocomplete' => 'given-name']) ?>
                <?= formInput('nom', 'Nom', $old['nom'] ?? '', $errors, ['required' => 1, 'rules' => 'required|name', 'maxlength' => 100, 'autocomplete' => 'family-name']) ?>
                <?= formInput('email', 'E-mail', $old['email'] ?? '', $errors, ['type' => 'email', 'required' => 1, 'rules' => 'required|email', 'maxlength' => 190, 'autocomplete' => 'email']) ?>
                <?= formInput('telephone', 'Téléphone', $old['telephone'] ?? '', $errors, ['type' => 'tel', 'required' => 1, 'rules' => 'required|phone', 'maxlength' => 20, 'autocomplete' => 'tel']) ?>
                <?= formInput('password', 'Mot de passe', '', $errors, ['type' => 'password', 'required' => 1, 'rules' => 'required|password', 'hint' => '8 caractères minimum, avec une lettre et un chiffre.', 'autocomplete' => 'new-password']) ?>
                <?= formInput('confirm_password', 'Confirmer le mot de passe', '', $errors, ['type' => 'password', 'required' => 1, 'rules' => 'required|match:password', 'autocomplete' => 'new-password']) ?>
                <?= formInput('date_naissance', 'Date de naissance (facultatif)', $old['date_naissance'] ?? '', $errors, ['type' => 'date', 'rules' => 'pastdate']) ?>
                <?= formSelect('genre', 'Genre (facultatif)', $old['genre'] ?? '', $errors, genreOptions(), ['empty' => '— Non précisé —']) ?>

                <h4 class="form-section-title">Informations professionnelles</h4>
                <?= formSelect('specialite', 'Spécialité', $old['specialite'] ?? '', $errors, specialiteOptions(), ['required' => 1, 'rules' => 'required', 'empty' => '— Choisir —']) ?>
                <?= formInput('numero_ordre', 'Numéro d\'ordre / d\'inscription', $old['numero_ordre'] ?? '', $errors, ['required' => 1, 'rules' => 'required|ordre', 'maxlength' => 20]) ?>
                <?= formInput('ville', 'Ville du cabinet (facultatif)', $old['ville'] ?? '', $errors, ['maxlength' => 100, 'rules' => 'max:100']) ?>
                <?= formInput('justificatif', 'Justificatif (diplôme ou carte professionnelle)', '', $errors, ['type' => 'file', 'required' => 1, 'rules' => 'required|file:3', 'accept' => '.pdf,.jpg,.jpeg,.png', 'hint' => 'PDF, JPG ou PNG — 3 Mo maximum.']) ?>
                <?= formTextarea('bio', 'Présentation (facultatif)', $old['bio'] ?? '', $errors, ['full' => 1, 'maxlength' => 1000, 'rules' => 'max:1000', 'rows' => 4]) ?>
            </div>
            <div class="form-actions">
                <button type="submit">Envoyer ma demande</button>
                <a class="btn-ghost" href="inscription_utilisateur.php">Je ne suis pas médecin</a>
            </div>
        </form>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
