<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/upload.php';
require_once __DIR__ . '/../../Controller/UserController.php';

/**
 * Sert un justificatif. Accès : administrateur, ou médecin propriétaire du fichier.
 * Le fichier n'est jamais accessible directement (dossier uploads protégé).
 */
requireRole(['admin', 'medecin']);

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$me = currentUser();
if (!$id || (userRole() !== 'admin' && (int) $me['id'] !== $id)) {
    redirect(url('View/Frontoffice/acces_refuse.php'));
}

$account = (new UserController())->getUserById($id);
$stored = $account['justificatif_fichier'] ?? null;
$path = isValidStoredName($stored) ? justificatifDir() . '/' . $stored : null;
if ($path === null || !is_file($path)) {
    http_response_code(404);
    exit('Justificatif introuvable.');
}

$mime = $account['justificatif_mime'];
if (!in_array($mime, array_keys(JUSTIFICATIF_TYPES), true)) {
    http_response_code(404);
    exit('Justificatif introuvable.');
}

// Réponse brute (pas de HTML) : on retire les en-têtes qui gêneraient l'affichage du PDF dans le navigateur.
header_remove('Content-Security-Policy');
header_remove('X-Frame-Options');
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="justificatif-' . $id . '.' . JUSTIFICATIF_TYPES[$mime] . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($path);
exit;
