<?php
header('Location: inscription_utilisateur.php');
exit;
