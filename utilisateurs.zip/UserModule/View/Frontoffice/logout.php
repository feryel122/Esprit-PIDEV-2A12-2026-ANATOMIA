<?php
require_once __DIR__ . '/../../includes/bootstrap.php';

// La déconnexion se fait en POST avec jeton CSRF (évite une déconnexion forcée par un lien externe).
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verifyCsrf()) {
    redirect(isLoggedIn() ? homeFor(userRole()) : 'login.php');
}

destroySession();
session_start();
setFlash('Vous avez été déconnecté.');
redirect('login.php');
