<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/forms.php';

// Réservé aux médecins DONT LE DOSSIER EST VALIDÉ : un médecin en attente ou refusé est renvoyé vers son profil.
requireVerifiedDoctor();
$account = currentUser();

$pageTitle = 'Espace médecin - ANATOMIA';
$currentPage = 'espace';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>
<main class="community">
    <?php require __DIR__ . '/includes/flash.php'; ?>
    <section class="hero" style="width:100%;margin:0 0 30px;">
        <div class="hero-content">
            <p class="hero-label">ESPACE MÉDECIN</p>
            <h1>Dr <?= e(fullName($account)) ?></h1>
            <p class="hero-description"><?= e(orDash($account['specialite'])) ?> — médecin vérifié</p>
        </div>
    </section>
    <section class="profile-card">
        <h3>Votre statut</h3>
        <p>Votre identité professionnelle a été validée par l'administration. Les fonctionnalités réservées
           aux médecins vérifiés (modules des autres membres de l'équipe) s'appuieront sur ce statut.</p>
        <div class="inline-actions">
            <a href="profil_medecin.php">Mon profil</a>
            <a href="modifier_profil.php" class="ghost-button">Modifier mes informations</a>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
