<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/forms.php';

// Page réservée aux médecins (en attente, vérifiés ou refusés) : un utilisateur normal est renvoyé en 403.
requireRole(['medecin']);
$account = currentUser();
$status = $account['statut_verification'] ?: 'en_attente';

$pageTitle = 'Profil médecin - ANATOMIA';
$currentPage = 'profil';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>
<main class="community">
    <?php require __DIR__ . '/includes/flash.php'; ?>
    <div class="section-heading">
        <h2>Profil médecin</h2>
        <p>Vos informations professionnelles et l'état de votre vérification.</p>
    </div>

    <?php if ($status === 'en_attente'): ?>
        <div class="banner en_attente"><strong>Dossier en attente de validation.</strong>
            Un administrateur examine votre justificatif. Tant qu'il n'est pas validé, vous n'êtes pas considéré comme médecin vérifié.</div>
    <?php elseif ($status === 'refuse'): ?>
        <div class="banner refuse"><strong>Dossier refusé.</strong>
            Motif : <?= e(orDash($account['motif_refus'])) ?><br>
            Corrigez vos informations ou téléversez un nouveau justificatif dans <a href="modifier_profil.php"><strong>Modifier mon profil</strong></a> : votre dossier sera réexaminé.</div>
    <?php else: ?>
        <div class="banner verifie"><strong>Médecin vérifié.</strong>
            Votre dossier a été validé le <?= e(fmtDate($account['verifie_le'], true)) ?>.</div>
    <?php endif; ?>

    <section class="profile-card">
        <div class="profile-head">
            <div class="avatar"><?= e(initials($account)) ?></div>
            <div>
                <h3>Dr <?= e(fullName($account)) ?>
                    <span class="status status-<?= e($status) ?>"><?= e(verificationLabel($status)) ?></span></h3>
                <p><?= e(orDash($account['specialite'])) ?></p>
            </div>
        </div>
        <dl class="info-list">
            <dt>E-mail</dt><dd><?= e($account['email']) ?></dd>
            <dt>Téléphone</dt><dd><?= e(orDash($account['telephone'])) ?></dd>
            <dt>Spécialité</dt><dd><?= e(orDash($account['specialite'])) ?></dd>
            <dt>N° d'ordre</dt><dd><?= e(orDash($account['numero_ordre'])) ?></dd>
            <dt>Ville du cabinet</dt><dd><?= e(orDash($account['ville'])) ?></dd>
            <dt>Date de naissance</dt><dd><?= e(fmtDate($account['date_naissance'])) ?></dd>
            <dt>Présentation</dt><dd><?= nl2br(e(orDash($account['bio']))) ?></dd>
            <dt>Justificatif</dt>
            <dd><?php if ($account['justificatif_fichier']): ?>
                <a href="justificatif.php?id=<?= (int) $account['id'] ?>" target="_blank" rel="noopener"><strong><?= e($account['justificatif_nom']) ?></strong></a>
            <?php else: ?>—<?php endif; ?></dd>
        </dl>
        <div class="inline-actions">
            <a href="modifier_profil.php">Modifier mon profil</a>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
