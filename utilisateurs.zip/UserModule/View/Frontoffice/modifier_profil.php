<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/validation.php';
require_once __DIR__ . '/../../includes/upload.php';
require_once __DIR__ . '/../../includes/forms.php';
require_once __DIR__ . '/../../Controller/UserController.php';

// Utilisateurs et médecins modifient LEUR profil. Les administrateurs passent par le back office.
requireRole(['utilisateur', 'medecin']);

$controller = new UserController();
$me = currentUser();
$id = (int) $me['id'];     // SEUL l'identifiant de la session est utilisé : aucun id n'est lu dans la requête
$role = $me['role'];
$isDoctor = $role === 'medecin';

$errors = [];
$pwdErrors = [];
$values = $me;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $errors['_global'] = 'La session a expiré (ou le fichier est trop volumineux). Rechargez la page et réessayez.';
    } elseif (($_POST['action'] ?? '') === 'profile') {
        // Le rôle vient de la base ($role), jamais du formulaire.
        [$user, $errors] = collectUserInput($role, 'none');
        $values = array_merge($me, $user->toFormArray());

        if (!isset($errors['email']) && $controller->emailTakenByOther($user->getEmail(), $id)) {
            $errors['email'] = 'Cet e-mail est déjà utilisé par un autre compte.';
        }
        $mime = null;
        if ($isDoctor) {
            if (!isset($errors['numero_ordre']) && $controller->ordreTakenByOther($user->getNumeroOrdre(), $id)) {
                $errors['numero_ordre'] = 'Ce numéro d\'ordre est déjà enregistré.';
            }
            [$fileError, $mime] = validateJustificatif(false);
            if ($fileError) {
                $errors['justificatif'] = $fileError;
            }
        }

        if (!$errors) {
            $stored = null;
            if ($isDoctor && $mime !== null) {
                $stored = storeJustificatif($mime);
                if ($stored === null) {
                    $errors['_global'] = 'Impossible d\'enregistrer le justificatif.';
                } else {
                    $user->setJustificatif($stored[0], $stored[1], $stored[2]);
                }
            }
            if (!$errors) {
                $result = $controller->updateOwnProfile($id, $user);
                if ($result === false) {
                    if ($stored) {
                        deleteJustificatif($stored[0]);
                    }
                    $errors['_global'] = 'La mise à jour a échoué.';
                } else {
                    if ($result['old_file']) {
                        deleteJustificatif($result['old_file']);
                    }
                    setFlash($result['reverify']
                        ? 'Profil mis à jour. Vos informations professionnelles ont changé : votre dossier repasse en attente de validation.'
                        : 'Profil mis à jour avec succès.');
                    redirect(homeFor($role));
                }
            }
        }
    } elseif (($_POST['action'] ?? '') === 'password') {
        [$current, $new, $pwdErrors] = collectPasswordChange();
        if (!isset($pwdErrors['current_password']) && !$controller->checkPassword($id, $current)) {
            $pwdErrors['current_password'] = 'Mot de passe actuel incorrect.';
        }
        if (!$pwdErrors) {
            $controller->updatePassword($id, $new);
            session_regenerate_id(true);
            setFlash('Mot de passe modifié avec succès.');
            redirect(homeFor($role));
        }
    }
}

$pageTitle = 'Modifier mon profil - ANATOMIA';
$currentPage = 'modifier';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>
<main class="community">
    <div class="section-heading">
        <h2>Modifier mon profil</h2>
        <p>Vous ne pouvez modifier que vos propres informations.</p>
    </div>

    <?php if (isset($errors['_global'])): ?><div class="notice notice-error"><?= e($errors['_global']) ?></div><?php endif; ?>
    <?php if (($errors && !isset($errors['_global'])) || $pwdErrors): ?><div class="notice notice-error">Veuillez corriger les champs signalés.</div><?php endif; ?>

    <section class="auth-card wide" style="margin-bottom:26px">
        <h3>Mes informations</h3>
        <form method="post" <?= $isDoctor ? 'enctype="multipart/form-data"' : '' ?> data-validate novalidate>
            <?= csrfField() ?>
            <input type="hidden" name="action" value="profile">
            <div class="form-grid">
                <?= formInput('prenom', 'Prénom', $values['prenom'] ?? '', $errors, ['required' => 1, 'rules' => 'required|name', 'maxlength' => 100]) ?>
                <?= formInput('nom', 'Nom', $values['nom'] ?? '', $errors, ['required' => 1, 'rules' => 'required|name', 'maxlength' => 100]) ?>
                <?= formInput('email', 'E-mail', $values['email'] ?? '', $errors, ['type' => 'email', 'required' => 1, 'rules' => 'required|email', 'maxlength' => 190]) ?>
                <?= formInput('telephone', $isDoctor ? 'Téléphone' : 'Téléphone (facultatif)', $values['telephone'] ?? '', $errors, ['type' => 'tel', 'required' => $isDoctor ? 1 : 0, 'rules' => ($isDoctor ? 'required|' : '') . 'phone', 'maxlength' => 20]) ?>
                <?= formInput('date_naissance', 'Date de naissance (facultatif)', $values['date_naissance'] ?? '', $errors, ['type' => 'date', 'rules' => 'pastdate']) ?>
                <?= formSelect('genre', 'Genre (facultatif)', $values['genre'] ?? '', $errors, genreOptions(), ['empty' => '— Non précisé —']) ?>

                <?php if ($isDoctor): ?>
                    <h4 class="form-section-title">Informations professionnelles</h4>
                    <div class="full banner en_attente" style="grid-column:1/-1;margin:0">
                        Modifier votre <strong>spécialité</strong>, votre <strong>numéro d'ordre</strong> ou votre <strong>justificatif</strong>
                        remet votre dossier en attente de validation par un administrateur.
                    </div>
                    <?= formSelect('specialite', 'Spécialité', $values['specialite'] ?? '', $errors, specialiteOptions(), ['required' => 1, 'rules' => 'required', 'empty' => '— Choisir —']) ?>
                    <?= formInput('numero_ordre', 'Numéro d\'ordre / d\'inscription', $values['numero_ordre'] ?? '', $errors, ['required' => 1, 'rules' => 'required|ordre', 'maxlength' => 20]) ?>
                    <?= formInput('ville', 'Ville du cabinet (facultatif)', $values['ville'] ?? '', $errors, ['maxlength' => 100, 'rules' => 'max:100']) ?>
                    <?= formInput('justificatif', 'Nouveau justificatif (facultatif)', '', $errors, ['type' => 'file', 'rules' => 'file:3', 'accept' => '.pdf,.jpg,.jpeg,.png', 'hint' => $me['justificatif_nom'] ? 'Actuel : ' . $me['justificatif_nom'] . ' — PDF, JPG ou PNG, 3 Mo max.' : 'PDF, JPG ou PNG — 3 Mo maximum.']) ?>
                    <?= formTextarea('bio', 'Présentation (facultatif)', $values['bio'] ?? '', $errors, ['full' => 1, 'maxlength' => 1000, 'rules' => 'max:1000', 'rows' => 4]) ?>
                <?php else: ?>
                    <?= formInput('taille', 'Taille en cm (facultatif)', $values['taille'] ?? '', $errors, ['type' => 'number', 'step' => '0.1', 'rules' => 'range:50:250']) ?>
                    <?= formInput('poids', 'Poids en kg (facultatif)', $values['poids'] ?? '', $errors, ['type' => 'number', 'step' => '0.1', 'rules' => 'range:20:300']) ?>
                <?php endif; ?>
            </div>
            <div class="form-actions">
                <button type="submit">Enregistrer</button>
                <a class="btn-ghost" href="<?= e(homeFor($role)) ?>">Annuler</a>
            </div>
        </form>
    </section>

    <section class="auth-card wide">
        <h3>Changer mon mot de passe</h3>
        <form method="post" data-validate novalidate>
            <?= csrfField() ?>
            <input type="hidden" name="action" value="password">
            <div class="form-grid">
                <?= formInput('current_password', 'Mot de passe actuel', '', $pwdErrors, ['type' => 'password', 'full' => 1, 'required' => 1, 'rules' => 'required', 'autocomplete' => 'current-password']) ?>
                <?= formInput('new_password', 'Nouveau mot de passe', '', $pwdErrors, ['type' => 'password', 'required' => 1, 'rules' => 'required|password', 'hint' => '8 caractères minimum, avec une lettre et un chiffre.', 'autocomplete' => 'new-password']) ?>
                <?= formInput('confirm_new_password', 'Confirmer le nouveau mot de passe', '', $pwdErrors, ['type' => 'password', 'required' => 1, 'rules' => 'required|match:new_password', 'autocomplete' => 'new-password']) ?>
            </div>
            <div class="form-actions"><button type="submit">Modifier le mot de passe</button></div>
        </form>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
