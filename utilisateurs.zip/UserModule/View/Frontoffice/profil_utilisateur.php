<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/forms.php';

requireRole(['utilisateur']);
$account = currentUser();

$pageTitle = 'Mon profil - ANATOMIA';
$currentPage = 'profil';
require __DIR__ . '/includes/head.php';
?>
<body>
<?php require __DIR__ . '/includes/navbar.php'; ?>
<main class="community">
    <?php require __DIR__ . '/includes/flash.php'; ?>
    <div class="section-heading">
        <h2>Mon profil</h2>
        <p>Vos informations personnelles.</p>
    </div>
    <section class="profile-card">
        <div class="profile-head">
            <div class="avatar"><?= e(initials($account)) ?></div>
            <div>
                <h3><?= e(fullName($account)) ?></h3>
                <p>Membre depuis le <?= e(fmtDate($account['created_at'])) ?></p>
            </div>
        </div>
        <dl class="info-list">
            <dt>E-mail</dt><dd><?= e($account['email']) ?></dd>
            <dt>Téléphone</dt><dd><?= e(orDash($account['telephone'])) ?></dd>
            <dt>Date de naissance</dt><dd><?= e(fmtDate($account['date_naissance'])) ?></dd>
            <dt>Genre</dt><dd><?= e(orDash(genreOptions()[$account['genre']] ?? '')) ?></dd>
            <dt>Taille</dt><dd><?= $account['taille'] !== null ? e($account['taille']) . ' cm' : '—' ?></dd>
            <dt>Poids</dt><dd><?= $account['poids'] !== null ? e($account['poids']) . ' kg' : '—' ?></dd>
        </dl>
        <div class="inline-actions">
            <a href="modifier_profil.php">Modifier mon profil</a>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
