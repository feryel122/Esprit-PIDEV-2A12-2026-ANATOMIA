<?php

/**
 * Modèle User : représente un compte (utilisateur, médecin ou administrateur).
 * Les données sont validées par includes/validation.php puis persistées par UserController.
 */
class User
{
    const ROLES = ['utilisateur', 'medecin', 'admin'];
    const GENRES = ['femme', 'homme', 'autre'];

    private $id;
    private $nom;
    private $prenom;
    private $email;
    private $password;          // mot de passe en clair, uniquement le temps du traitement (haché par le contrôleur)
    private $role;
    private $telephone;
    private $dateNaissance;
    private $genre;
    private $taille;
    private $poids;
    private $specialite;
    private $numeroOrdre;
    private $ville;
    private $bio;
    private $justificatifFichier;
    private $justificatifNom;
    private $justificatifMime;

    public function __construct($role = 'utilisateur')
    {
        $this->role = $role;
    }

    public function getId() { return $this->id; }
    public function getNom() { return $this->nom; }
    public function getPrenom() { return $this->prenom; }
    public function getEmail() { return $this->email; }
    public function getPassword() { return $this->password; }
    public function getRole() { return $this->role; }
    public function getTelephone() { return $this->telephone; }
    public function getDateNaissance() { return $this->dateNaissance; }
    public function getGenre() { return $this->genre; }
    public function getTaille() { return $this->taille; }
    public function getPoids() { return $this->poids; }
    public function getSpecialite() { return $this->specialite; }
    public function getNumeroOrdre() { return $this->numeroOrdre; }
    public function getVille() { return $this->ville; }
    public function getBio() { return $this->bio; }
    public function getJustificatifFichier() { return $this->justificatifFichier; }
    public function getJustificatifNom() { return $this->justificatifNom; }
    public function getJustificatifMime() { return $this->justificatifMime; }

    public function setId($v) { $this->id = $v; return $this; }
    public function setNom($v) { $this->nom = $v; return $this; }
    public function setPrenom($v) { $this->prenom = $v; return $this; }
    public function setEmail($v) { $this->email = $v; return $this; }
    public function setPassword($v) { $this->password = $v; return $this; }
    public function setRole($v) { $this->role = $v; return $this; }
    public function setTelephone($v) { $this->telephone = $v; return $this; }
    public function setDateNaissance($v) { $this->dateNaissance = $v; return $this; }
    public function setGenre($v) { $this->genre = $v; return $this; }
    public function setTaille($v) { $this->taille = $v; return $this; }
    public function setPoids($v) { $this->poids = $v; return $this; }
    public function setSpecialite($v) { $this->specialite = $v; return $this; }
    public function setNumeroOrdre($v) { $this->numeroOrdre = $v; return $this; }
    public function setVille($v) { $this->ville = $v; return $this; }
    public function setBio($v) { $this->bio = $v; return $this; }

    public function setJustificatif($fichier, $nom, $mime)
    {
        $this->justificatifFichier = $fichier;
        $this->justificatifNom = $nom;
        $this->justificatifMime = $mime;
        return $this;
    }

    public function isDoctor() { return $this->role === 'medecin'; }

    /** Données du formulaire pour ré-affichage en cas d'erreur (jamais le mot de passe). */
    public function toFormArray()
    {
        return [
            'nom' => $this->nom, 'prenom' => $this->prenom, 'email' => $this->email,
            'telephone' => $this->telephone, 'date_naissance' => $this->dateNaissance,
            'genre' => $this->genre, 'taille' => $this->taille, 'poids' => $this->poids,
            'specialite' => $this->specialite, 'numero_ordre' => $this->numeroOrdre,
            'ville' => $this->ville, 'bio' => $this->bio, 'role' => $this->role,
        ];
    }
}
