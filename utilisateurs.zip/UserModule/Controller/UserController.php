<?php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../Model/User.php';

/**
 * Accès aux données des comptes : toutes les requêtes utilisent des requêtes préparées (PDO).
 * Les droits (qui a le droit de faire quoi) sont contrôlés par les pages via requireRole()
 * et en limitant chaque opération à l'identifiant de session quand il s'agit d'un profil personnel.
 */
class UserController
{
    // Colonnes renvoyées au reste de l'application : jamais le hash du mot de passe.
    const COLUMNS = 'id, nom, prenom, email, role, telephone, date_naissance, genre, taille, poids,
        specialite, numero_ordre, ville, bio, statut_compte, statut_verification, motif_refus,
        verifie_par, verifie_le, justificatif_fichier, justificatif_nom, justificatif_mime, created_at';

    const MAX_ATTEMPTS = 5;
    const LOCK_MINUTES = 15;
    // Hash factice : même coût de calcul quand l'e-mail n'existe pas (évite de révéler les comptes existants).
    const DUMMY_HASH = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

    private $db;

    public function __construct()
    {
        $this->db = config::getConnexion();
    }

    /* ======================= CREATE ======================= */

    /**
     * Crée un compte. Le rôle vient du modèle (jamais d'un champ libre côté public).
     * Un médecin est créé "en_attente" sauf si $verifyNow (réservé à l'admin).
     * Retourne l'id créé ou false.
     */
    public function create(User $u, $verifyNow = false, $adminId = null)
    {
        $role = $u->getRole();
        if (!in_array($role, User::ROLES, true)) {
            return false;
        }
        $isDoctor = $role === 'medecin';
        $status = $isDoctor ? ($verifyNow ? 'verifie' : 'en_attente') : null;

        $sql = "INSERT INTO users
                (nom, prenom, email, password, role, telephone, date_naissance, genre, taille, poids,
                 specialite, numero_ordre, ville, bio, statut_verification, verifie_par, verifie_le,
                 justificatif_fichier, justificatif_nom, justificatif_mime)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            $this->db->prepare($sql)->execute([
                $u->getNom(), $u->getPrenom(), $u->getEmail(),
                password_hash($u->getPassword(), PASSWORD_DEFAULT),
                $role, $u->getTelephone(), $u->getDateNaissance(), $u->getGenre(),
                $role === 'utilisateur' ? $u->getTaille() : null,
                $role === 'utilisateur' ? $u->getPoids() : null,
                $isDoctor ? $u->getSpecialite() : null,
                $isDoctor ? $u->getNumeroOrdre() : null,
                $isDoctor ? $u->getVille() : null,
                $isDoctor ? $u->getBio() : null,
                $status,
                ($isDoctor && $verifyNow) ? $adminId : null,
                ($isDoctor && $verifyNow) ? date('Y-m-d H:i:s') : null,
                $isDoctor ? $u->getJustificatifFichier() : null,
                $isDoctor ? $u->getJustificatifNom() : null,
                $isDoctor ? $u->getJustificatifMime() : null,
            ]);
            return (int) $this->db->lastInsertId();
        } catch (PDOException $ex) {
            return false; // doublon e-mail / numéro d'ordre détecté par les index UNIQUE
        }
    }

    /* ======================= READ ======================= */

    public function getUserById($id)
    {
        $q = $this->db->prepare('SELECT ' . self::COLUMNS . ' FROM users WHERE id = ?');
        $q->execute([(int) $id]);
        $row = $q->fetch();
        return $row ?: null;
    }

    public function findByEmail($email)
    {
        $q = $this->db->prepare('SELECT * FROM users WHERE email = ?');
        $q->execute([$email]);
        $row = $q->fetch();
        return $row ?: null;
    }

    public function emailTakenByOther($email, $id = 0)
    {
        $q = $this->db->prepare('SELECT id FROM users WHERE email = ? AND id <> ?');
        $q->execute([$email, (int) $id]);
        return (bool) $q->fetch();
    }

    public function ordreTakenByOther($numero, $id = 0)
    {
        $q = $this->db->prepare('SELECT id FROM users WHERE numero_ordre = ? AND id <> ?');
        $q->execute([$numero, (int) $id]);
        return (bool) $q->fetch();
    }

    /**
     * Liste paginée avec recherche et filtres.
     * $scope : 'users' (utilisateurs + admins) ou 'doctors' (médecins).
     */
    public function search($scope, $term, array $filters, $page, $perPage = 10)
    {
        $where = [$scope === 'doctors' ? "role = 'medecin'" : "role IN ('utilisateur', 'admin')"];
        $params = [];

        if ($term !== '') {
            $like = '%' . addcslashes($term, '%_\\') . '%';
            $where[] = '(nom LIKE ? OR prenom LIKE ? OR email LIKE ? OR specialite LIKE ? OR numero_ordre LIKE ?)';
            array_push($params, $like, $like, $like, $like, $like);
        }
        if (in_array($filters['statut'] ?? '', ['actif', 'desactive'], true)) {
            $where[] = 'statut_compte = ?';
            $params[] = $filters['statut'];
        }
        if ($scope === 'users' && in_array($filters['role'] ?? '', ['utilisateur', 'admin'], true)) {
            $where[] = 'role = ?';
            $params[] = $filters['role'];
        }
        if ($scope === 'doctors' && in_array($filters['verification'] ?? '', ['en_attente', 'verifie', 'refuse'], true)) {
            $where[] = 'statut_verification = ?';
            $params[] = $filters['verification'];
        }
        $whereSql = ' WHERE ' . implode(' AND ', $where);

        $count = $this->db->prepare('SELECT COUNT(*) FROM users' . $whereSql);
        $count->execute($params);
        $total = (int) $count->fetchColumn();

        $perPage = max(1, (int) $perPage);
        $pages = max(1, (int) ceil($total / $perPage));
        $page = min(max(1, (int) $page), $pages);
        $offset = ($page - 1) * $perPage;

        $q = $this->db->prepare('SELECT ' . self::COLUMNS . ' FROM users' . $whereSql
            . ' ORDER BY id DESC LIMIT ' . $perPage . ' OFFSET ' . $offset);
        $q->execute($params);

        return ['rows' => $q->fetchAll(), 'total' => $total, 'pages' => $pages, 'page' => $page];
    }

    public function getDoctorsByVerification($status, $limit = 50)
    {
        $q = $this->db->prepare('SELECT ' . self::COLUMNS . " FROM users
            WHERE role = 'medecin' AND statut_verification = ? ORDER BY created_at ASC LIMIT " . (int) $limit);
        $q->execute([$status]);
        return $q->fetchAll();
    }

    public function latest($limit = 5)
    {
        return $this->db->query('SELECT ' . self::COLUMNS . ' FROM users ORDER BY id DESC LIMIT ' . (int) $limit)->fetchAll();
    }

    public function stats()
    {
        $row = $this->db->query("SELECT
                SUM(role = 'utilisateur') AS users,
                SUM(role = 'admin') AS admins,
                SUM(role = 'medecin') AS doctors,
                SUM(role = 'medecin' AND statut_verification = 'en_attente') AS pending,
                SUM(role = 'medecin' AND statut_verification = 'verifie') AS verified,
                SUM(role = 'medecin' AND statut_verification = 'refuse') AS refused,
                SUM(statut_compte = 'desactive') AS inactive
            FROM users")->fetch();
        $stats = [];
        foreach (['users', 'admins', 'doctors', 'pending', 'verified', 'refused', 'inactive'] as $k) {
            $stats[$k] = (int) ($row[$k] ?? 0);
        }
        return $stats;
    }

    public function countPendingDoctors()
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM users
            WHERE role = 'medecin' AND statut_verification = 'en_attente'")->fetchColumn();
    }

    /* ======================= AUTHENTIFICATION ======================= */

    /** Retourne ['user' => array|null, 'error' => string|null]. */
    public function authenticate($email, $password)
    {
        $generic = 'E-mail ou mot de passe incorrect.';
        $row = $this->findByEmail($email);

        if (!$row) {
            password_verify($password, self::DUMMY_HASH);
            return ['user' => null, 'error' => $generic];
        }

        if ($row['verrouille_jusqua'] !== null && strtotime($row['verrouille_jusqua']) > time()) {
            $minutes = max(1, (int) ceil((strtotime($row['verrouille_jusqua']) - time()) / 60));
            return ['user' => null, 'error' => 'Trop de tentatives échouées. Réessayez dans ' . $minutes . ' minute(s).'];
        }

        if (!password_verify($password, $row['password'])) {
            $attempts = (int) $row['tentatives_echec'] + 1;
            if ($attempts >= self::MAX_ATTEMPTS) {
                $lockUntil = date('Y-m-d H:i:s', time() + self::LOCK_MINUTES * 60);
                $this->db->prepare('UPDATE users SET tentatives_echec = 0, verrouille_jusqua = ? WHERE id = ?')
                    ->execute([$lockUntil, $row['id']]);
            } else {
                $this->db->prepare('UPDATE users SET tentatives_echec = ? WHERE id = ?')
                    ->execute([$attempts, $row['id']]);
            }
            return ['user' => null, 'error' => $generic];
        }

        if ($row['statut_compte'] !== 'actif') {
            return ['user' => null, 'error' => 'Votre compte a été désactivé. Contactez l\'administration.'];
        }

        $this->db->prepare('UPDATE users SET tentatives_echec = 0, verrouille_jusqua = NULL WHERE id = ?')
            ->execute([$row['id']]);
        if (password_needs_rehash($row['password'], PASSWORD_DEFAULT)) {
            $this->updatePassword($row['id'], $password);
        }
        return ['user' => $this->getUserById($row['id']), 'error' => null];
    }

    public function checkPassword($id, $plain)
    {
        $q = $this->db->prepare('SELECT password FROM users WHERE id = ?');
        $q->execute([(int) $id]);
        $hash = $q->fetchColumn();
        return $hash !== false && password_verify($plain, $hash);
    }

    public function updatePassword($id, $plain)
    {
        return $this->db->prepare('UPDATE users SET password = ? WHERE id = ?')
            ->execute([password_hash($plain, PASSWORD_DEFAULT), (int) $id]);
    }

    /* ======================= UPDATE ======================= */

    /**
     * Modification de SON PROPRE profil : l'id est celui de la session, le rôle et l'état de
     * vérification ne sont jamais modifiables ici. Pour un médecin, changer la spécialité,
     * le numéro d'ordre ou le justificatif remet le dossier "en_attente" (nouvelle vérification).
     * Retourne ['reverify' => bool, 'old_file' => ?string] ou false.
     */
    public function updateOwnProfile($id, User $u)
    {
        $cur = $this->getUserById($id);
        if (!$cur) {
            return false;
        }

        $set = 'nom = ?, prenom = ?, email = ?, telephone = ?';
        $params = [$u->getNom(), $u->getPrenom(), $u->getEmail(), $u->getTelephone()];
        $reverify = false;
        $oldFile = null;

        if ($cur['role'] === 'utilisateur') {
            $set .= ', date_naissance = ?, genre = ?, taille = ?, poids = ?';
            array_push($params, $u->getDateNaissance(), $u->getGenre(), $u->getTaille(), $u->getPoids());
        } elseif ($cur['role'] === 'medecin') {
            $set .= ', date_naissance = ?, genre = ?, specialite = ?, numero_ordre = ?, ville = ?, bio = ?';
            array_push($params, $u->getDateNaissance(), $u->getGenre(), $u->getSpecialite(),
                $u->getNumeroOrdre(), $u->getVille(), $u->getBio());

            $newFile = $u->getJustificatifFichier() !== null;
            $reverify = $newFile
                || $u->getSpecialite() !== $cur['specialite']
                || $u->getNumeroOrdre() !== $cur['numero_ordre'];
            if ($newFile) {
                $set .= ', justificatif_fichier = ?, justificatif_nom = ?, justificatif_mime = ?';
                array_push($params, $u->getJustificatifFichier(), $u->getJustificatifNom(), $u->getJustificatifMime());
                $oldFile = $cur['justificatif_fichier'];
            }
            if ($reverify) {
                $set .= ", statut_verification = 'en_attente', motif_refus = NULL, verifie_par = NULL, verifie_le = NULL";
            }
        }

        $params[] = (int) $id;
        try {
            $this->db->prepare('UPDATE users SET ' . $set . ' WHERE id = ?')->execute($params);
        } catch (PDOException $ex) {
            return false;
        }
        return ['reverify' => $reverify, 'old_file' => $oldFile];
    }

    /** Modification par l'administrateur (back office). Le rôle d'un médecin ne change jamais. */
    public function adminUpdate($id, User $u, $changePassword)
    {
        $cur = $this->getUserById($id);
        if (!$cur) {
            return false;
        }
        $role = $cur['role'];
        if ($role !== 'medecin' && in_array($u->getRole(), ['utilisateur', 'admin'], true)) {
            $role = $u->getRole();
        }

        $set = 'nom = ?, prenom = ?, email = ?, telephone = ?, role = ?';
        $params = [$u->getNom(), $u->getPrenom(), $u->getEmail(), $u->getTelephone(), $role];

        if ($role === 'utilisateur') {
            $set .= ', date_naissance = ?, genre = ?, taille = ?, poids = ?';
            array_push($params, $u->getDateNaissance(), $u->getGenre(), $u->getTaille(), $u->getPoids());
        } elseif ($role === 'medecin') {
            $set .= ', date_naissance = ?, genre = ?, specialite = ?, numero_ordre = ?, ville = ?, bio = ?';
            array_push($params, $u->getDateNaissance(), $u->getGenre(), $u->getSpecialite(),
                $u->getNumeroOrdre(), $u->getVille(), $u->getBio());
        }
        if ($changePassword) {
            $set .= ', password = ?';
            $params[] = password_hash($u->getPassword(), PASSWORD_DEFAULT);
        }
        $params[] = (int) $id;

        try {
            $this->db->prepare('UPDATE users SET ' . $set . ' WHERE id = ?')->execute($params);
            return true;
        } catch (PDOException $ex) {
            return false;
        }
    }

    /** Activer / désactiver un compte (désactivé = connexion et sessions refusées). */
    public function setAccountStatus($id, $status)
    {
        if (!in_array($status, ['actif', 'desactive'], true)) {
            return false;
        }
        return $this->db->prepare('UPDATE users SET statut_compte = ? WHERE id = ?')->execute([$status, (int) $id]);
    }

    /* ======================= VÉRIFICATION DES MÉDECINS (admin) ======================= */

    public function verifyDoctor($id, $adminId)
    {
        $q = $this->db->prepare("UPDATE users
            SET statut_verification = 'verifie', motif_refus = NULL, verifie_par = ?, verifie_le = ?
            WHERE id = ? AND role = 'medecin'");
        $q->execute([(int) $adminId, date('Y-m-d H:i:s'), (int) $id]);
        return $q->rowCount() > 0;
    }

    public function refuseDoctor($id, $adminId, $reason)
    {
        $q = $this->db->prepare("UPDATE users
            SET statut_verification = 'refuse', motif_refus = ?, verifie_par = ?, verifie_le = ?
            WHERE id = ? AND role = 'medecin'");
        $q->execute([$reason, (int) $adminId, date('Y-m-d H:i:s'), (int) $id]);
        return $q->rowCount() > 0;
    }

    /* ======================= DELETE ======================= */

    public function deleteUser($id)
    {
        $q = $this->db->prepare('DELETE FROM users WHERE id = ?');
        $q->execute([(int) $id]);
        return $q->rowCount() > 0;
    }
}
