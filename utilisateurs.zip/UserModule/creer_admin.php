<?php
/**
 * Création du premier administrateur — EN LIGNE DE COMMANDE UNIQUEMENT :
 *   php creer_admin.php email@exemple.com "MotDePasse123" Prenom Nom
 * (refusé si appelé depuis le navigateur)
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/Controller/UserController.php';

[$script, $email, $password, $prenom, $nom] = array_pad($argv, 5, '');
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8 || $prenom === '' || $nom === '') {
    fwrite(STDERR, "Usage : php creer_admin.php email mot_de_passe(8+) prenom nom\n");
    exit(1);
}

$controller = new UserController();
if ($controller->findByEmail(mb_strtolower($email))) {
    fwrite(STDERR, "Cet e-mail existe déjà.\n");
    exit(1);
}
$admin = (new User('admin'))->setNom($nom)->setPrenom($prenom)->setEmail(mb_strtolower($email))->setPassword($password);
echo $controller->create($admin) ? "Administrateur créé.\n" : "Échec de la création.\n";
