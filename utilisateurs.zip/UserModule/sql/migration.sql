-- À importer UNE SEULE FOIS si la table `users` existe déjà (ancienne version du projet).
-- Nécessite MariaDB (XAMPP) : ADD COLUMN IF NOT EXISTS n'existe pas sous MySQL.
USE anatomia_forum;

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS telephone            VARCHAR(20)  NULL AFTER role,
    ADD COLUMN IF NOT EXISTS numero_ordre         VARCHAR(30)  NULL,
    ADD COLUMN IF NOT EXISTS ville                VARCHAR(100) NULL,
    ADD COLUMN IF NOT EXISTS bio                  TEXT         NULL,
    ADD COLUMN IF NOT EXISTS statut_compte        ENUM('actif','desactive') NOT NULL DEFAULT 'actif',
    ADD COLUMN IF NOT EXISTS statut_verification  ENUM('en_attente','verifie','refuse') NULL,
    ADD COLUMN IF NOT EXISTS motif_refus          VARCHAR(500) NULL,
    ADD COLUMN IF NOT EXISTS verifie_par          INT UNSIGNED NULL,
    ADD COLUMN IF NOT EXISTS verifie_le           DATETIME     NULL,
    ADD COLUMN IF NOT EXISTS justificatif_fichier VARCHAR(80)  NULL,
    ADD COLUMN IF NOT EXISTS justificatif_nom     VARCHAR(255) NULL,
    ADD COLUMN IF NOT EXISTS justificatif_mime    VARCHAR(100) NULL,
    ADD COLUMN IF NOT EXISTS tentatives_echec     TINYINT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS verrouille_jusqua    DATETIME     NULL,
    ADD COLUMN IF NOT EXISTS updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE users ADD UNIQUE KEY uq_users_numero_ordre (numero_ordre);

-- Les médecins déjà inscrits ne sont PAS considérés comme vérifiés tant que l'admin ne les valide pas.
UPDATE users SET statut_verification = 'en_attente'
 WHERE role = 'medecin' AND statut_verification IS NULL;
