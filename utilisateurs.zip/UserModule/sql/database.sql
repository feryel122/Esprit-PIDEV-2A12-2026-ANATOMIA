-- ANATOMIA — Module Utilisateurs (Front Office + Back Office AdminLTE)
-- Import complet pour une nouvelle base (phpMyAdmin > Importer).
-- Compatible MariaDB (XAMPP) et MySQL 8.

CREATE DATABASE IF NOT EXISTS anatomia_forum
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE anatomia_forum;

CREATE TABLE IF NOT EXISTS users (
    id                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nom                  VARCHAR(100)  NOT NULL,
    prenom               VARCHAR(100)  NOT NULL,
    email                VARCHAR(190)  NOT NULL,
    password             VARCHAR(255)  NOT NULL,
    role                 ENUM('utilisateur','medecin','admin') NOT NULL DEFAULT 'utilisateur',
    telephone            VARCHAR(20)   NULL,
    date_naissance       DATE          NULL,
    genre                ENUM('femme','homme','autre') NULL,
    taille               DECIMAL(5,1)  NULL,
    poids                DECIMAL(5,1)  NULL,
    -- Champs propres aux médecins
    specialite           VARCHAR(150)  NULL,
    numero_ordre         VARCHAR(30)   NULL,
    ville                VARCHAR(100)  NULL,
    bio                  TEXT          NULL,
    -- État du compte (désactivation par l'administrateur)
    statut_compte        ENUM('actif','desactive') NOT NULL DEFAULT 'actif',
    -- Vérification du médecin (NULL pour les non-médecins)
    statut_verification  ENUM('en_attente','verifie','refuse') NULL,
    motif_refus          VARCHAR(500)  NULL,
    verifie_par          INT UNSIGNED  NULL,
    verifie_le           DATETIME      NULL,
    -- Justificatif (stocké hors d'accès public, nom aléatoire)
    justificatif_fichier VARCHAR(80)   NULL,
    justificatif_nom     VARCHAR(255)  NULL,
    justificatif_mime    VARCHAR(100)  NULL,
    -- Protection contre le brute force
    tentatives_echec     TINYINT UNSIGNED NOT NULL DEFAULT 0,
    verrouille_jusqua    DATETIME      NULL,
    created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    UNIQUE KEY uq_users_numero_ordre (numero_ordre),
    KEY idx_users_role (role),
    KEY idx_users_verification (statut_verification)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
