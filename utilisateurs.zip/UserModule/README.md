# ANATOMIA — Module Utilisateurs (Front Office + Back Office AdminLTE)

Gestion des comptes : inscription utilisateur / médecin, connexion, profils, vérification des médecins
par l'administrateur, CRUD des utilisateurs et des médecins. PHP 8 (PDO / MySQL), architecture MVC simple,
template **AdminLTE** pour le back office.

## Installation (XAMPP)

1. Copier le dossier `UserModule` dans `C:\xampp\htdocs\` (le nom du dossier du dépôt peut être différent).
2. Démarrer **Apache** et **MySQL** dans XAMPP. Activer l'extension PHP `fileinfo` si ce n'est pas déjà le cas (active par défaut).
3. phpMyAdmin → importer `sql/database.sql` (nouvelle base `anatomia_forum`).
   *Base existante :* importer `sql/migration.sql` **une seule fois** à la place (MariaDB).
4. Vérifier `config.php` (localhost, `anatomia_forum`, `root`, mot de passe vide).
5. Créer le premier administrateur (le formulaire public ne peut pas créer d'admin) :
   `C:\xampp\php\php.exe creer_admin.php admin@anatomia.tn "Admin1234" Admin Anatomia`
6. Ouvrir `http://localhost/<dossier>/UserModule/View/Frontoffice/accueil.php`
   Back office : `http://localhost/<dossier>/UserModule/View/Backoffice/adminlte/dashboard.php`

## Pages

| Front Office (`View/Frontoffice`) | Rôle autorisé |
|---|---|
| `inscription_utilisateur.php`, `inscription_medecin.php`, `login.php` | public (visiteurs) |
| `profil_utilisateur.php` | utilisateur |
| `profil_medecin.php` | médecin (en attente, vérifié ou refusé) |
| `espace_medecin.php` | médecin **vérifié** uniquement |
| `modifier_profil.php` (+ changement de mot de passe) | utilisateur ou médecin — son propre profil |
| `justificatif.php` | admin, ou médecin propriétaire du fichier |
| `acces_refuse.php` (403) | — |

| Back Office (`View/Backoffice/adminlte`) — **admin uniquement** | |
|---|---|
| `dashboard.php` | statistiques, dossiers à vérifier, dernières inscriptions |
| `afficherusers.php`, `afficheruser.php`, `ajoutuser.php`, `modifieruser.php`, `supprimeruser.php` | CRUD utilisateurs (recherche, filtres, pagination) |
| `afficherdoctors.php`, `afficherdoctor.php`, `ajoutdoctor.php`, `modifierdoctor.php`, `supprimerdoctor.php` | CRUD médecins |
| `verifier_medecins.php` + `valider_medecin.php` | file de vérification : valider / refuser (motif obligatoire) |
| `changer_statut.php` | désactiver / réactiver un compte |

## Règles métier et sécurité

- **Rôles** : `utilisateur`, `medecin`, `admin`. Le rôle n'est jamais lu depuis un formulaire public.
- **Profil personnel** : `modifier_profil.php` n'utilise que l'identifiant de la session (aucun `id` dans l'URL ni le formulaire).
- **Pages protégées** : `requireRole()` (403 si mauvais rôle, redirection login si non connecté). Un utilisateur
  ne voit pas les pages médecin ; un médecin ne voit pas le back office.
- **Médecin en attente ≠ vérifié** : `statut_verification` = `en_attente` à l'inscription ; seul l'admin peut passer à
  `verifie` ou `refuse`. Modifier spécialité, n° d'ordre ou justificatif remet le dossier en attente.
- **Mots de passe** : `password_hash` / `password_verify`, 8 caractères min. avec lettre + chiffre.
- **Sessions** : cookie HttpOnly + SameSite, `session_regenerate_id` à la connexion, expiration après 30 min d'inactivité,
  compte relu en base à chaque requête (désactivation / changement de rôle immédiats).
- **Brute force** : 5 échecs → compte verrouillé 15 min ; message de connexion générique.
- **Requêtes préparées** PDO partout ; sortie échappée avec `e()` (XSS) ; jeton **CSRF** sur tous les formulaires POST ;
  déconnexion en POST ; en-têtes de sécurité (CSP, X-Frame-Options, nosniff).
- **Upload du justificatif** : PDF/JPG/PNG, 3 Mo max, type détecté sur le contenu (`finfo`), nom aléatoire,
  dossier `uploads/justificatifs` interdit d'accès direct (`.htaccess`), lecture via `justificatif.php` avec contrôle d'identité.
- **Validation** : serveur (`includes/validation.php`, fait foi) **et** client (`View/Assets/js/validation.js`, attributs `data-rules`).
- **Désactivation** : un compte désactivé ne peut plus se connecter ; sa session en cours est invalidée.
  L'admin ne peut ni se désactiver, ni se supprimer, ni changer son propre rôle.

## Structure

```
config.php            connexion PDO
includes/             bootstrap (session, CSRF, accès), validation, upload, générateurs de champs
Model/User.php        modèle
Controller/UserController.php   accès aux données (requêtes préparées)
View/Frontoffice/     pages publiques et espaces utilisateur / médecin
View/Backoffice/      AdminLTE (adminlte/ = pages, Views/ = layout, partials, vues)
View/Assets/          CSS + JS (validation.js, app.js)
sql/                  database.sql, migration.sql
uploads/justificatifs/  fichiers déposés (protégé)
creer_admin.php       création du 1er admin (CLI)
```
