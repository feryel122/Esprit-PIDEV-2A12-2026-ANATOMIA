<?php
/**
 * Point d'entrée principal du Back-Office
 * Projet Technologies Web 2026-2027 (Architecture MVC)
 */

if (session_status() === PHP_SESSION_NONE) {
    $tempDir = sys_get_temp_dir();
    if (is_writable($tempDir)) {
        @session_save_path($tempDir);
    }
    @session_start();
}

// Chargement de la configuration
require_once __DIR__ . '/app/config.php';

// Chargement des contrôleurs
require_once __DIR__ . '/app/Controllers/Controller.php';
require_once __DIR__ . '/app/Controllers/DashboardController.php';
require_once __DIR__ . '/app/Controllers/RecetteController.php';

// Routage des requêtes
require_once __DIR__ . '/app/routes.php';
