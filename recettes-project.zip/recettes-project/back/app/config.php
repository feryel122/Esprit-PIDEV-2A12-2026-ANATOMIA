<?php
/**
 * Configuration de l'application Recettes
 * Projet Technologies Web 2026-2027 (Architecture MVC)
 */

define('APP_NAME', 'Recettes Délices');
define('APP_VERSION', '1.0.0');

// Configuration Base de Données (Optionnel pour MySQL / phpMyAdmin)
define('DB_HOST', 'localhost');
define('DB_NAME', 'recettes_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Chemin du fichier de stockage par défaut (JSON pour fonctionnement immédiat sans MySQL)
define('DATA_FILE', __DIR__ . '/data/recettes.json');
