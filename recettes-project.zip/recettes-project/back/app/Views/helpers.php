<?php
/**
 * Fonctions d'aide pour les vues et les menus actifs
 * Workshop Template Integration - ESPRIT
 */

function isActive(string $page, string $currentPage): string {
    return $page === $currentPage ? 'active' : '';
}

function isOpen(array $pages, string $currentPage): bool {
    return in_array($currentPage, $pages, true);
}

function isCollapsed(array $pages, string $currentPage): string {
    return in_array($currentPage, $pages, true) ? '' : 'collapsed';
}

function groupIsExpanded(array $pages, string $currentPage): string {
    return in_array($currentPage, $pages, true) ? 'true' : 'false';
}
