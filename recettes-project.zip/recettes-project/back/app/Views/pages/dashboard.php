<!-- Page Header / Breadcrumb -->
<div class="title-head mb-4">
    <div>
        <h3 class="fw-bold">Tableau de bord</h3>
        <p class="text-muted mb-0">Bienvenue dans l'espace d'administration du module Recettes (Architecture MVC)</p>
    </div>
    <div class="d-flex gap-2">
        <a href="index.php?page=recette-add" class="main-btn primary-btn btn-hover text-decoration-none">
            <i class="lni lni-plus me-1"></i> Nouvelle Recette
        </a>
        <a href="../front/recettes.php" target="_blank" class="btn btn-outline-primary rounded-3">
            <i class="lni lni-website me-1"></i> Front-Office
        </a>
    </div>
</div>

<!-- Stats Row -->
<div class="row">
    <div class="col-xl-3 col-lg-4 col-sm-6">
        <div class="icon-card purple">
            <div class="icon">
                <i class="lni lni-dinner"></i>
            </div>
            <div class="content">
                <h6>Total Recettes</h6>
                <h3><?= $stats['total'] ?? 0 ?></h3>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-sm-6">
        <div class="icon-card success">
            <div class="icon">
                <i class="lni lni-checkmark-circle"></i>
            </div>
            <div class="content">
                <h6>Recettes Publiées</h6>
                <h3><?= $stats['published'] ?? 0 ?></h3>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-sm-6">
        <div class="icon-card warning">
            <div class="icon">
                <i class="lni lni-layers"></i>
            </div>
            <div class="content">
                <h6>Catégories</h6>
                <h3><?= $stats['categories_count'] ?? 0 ?></h3>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-4 col-sm-6">
        <div class="icon-card danger">
            <div class="icon">
                <i class="lni lni-pencil-alt"></i>
            </div>
            <div class="content">
                <h6>Brouillons</h6>
                <h3><?= $stats['drafts'] ?? 0 ?></h3>
            </div>
        </div>
    </div>
</div>

<!-- Recent Recipes Card -->
<div class="card-style">
    <div class="title-head">
        <h4 class="fw-bold">Dernières Recettes Enregistrées</h4>
        <a href="index.php?page=recettes" class="text-primary text-decoration-none fw-semibold">
            Voir toute la liste <i class="lni lni-arrow-right ms-1"></i>
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover table-style align-middle">
            <thead>
                <tr>
                    <th scope="col">Recette</th>
                    <th scope="col">Catégorie</th>
                    <th scope="col">Temps</th>
                    <th scope="col">Difficulté</th>
                    <th scope="col">Statut</th>
                    <th scope="col" class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentRecipes)): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">Aucune recette pour le moment.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentRecipes as $r): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="<?= htmlspecialchars($r['image']) ?>" alt="<?= htmlspecialchars($r['titre']) ?>" class="recipe-img-thumb me-3 border" onerror="this.src='https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=150&q=80'">
                                    <div>
                                        <h6 class="mb-0 fw-bold"><?= htmlspecialchars($r['titre']) ?></h6>
                                        <small class="text-muted"><i class="lni lni-user me-1"></i><?= htmlspecialchars($r['chef'] ?? 'Chef') ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border"><?= htmlspecialchars($r['categorie']) ?></span>
                            </td>
                            <td>
                                <small class="text-muted"><i class="lni lni-timer me-1"></i>Prep: <?= (int)$r['temps_prep'] ?>m | Cuis: <?= (int)$r['temps_cuisson'] ?>m</small>
                            </td>
                            <td>
                                <?php
                                $diffClass = match($r['difficulte']) {
                                    'Facile' => 'badge-facile',
                                    'Moyen' => 'badge-moyen',
                                    'Difficile' => 'badge-difficile',
                                    default => 'badge-facile'
                                };
                                ?>
                                <span class="badge-status <?= $diffClass ?>"><?= htmlspecialchars($r['difficulte']) ?></span>
                            </td>
                            <td>
                                <span class="badge-status <?= ($r['statut'] === 'Publié') ? 'badge-publie' : 'badge-brouillon' ?>">
                                    <?= htmlspecialchars($r['statut']) ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <a href="index.php?page=recette-edit&id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary me-1" title="Modifier">
                                    <i class="lni lni-pencil"></i>
                                </a>
                                <a href="../front/recette-detail.php?id=<?= $r['id'] ?>" target="_blank" class="btn btn-sm btn-outline-info" title="Voir sur le Front">
                                    <i class="lni lni-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
