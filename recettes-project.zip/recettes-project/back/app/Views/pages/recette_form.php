<?php
// Formattage des ingrédients et étapes si reçus sous forme de tableau
$ingredientsText = '';
if (!empty($recipe['ingredients'])) {
    if (is_array($recipe['ingredients'])) {
        $ingredientsText = implode("\n", $recipe['ingredients']);
    } else {
        $ingredientsText = $recipe['ingredients'];
    }
}

$etapesText = '';
if (!empty($recipe['etapes'])) {
    if (is_array($recipe['etapes'])) {
        $etapesText = implode("\n", $recipe['etapes']);
    } else {
        $etapesText = $recipe['etapes'];
    }
}

$actionUrl = $isEdit ? 'index.php?page=recette-update' : 'index.php?page=recette-store';
?>

<!-- Title & Breadcrumb -->
<div class="title-head mb-4">
    <div>
        <h3 class="fw-bold"><?= $isEdit ? 'Modifier la Recette #' . (int)($recipe['id'] ?? 0) : 'Ajouter une Nouvelle Recette' ?></h3>
        <p class="text-muted mb-0">
            <?= $isEdit ? 'Modifiez les informations de la recette ci-dessous.' : 'Remplissez le formulaire pour publier une nouvelle recette culinaire.' ?>
        </p>
    </div>
    <div>
        <a href="index.php?page=recettes" class="btn btn-outline-secondary">
            <i class="lni lni-arrow-left me-1"></i> Retour à la liste
        </a>
    </div>
</div>

<!-- Errors Display -->
<?php if (!empty($errors)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <h6 class="alert-heading fw-bold mb-2"><i class="lni lni-warning me-2"></i>Erreur(s) détectée(s) :</h6>
        <ul class="mb-0 ps-3">
            <?php foreach ($errors as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- Form Card -->
<div class="card-style">
    <form action="<?= $actionUrl ?>" method="POST" id="recipeForm">
        <?php if ($isEdit): ?>
            <input type="hidden" name="id" value="<?= (int)($recipe['id'] ?? 0) ?>">
        <?php endif; ?>

        <div class="row g-4">
            <!-- Informations Générales -->
            <div class="col-12">
                <h5 class="fw-bold text-primary border-bottom pb-2">
                    <i class="lni lni-information me-2"></i>1. Informations Générales
                </h5>
            </div>

            <!-- Titre -->
            <div class="col-md-8">
                <label for="titre" class="form-label">Titre de la recette <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="titre" name="titre" placeholder="Ex: Couscous Tunisien à l'Agneau" value="<?= htmlspecialchars($recipe['titre'] ?? '') ?>" required>
            </div>

            <!-- Catégorie -->
            <div class="col-md-4">
                <label for="categorie" class="form-label">Catégorie <span class="text-danger">*</span></label>
                <select class="form-select" id="categorie" name="categorie" required>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat) ?>" <?= (($recipe['categorie'] ?? '') === $cat) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Description -->
            <div class="col-12">
                <label for="description" class="form-label">Description courte</label>
                <textarea class="form-control" id="description" name="description" rows="2" placeholder="Présentation succincte de la recette..."><?= htmlspecialchars($recipe['description'] ?? '') ?></textarea>
            </div>

            <!-- Caractéristiques & Métriques -->
            <div class="col-12 mt-4">
                <h5 class="fw-bold text-primary border-bottom pb-2">
                    <i class="lni lni-timer me-2"></i>2. Caractéristiques & Préparation
                </h5>
            </div>

            <!-- Temps Prep -->
            <div class="col-md-3 col-sm-6">
                <label for="temps_prep" class="form-label">Temps de préparation (min)</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="lni lni-timer"></i></span>
                    <input type="number" class="form-control" id="temps_prep" name="temps_prep" min="1" value="<?= (int)($recipe['temps_prep'] ?? 15) ?>" required>
                </div>
            </div>

            <!-- Temps Cuisson -->
            <div class="col-md-3 col-sm-6">
                <label for="temps_cuisson" class="form-label">Temps de cuisson (min)</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="lni lni-fire-alt"></i></span>
                    <input type="number" class="form-control" id="temps_cuisson" name="temps_cuisson" min="0" value="<?= (int)($recipe['temps_cuisson'] ?? 30) ?>" required>
                </div>
            </div>

            <!-- Portions -->
            <div class="col-md-2 col-sm-6">
                <label for="portions" class="form-label">Portions (personnes)</label>
                <input type="number" class="form-control" id="portions" name="portions" min="1" max="50" value="<?= (int)($recipe['portions'] ?? 4) ?>" required>
            </div>

            <!-- Difficulté -->
            <div class="col-md-2 col-sm-6">
                <label for="difficulte" class="form-label">Difficulté</label>
                <select class="form-select" id="difficulte" name="difficulte">
                    <option value="Facile" <?= (($recipe['difficulte'] ?? '') === 'Facile') ? 'selected' : '' ?>>Facile</option>
                    <option value="Moyen" <?= (($recipe['difficulte'] ?? '') === 'Moyen') ? 'selected' : '' ?>>Moyen</option>
                    <option value="Difficile" <?= (($recipe['difficulte'] ?? '') === 'Difficile') ? 'selected' : '' ?>>Difficile</option>
                </select>
            </div>

            <!-- Calories -->
            <div class="col-md-2 col-sm-6">
                <label for="calories" class="form-label">Calories (kcal)</label>
                <input type="number" class="form-control" id="calories" name="calories" min="0" value="<?= (int)($recipe['calories'] ?? 350) ?>">
            </div>

            <!-- Médias & Auteur -->
            <div class="col-12 mt-4">
                <h5 class="fw-bold text-primary border-bottom pb-2">
                    <i class="lni lni-image me-2"></i>3. Médias & Publication
                </h5>
            </div>

            <!-- URL Image -->
            <div class="col-md-6">
                <label for="image" class="form-label">URL de l'image</label>
                <input type="url" class="form-control" id="image" name="image" placeholder="https://..." value="<?= htmlspecialchars($recipe['image'] ?? '') ?>" oninput="updateImagePreview(this.value)">
                <small class="text-muted">Lien direct vers l'image de la recette (Unsplash ou fichier local)</small>
            </div>

            <!-- Prévisualisation Image -->
            <div class="col-md-2 text-center">
                <label class="form-label d-block">Aperçu</label>
                <img id="imgPreview" src="<?= !empty($recipe['image']) ? htmlspecialchars($recipe['image']) : 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=200&q=80' ?>" alt="Aperçu" class="rounded border shadow-sm" style="width: 70px; height: 70px; object-fit: cover;">
            </div>

            <!-- Chef -->
            <div class="col-md-2 col-sm-6">
                <label for="chef" class="form-label">Nom du Chef</label>
                <input type="text" class="form-control" id="chef" name="chef" placeholder="Ex: Chef Mohamed" value="<?= htmlspecialchars($recipe['chef'] ?? 'Chef Équipe') ?>">
            </div>

            <!-- Statut -->
            <div class="col-md-2 col-sm-6">
                <label for="statut" class="form-label">Statut</label>
                <select class="form-select" id="statut" name="statut">
                    <option value="Publié" <?= (($recipe['statut'] ?? '') === 'Publié') ? 'selected' : '' ?>>Publié</option>
                    <option value="Brouillon" <?= (($recipe['statut'] ?? '') === 'Brouillon') ? 'selected' : '' ?>>Brouillon</option>
                </select>
            </div>

            <!-- Ingrédients & Étapes -->
            <div class="col-12 mt-4">
                <h5 class="fw-bold text-primary border-bottom pb-2">
                    <i class="lni lni-list me-2"></i>4. Ingrédients & Étapes de Préparation
                </h5>
            </div>

            <!-- Ingrédients -->
            <div class="col-md-6">
                <label for="ingredients" class="form-label">Ingrédients <span class="text-danger">*</span></label>
                <textarea class="form-control" id="ingredients" name="ingredients" rows="8" placeholder="Saisir un ingrédient par ligne :
Exemple :
500g de semoule
1 oignon haché
2 c.à.s d'huile d'olive" required><?= htmlspecialchars($ingredientsText) ?></textarea>
                <small class="text-muted">Un ingrédient par ligne (la touche Entrée pour séparer)</small>
            </div>

            <!-- Étapes -->
            <div class="col-md-6">
                <label for="etapes" class="form-label">Étapes de Préparation <span class="text-danger">*</span></label>
                <textarea class="form-control" id="etapes" name="etapes" rows="8" placeholder="Saisir une étape par ligne :
Exemple :
Faire chauffer l'huile d'olive dans une sauteuse.
Ajouter les oignons et faire dorer 5 minutes.
Ajouter la viande et les épices puis couvrir d'eau." required><?= htmlspecialchars($etapesText) ?></textarea>
                <small class="text-muted">Une étape par ligne (chaque ligne sera numérotée automatiquement)</small>
            </div>

            <!-- Boutons de soumission -->
            <div class="col-12 mt-4 pt-3 border-top d-flex gap-3">
                <button type="submit" class="main-btn primary-btn btn-hover px-4">
                    <i class="lni lni-checkmark me-2"></i> <?= $isEdit ? 'Mettre à jour la recette' : 'Enregistrer la recette' ?>
                </button>
                <a href="index.php?page=recettes" class="btn btn-outline-secondary px-4">
                    Annuler
                </a>
            </div>
        </div>
    </form>
</div>

<script>
function updateImagePreview(url) {
    const preview = document.getElementById('imgPreview');
    if (url && url.trim().length > 5) {
        preview.src = url;
    } else {
        preview.src = 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=200&q=80';
    }
}
</script>
