<!-- Notifications Flash -->
<?php if (!empty($message)): ?>
    <div class="alert alert-success alert-dismissible fade show d-flex align-items-center mb-4" role="alert">
        <i class="lni lni-checkmark-circle fs-4 me-2"></i>
        <div><?= htmlspecialchars($message) ?></div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center mb-4" role="alert">
        <i class="lni lni-cross-circle fs-4 me-2"></i>
        <div><?= htmlspecialchars($error) ?></div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- Title & Action Button -->
<div class="title-head mb-4">
    <div>
        <h3 class="fw-bold">Gestion des Recettes</h3>
        <p class="text-muted mb-0">Espace d'administration : Consultation, Ajout, Modification et Suppression</p>
    </div>
    <div class="d-flex gap-2">
        <a href="index.php?page=recette-add" class="main-btn primary-btn btn-hover text-decoration-none shadow-sm">
            <i class="lni lni-plus me-1"></i> Ajouter une Recette
        </a>
    </div>
</div>

<!-- Filters Bar Card -->
<div class="card-style mb-4 py-3">
    <form action="index.php" method="GET" class="row g-3 align-items-center">
        <input type="hidden" name="page" value="recettes">
        
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-text bg-white border-end-0 text-muted"><i class="lni lni-search-alt"></i></span>
                <input type="text" name="search" class="form-control border-start-0 ps-0" placeholder="Rechercher par mot-clé, ingrédient..." value="<?= htmlspecialchars($search ?? '') ?>">
            </div>
        </div>

        <div class="col-md-4">
            <select name="category" class="form-select" onchange="this.form.submit()">
                <option value="">Toutes les catégories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= htmlspecialchars($cat) ?>" <?= ($category === $cat) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-primary px-3 flex-grow-1">
                Filtrer
            </button>
            <?php if (!empty($search) || !empty($category)): ?>
                <a href="index.php?page=recettes" class="btn btn-outline-secondary" title="Réinitialiser">
                    <i class="lni lni-reload"></i>
                </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- Table Card -->
<div class="card-style">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-muted fw-semibold">
            Affichage de <strong><?= count($recipes) ?></strong> recette(s)
        </span>
    </div>

    <div class="table-responsive">
        <table class="table table-hover table-style align-middle">
            <thead>
                <tr>
                    <th scope="col" style="width: 60px;">#</th>
                    <th scope="col">Recette</th>
                    <th scope="col">Catégorie</th>
                    <th scope="col">Préparation / Cuisson</th>
                    <th scope="col">Portions</th>
                    <th scope="col">Difficulté</th>
                    <th scope="col">Statut</th>
                    <th scope="col" class="text-end" style="min-width: 140px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recipes)): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <i class="lni lni-dinner text-muted display-4 d-block mb-3"></i>
                            <h5 class="fw-bold text-muted">Aucune recette trouvée</h5>
                            <p class="text-muted small">Essayez de modifier vos critères de recherche ou ajoutez une nouvelle recette.</p>
                            <a href="index.php?page=recette-add" class="btn btn-primary btn-sm mt-2">
                                <i class="lni lni-plus me-1"></i> Ajouter une recette
                            </a>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recipes as $r): ?>
                        <tr>
                            <td class="fw-bold text-muted">#<?= $r['id'] ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="<?= htmlspecialchars($r['image']) ?>" alt="<?= htmlspecialchars($r['titre']) ?>" class="recipe-img-thumb me-3 border shadow-sm" onerror="this.src='https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=150&q=80'">
                                    <div>
                                        <h6 class="mb-0 fw-bold"><?= htmlspecialchars($r['titre']) ?></h6>
                                        <small class="text-muted text-truncate d-inline-block" style="max-width: 250px;">
                                            <?= htmlspecialchars(mb_substr($r['description'] ?? '', 0, 60)) ?>...
                                        </small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-light text-primary border fw-semibold">
                                    <?= htmlspecialchars($r['categorie']) ?>
                                </span>
                            </td>
                            <td>
                                <div class="small">
                                    <div><i class="lni lni-timer text-muted me-1"></i>Prep: <strong><?= (int)$r['temps_prep'] ?> min</strong></div>
                                    <div class="text-muted"><i class="lni lni-fire-alt text-muted me-1"></i>Cuis: <strong><?= (int)$r['temps_cuisson'] ?> min</strong></div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border">
                                    <i class="lni lni-users me-1"></i><?= (int)$r['portions'] ?> pers.
                                </span>
                            </td>
                            <td>
                                <?php
                                $diffClass = match($r['difficulte']) {
                                    'Facile' => 'badge-facile',
                                    'Moyen' => 'badge-moyen',
                                    'Difficile' => 'badge-difficile',
                                    default => 'badge-facile'
                                };
                                ?>
                                <span class="badge-status <?= $diffClass ?>"><?= htmlspecialchars($r['difficulte']) ?></span>
                            </td>
                            <td>
                                <span class="badge-status <?= ($r['statut'] === 'Publié') ? 'badge-publie' : 'badge-brouillon' ?>">
                                    <?= htmlspecialchars($r['statut']) ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="btn-group" role="group">
                                    <!-- Voir Détail sur Front Office -->
                                    <a href="../front/recette-detail.php?id=<?= $r['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="Voir sur le Front-Office">
                                        <i class="lni lni-eye"></i>
                                    </a>
                                    <!-- Modifier Recette -->
                                    <a href="index.php?page=recette-edit&id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary" title="Modifier la recette">
                                        <i class="lni lni-pencil"></i>
                                    </a>
                                    <!-- Supprimer Recette -->
                                    <button type="button" class="btn btn-sm btn-outline-danger" title="Supprimer la recette" onclick="confirmDelete(<?= $r['id'] ?>, '<?= htmlspecialchars(addslashes($r['titre'])) ?>')">
                                        <i class="lni lni-trash-can"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Confirmation Suppression -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteModalLabel"><i class="lni lni-warning me-2"></i>Confirmation de suppression</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4 text-center">
                <i class="lni lni-trash-can display-4 text-danger mb-3 d-block"></i>
                <p class="mb-1">Êtes-vous sûr de vouloir supprimer définitivement la recette suivante ?</p>
                <h5 class="fw-bold text-dark mt-2" id="deleteRecipeTitle"></h5>
                <p class="text-muted small mt-2">Cette action est irréversible.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
                <a href="#" id="confirmDeleteBtn" class="btn btn-danger">Confirmer la suppression</a>
            </div>
        </div>
    </div>
</div>

<script>
function confirmDelete(id, title) {
    document.getElementById('deleteRecipeTitle').innerText = title;
    document.getElementById('confirmDeleteBtn').href = 'index.php?page=recette-delete&id=' + id;
    var modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}
</script>
