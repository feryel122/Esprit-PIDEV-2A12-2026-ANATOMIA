/* ==========================================================================
   PlainAdmin Dashboard JS (ESPRIT MVC Integration)
   ========================================================================== */

document.addEventListener("DOMContentLoaded", function () {
    // 1. Preloader fade out
    const preloader = document.getElementById("preloader");
    if (preloader) {
        setTimeout(() => {
            preloader.classList.add("hidden");
        }, 200);
    }

    // 2. Sidebar Toggle for desktop & mobile
    const menuToggle = document.getElementById("menu-toggle");
    const sidebar = document.querySelector(".sidebar-nav-wrapper");
    const overlay = document.querySelector(".overlay");
    const mainWrapper = document.querySelector(".main-wrapper");

    if (menuToggle && sidebar) {
        menuToggle.addEventListener("click", function (e) {
            e.preventDefault();
            if (window.innerWidth < 992) {
                sidebar.classList.toggle("active");
                if (overlay) overlay.classList.toggle("active");
            } else {
                sidebar.classList.toggle("close");
                if (mainWrapper) mainWrapper.classList.toggle("full-width");
            }
        });
    }

    if (overlay && sidebar) {
        overlay.addEventListener("click", function () {
            sidebar.classList.remove("active");
            overlay.classList.remove("active");
        });
    }

    // 3. Auto-dismiss alerts after 4 seconds
    const alerts = document.querySelectorAll(".alert-dismissible");
    alerts.forEach((alert) => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 4000);
    });
});
