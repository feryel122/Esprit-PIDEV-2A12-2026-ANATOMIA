<!-- ======== footer start ======== -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-6 order-last order-md-first">
                <div class="copyright text-center text-md-start">
                    <p class="text-sm text-muted mb-0">
                        Projet Technologies Web 2026-2027 &copy; Module Recettes - ESPRIT (Architecture MVC)
                    </p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="terms d-flex justify-content-center justify-content-md-end gap-3">
                    <a href="../front/recettes.php" target="_blank" class="text-sm text-decoration-none">Front Office</a>
                    <a href="index.php?page=recettes" class="text-sm text-decoration-none">Back Office Recettes</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- ======== footer end ======== -->
