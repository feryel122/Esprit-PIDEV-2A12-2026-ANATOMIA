<?php
// $currentPage est fourni par le Controller (voir app/Controllers/Controller.php)
$currentPage = $currentPage ?? 'dashboard';
?>
<!-- ======== sidebar-nav start ======== -->
<aside class="sidebar-nav-wrapper">
    <div class="navbar-logo">
        <a href="index.php?page=dashboard" class="d-flex align-items-center gap-2 text-decoration-none">
            <span class="logo-icon"><i class="lni lni-chef-hat text-primary fs-3"></i></span>
            <span class="logo-text fw-bold fs-5 text-dark">Recettes<span class="text-primary">Admin</span></span>
        </a>
    </div>
    <nav class="sidebar-nav">
        <ul>
            <!-- Dashboard Link -->
            <li class="nav-item <?= isActive('dashboard', $currentPage) ?>">
                <a href="index.php?page=dashboard">
                    <span class="icon"><i class="lni lni-grid-alt"></i></span>
                    <span class="text">Tableau de bord</span>
                </a>
            </li>

            <!-- Section Divider -->
            <span class="divider"><hr /></span>

            <!-- Recettes Dropdown Menu -->
            <li class="nav-item nav-item-has-children <?= isOpen(['recettes', 'recette-add', 'recette-edit'], $currentPage) ? 'active' : '' ?>">
                <a href="#0" class="<?= isCollapsed(['recettes', 'recette-add', 'recette-edit'], $currentPage) ?>" data-bs-toggle="collapse" data-bs-target="#ddmenu_recettes" aria-controls="ddmenu_recettes" aria-expanded="<?= groupIsExpanded(['recettes', 'recette-add', 'recette-edit'], $currentPage) ?>" aria-label="Toggle navigation">
                    <span class="icon"><i class="lni lni-dinner"></i></span>
                    <span class="text">Gestion Recettes</span>
                </a>
                <ul id="ddmenu_recettes" class="collapse <?= isOpen(['recettes', 'recette-add', 'recette-edit'], $currentPage) ? 'show' : '' ?> dropdown-nav">
                    <li>
                        <a href="index.php?page=recettes" class="<?= isActive('recettes', $currentPage) ?>">
                            <i class="lni lni-list me-2"></i> Liste des recettes
                        </a>
                    </li>
                    <li>
                        <a href="index.php?page=recette-add" class="<?= isActive('recette-add', $currentPage) ?>">
                            <i class="lni lni-circle-plus me-2"></i> Ajouter une recette
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Section Divider -->
            <span class="divider"><hr /></span>

            <!-- Lien vers le Front-Office -->
            <li class="nav-item">
                <a href="../front/recettes.php" target="_blank" class="text-primary fw-medium">
                    <span class="icon"><i class="lni lni-website text-primary"></i></span>
                    <span class="text">Voir Front-Office <i class="lni lni-arrow-right fs-6 ms-1"></i></span>
                </a>
            </li>

            <!-- Modules de l'équipe (Projet PI) -->
            <li class="nav-item">
                <a href="#0" onclick="alert('Module en cours d\'intégration par vos coéquipiers (Projet PI)'); return false;" class="text-muted">
                    <span class="icon"><i class="lni lni-users"></i></span>
                    <span class="text">Modules Équipe</span>
                </a>
            </li>
        </ul>
    </nav>
</aside>
<!-- ======== sidebar-nav end ======== -->
