<!-- ======== header start ======== -->
<header class="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 col-md-5 col-6">
                <div class="header-left d-flex align-items-center">
                    <div class="menu-toggle-btn mr-15">
                        <button id="menu-toggle" class="main-btn primary-btn btn-hover" type="button" title="Afficher/Masquer le menu">
                            <i class="lni lni-chevron-left me-1"></i> <span>Menu</span>
                        </button>
                    </div>
                    <div class="header-search d-none d-md-flex">
                        <form action="index.php" method="GET">
                            <input type="hidden" name="page" value="recettes">
                            <input type="text" name="search" placeholder="Rechercher une recette..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" />
                            <button type="submit"><i class="lni lni-search-alt"></i></button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 col-md-7 col-6">
                <div class="header-right">
                    <!-- Notification box -->
                    <div class="notification-box ml-15 d-none d-md-flex">
                        <button class="dropdown-toggle" type="button" id="notification" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="lni lni-alarm"></i>
                            <span class="badge bg-danger rounded-pill">1</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="notification">
                            <li class="p-3 border-bottom">
                                <h6 class="mb-0 fw-bold">Notifications</h6>
                            </li>
                            <li>
                                <a class="dropdown-item py-2" href="#">
                                    <div class="d-flex align-items-center">
                                        <i class="lni lni-checkmark-circle text-success fs-4 me-2"></i>
                                        <div>
                                            <p class="mb-0 small fw-bold">Module Recettes actif</p>
                                            <small class="text-muted">Architecture MVC intégrée</small>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <!-- Profile box -->
                    <div class="profile-box ml-15">
                        <button class="dropdown-toggle bg-transparent border-0 d-flex align-items-center gap-2" type="button" id="profile" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="profile-info">
                                <div class="info text-end d-none d-lg-block">
                                    <h6 class="mb-0 fw-semibold">Admin ESPRIT</h6>
                                    <small class="text-muted">Responsable Recettes</small>
                                </div>
                            </div>
                            <div class="image">
                                <img src="https://ui-avatars.com/api/?name=Admin+Esprit&background=4a6cf7&color=fff&rounded=true" alt="Admin" width="40" height="40" class="rounded-circle border" />
                            </div>
                            <i class="lni lni-chevron-down d-none d-lg-inline"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="profile">
                            <li class="px-3 py-2 border-bottom">
                                <span class="d-block fw-bold">Étudiant ESPRIT</span>
                                <small class="text-muted">Projet Web 2026-2027</small>
                            </li>
                            <li>
                                <a class="dropdown-item py-2" href="index.php?page=recettes">
                                    <i class="lni lni-dinner me-2"></i> Mes Recettes
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item py-2" href="../front/recettes.php" target="_blank">
                                    <i class="lni lni-website me-2"></i> Accès Front-Office
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- ======== header end ======== -->
