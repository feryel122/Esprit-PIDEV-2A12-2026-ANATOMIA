<?php
namespace App\Controllers;

require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../Models/Recette.php';

use App\Models\Recette;

class RecetteController extends Controller
{
    protected string $page = 'recettes';
    protected string $title = 'Gestion des Recettes | PlainAdmin';

    /**
     * Back-Office: Liste des recettes
     */
    public function index(): void
    {
        $search = trim($_GET['search'] ?? '');
        $category = trim($_GET['category'] ?? '');

        $recipes = Recette::all($search, $category);
        $categories = Recette::getCategories();
        $stats = Recette::stats();

        $message = $_GET['msg'] ?? null;
        $error = $_GET['err'] ?? null;

        $this->render('recettes_list', [
            'recipes' => $recipes,
            'categories' => $categories,
            'search' => $search,
            'category' => $category,
            'stats' => $stats,
            'message' => $message,
            'error' => $error
        ]);
    }

    /**
     * Back-Office: Formulaire d'ajout
     */
    public function create(): void
    {
        $this->page = 'recette-add';
        $this->title = 'Ajouter une Recette | Back Office';

        $categories = Recette::getCategories();

        $this->render('recette_form', [
            'isEdit' => false,
            'recipe' => [
                'titre' => '',
                'categorie' => 'Plats Principaux',
                'description' => '',
                'temps_prep' => 15,
                'temps_cuisson' => 30,
                'portions' => 4,
                'difficulte' => 'Facile',
                'calories' => 350,
                'image' => '',
                'statut' => 'Publié',
                'chef' => 'Chef Équipe',
                'ingredients' => [],
                'etapes' => []
            ],
            'categories' => $categories,
            'errors' => []
        ]);
    }

    /**
     * Back-Office: Enregistrement d'une nouvelle recette
     */
    public function store(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?page=recettes');
        }

        $titre = trim($_POST['titre'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $categorie = trim($_POST['categorie'] ?? 'Plats Principaux');
        $temps_prep = (int)($_POST['temps_prep'] ?? 15);
        $temps_cuisson = (int)($_POST['temps_cuisson'] ?? 30);
        $portions = (int)($_POST['portions'] ?? 4);
        $difficulte = trim($_POST['difficulte'] ?? 'Facile');
        $calories = (int)($_POST['calories'] ?? 350);
        $image = trim($_POST['image'] ?? '');
        $statut = trim($_POST['statut'] ?? 'Publié');
        $chef = trim($_POST['chef'] ?? 'Chef Équipe');
        $ingredients = trim($_POST['ingredients'] ?? '');
        $etapes = trim($_POST['etapes'] ?? '');

        // Validation simple
        $errors = [];
        if (empty($titre)) {
            $errors[] = "Le titre de la recette est obligatoire.";
        }
        if (empty($ingredients)) {
            $errors[] = "Veuillez renseigner au moins un ingrédient.";
        }
        if (empty($etapes)) {
            $errors[] = "Veuillez renseigner les étapes de préparation.";
        }

        if (!empty($errors)) {
            $this->page = 'recette-add';
            $this->title = 'Ajouter une Recette | Back Office';
            $this->render('recette_form', [
                'isEdit' => false,
                'recipe' => $_POST,
                'categories' => Recette::getCategories(),
                'errors' => $errors
            ]);
            return;
        }

        $newId = Recette::create([
            'titre' => $titre,
            'categorie' => $categorie,
            'description' => $description,
            'temps_prep' => $temps_prep,
            'temps_cuisson' => $temps_cuisson,
            'portions' => $portions,
            'difficulte' => $difficulte,
            'calories' => $calories,
            'image' => $image,
            'statut' => $statut,
            'chef' => $chef,
            'ingredients' => $ingredients,
            'etapes' => $etapes
        ]);

        $this->redirect('index.php?page=recettes&msg=' . urlencode('Recette ajoutée avec succès !'));
    }

    /**
     * Back-Office: Formulaire de modification
     */
    public function edit(): void
    {
        $id = (int)($_GET['id'] ?? 0);
        $recipe = Recette::find($id);

        if (!$recipe) {
            $this->redirect('index.php?page=recettes&err=' . urlencode('Recette introuvable.'));
        }

        $this->page = 'recette-edit';
        $this->title = 'Modifier la Recette #' . $id . ' | Back Office';

        $this->render('recette_form', [
            'isEdit' => true,
            'recipe' => $recipe,
            'categories' => Recette::getCategories(),
            'errors' => []
        ]);
    }

    /**
     * Back-Office: Traitement de la modification
     */
    public function update(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?page=recettes');
        }

        $id = (int)($_POST['id'] ?? 0);
        $titre = trim($_POST['titre'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $categorie = trim($_POST['categorie'] ?? 'Plats Principaux');
        $temps_prep = (int)($_POST['temps_prep'] ?? 15);
        $temps_cuisson = (int)($_POST['temps_cuisson'] ?? 30);
        $portions = (int)($_POST['portions'] ?? 4);
        $difficulte = trim($_POST['difficulte'] ?? 'Facile');
        $calories = (int)($_POST['calories'] ?? 350);
        $image = trim($_POST['image'] ?? '');
        $statut = trim($_POST['statut'] ?? 'Publié');
        $chef = trim($_POST['chef'] ?? 'Chef Équipe');
        $ingredients = trim($_POST['ingredients'] ?? '');
        $etapes = trim($_POST['etapes'] ?? '');

        $errors = [];
        if (empty($titre)) {
            $errors[] = "Le titre de la recette est obligatoire.";
        }

        if (!empty($errors)) {
            $this->page = 'recette-edit';
            $this->title = 'Modifier la Recette | Back Office';
            $this->render('recette_form', [
                'isEdit' => true,
                'recipe' => $_POST,
                'categories' => Recette::getCategories(),
                'errors' => $errors
            ]);
            return;
        }

        Recette::update($id, [
            'titre' => $titre,
            'categorie' => $categorie,
            'description' => $description,
            'temps_prep' => $temps_prep,
            'temps_cuisson' => $temps_cuisson,
            'portions' => $portions,
            'difficulte' => $difficulte,
            'calories' => $calories,
            'image' => $image,
            'statut' => $statut,
            'chef' => $chef,
            'ingredients' => $ingredients,
            'etapes' => $etapes
        ]);

        $this->redirect('index.php?page=recettes&msg=' . urlencode('Recette modifiée avec succès !'));
    }

    /**
     * Back-Office: Suppression d'une recette
     */
    public function delete(): void
    {
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            Recette::delete($id);
            $this->redirect('index.php?page=recettes&msg=' . urlencode('Recette supprimée avec succès !'));
        } else {
            $this->redirect('index.php?page=recettes&err=' . urlencode('Identifiant de recette invalide.'));
        }
    }
}
