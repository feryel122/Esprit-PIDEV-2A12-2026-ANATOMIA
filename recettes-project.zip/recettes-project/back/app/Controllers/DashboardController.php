<?php
namespace App\Controllers;

require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../Models/Recette.php';

use App\Models\Recette;

class DashboardController extends Controller
{
    protected string $page = 'dashboard';
    protected string $title = 'Tableau de bord | Recettes Admin';

    public function index(): void
    {
        $stats = Recette::stats();
        $recentRecipes = array_slice(Recette::all(), 0, 5);

        $this->render('dashboard', [
            'stats' => $stats,
            'recentRecipes' => $recentRecipes
        ]);
    }
}
