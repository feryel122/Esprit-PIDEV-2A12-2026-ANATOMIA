<?php
namespace App\Controllers;

abstract class Controller
{
    /** Clé de la page courante, utilisée par la sidebar pour l'état actif */
    protected string $page = 'dashboard';

    /** Titre affiché dans <title> */
    protected string $title = 'PlainAdmin | Gestion Recettes';

    /**
     * Rend une vue de contenu (app/Views/pages/{$view}.php) dans le layout commun.
     *
     * @param string $view nom du fichier de vue (sans .php) dans Views/pages
     * @param array $data variables à extraire dans la vue de contenu
     * @param string|null $scriptsView nom du fichier de script spécifique (sans .php) - optionnel
     */
    protected function render(string $view, array $data = [], ?string $scriptsView = null): void
    {
        $content = $this->capture(__DIR__ . '/../Views/pages/' . $view . '.php', $data);
        $extraScripts = $scriptsView
            ? $this->capture(__DIR__ . '/../Views/pages/' . $scriptsView . '.php', $data)
            : '';

        $title = $this->title;
        $currentPage = $this->page;

        require_once __DIR__ . '/../Views/layout.php';
    }

    protected function capture(string $filePath, array $data = []): string
    {
        extract($data);
        ob_start();
        require $filePath;
        return ob_get_clean();
    }

    protected function redirect(string $url): void
    {
        header('Location: ' . $url);
        exit;
    }
}
