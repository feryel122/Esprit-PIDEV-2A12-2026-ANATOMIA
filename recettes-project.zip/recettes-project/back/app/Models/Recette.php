<?php
namespace App\Models;

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Model.php';

class Recette extends Model
{
    private static string $dataFile = DATA_FILE;

    /**
     * Récupère toutes les recettes
     */
    public static function all(string $search = '', string $category = ''): array
    {
        $pdo = self::getPDO();
        if ($pdo) {
            try {
                $sql = "SELECT * FROM recettes WHERE 1=1";
                $params = [];
                if (!empty($search)) {
                    $sql .= " AND (titre LIKE :s1 OR description LIKE :s2 OR ingredients LIKE :s3)";
                    $params[':s1'] = "%$search%";
                    $params[':s2'] = "%$search%";
                    $params[':s3'] = "%$search%";
                }
                if (!empty($category) && $category !== 'Toutes') {
                    $sql .= " AND categorie = :cat";
                    $params[':cat'] = $category;
                }
                $sql .= " ORDER BY id DESC";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $rows = $stmt->fetchAll();
                foreach ($rows as &$row) {
                    if (is_string($row['ingredients'])) {
                        $row['ingredients'] = explode("\n", str_replace("\r", "", $row['ingredients']));
                    }
                    if (is_string($row['etapes'])) {
                        $row['etapes'] = explode("\n", str_replace("\r", "", $row['etapes']));
                    }
                }
                return $rows;
            } catch (\Exception $e) {
                // Fallback to JSON
            }
        }

        // Mode JSON Storage
        $recipes = self::readJson();
        if (!empty($search) || (!empty($category) && $category !== 'Toutes')) {
            $recipes = array_filter($recipes, function($r) use ($search, $category) {
                $matchSearch = true;
                $matchCat = true;
                if (!empty($search)) {
                    $s = mb_strtolower($search);
                    $titleMatch = mb_strpos(mb_strtolower($r['titre'] ?? ''), $s) !== false;
                    $descMatch = mb_strpos(mb_strtolower($r['description'] ?? ''), $s) !== false;
                    $matchSearch = $titleMatch || $descMatch;
                }
                if (!empty($category) && $category !== 'Toutes') {
                    $matchCat = ($r['categorie'] ?? '') === $category;
                }
                return $matchSearch && $matchCat;
            });
        }
        return array_values($recipes);
    }

    /**
     * Récupère une recette par son ID
     */
    public static function find(int $id): ?array
    {
        $pdo = self::getPDO();
        if ($pdo) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM recettes WHERE id = :id LIMIT 1");
                $stmt->execute([':id' => $id]);
                $row = $stmt->fetch();
                if ($row) {
                    if (is_string($row['ingredients'])) {
                        $row['ingredients'] = explode("\n", str_replace("\r", "", $row['ingredients']));
                    }
                    if (is_string($row['etapes'])) {
                        $row['etapes'] = explode("\n", str_replace("\r", "", $row['etapes']));
                    }
                    return $row;
                }
                return null;
            } catch (\Exception $e) {
                // Fallback to JSON
            }
        }

        $recipes = self::readJson();
        foreach ($recipes as $r) {
            if ((int)$r['id'] === $id) {
                return $r;
            }
        }
        return null;
    }

    /**
     * Crée une nouvelle recette
     */
    public static function create(array $data): int
    {
        $ingredientsArr = is_array($data['ingredients']) ? $data['ingredients'] : array_filter(array_map('trim', explode("\n", $data['ingredients'])));
        $etapesArr = is_array($data['etapes']) ? $data['etapes'] : array_filter(array_map('trim', explode("\n", $data['etapes'])));

        $pdo = self::getPDO();
        if ($pdo) {
            try {
                $sql = "INSERT INTO recettes (titre, categorie, description, temps_prep, temps_cuisson, portions, difficulte, calories, image, statut, chef, note, ingredients, etapes)
                        VALUES (:titre, :categorie, :description, :temps_prep, :temps_cuisson, :portions, :difficulte, :calories, :image, :statut, :chef, :note, :ingredients, :etapes)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':titre' => $data['titre'],
                    ':categorie' => $data['categorie'] ?? 'Plats Principaux',
                    ':description' => $data['description'] ?? '',
                    ':temps_prep' => (int)($data['temps_prep'] ?? 15),
                    ':temps_cuisson' => (int)($data['temps_cuisson'] ?? 30),
                    ':portions' => (int)($data['portions'] ?? 4),
                    ':difficulte' => $data['difficulte'] ?? 'Facile',
                    ':calories' => (int)($data['calories'] ?? 350),
                    ':image' => $data['image'] ?? 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800&q=80',
                    ':statut' => $data['statut'] ?? 'Publié',
                    ':chef' => $data['chef'] ?? 'Chef Équipe',
                    ':note' => (float)($data['note'] ?? 4.8),
                    ':ingredients' => implode("\n", $ingredientsArr),
                    ':etapes' => implode("\n", $etapesArr)
                ]);
                return (int)$pdo->lastInsertId();
            } catch (\Exception $e) {
                // Fallback to JSON
            }
        }

        $recipes = self::readJson();
        $maxId = 0;
        foreach ($recipes as $r) {
            if ($r['id'] > $maxId) {
                $maxId = $r['id'];
            }
        }
        $newId = $maxId + 1;

        $newRecipe = [
            'id' => $newId,
            'titre' => $data['titre'],
            'categorie' => $data['categorie'] ?? 'Plats Principaux',
            'description' => $data['description'] ?? '',
            'temps_prep' => (int)($data['temps_prep'] ?? 15),
            'temps_cuisson' => (int)($data['temps_cuisson'] ?? 30),
            'portions' => (int)($data['portions'] ?? 4),
            'difficulte' => $data['difficulte'] ?? 'Facile',
            'calories' => (int)($data['calories'] ?? 350),
            'image' => !empty($data['image']) ? $data['image'] : 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800&q=80',
            'statut' => $data['statut'] ?? 'Publié',
            'chef' => !empty($data['chef']) ? $data['chef'] : 'Chef Équipe',
            'note' => 4.8,
            'created_at' => date('Y-m-d H:i:s'),
            'ingredients' => $ingredientsArr,
            'etapes' => $etapesArr
        ];

        array_unshift($recipes, $newRecipe);
        self::writeJson($recipes);
        return $newId;
    }

    /**
     * Met à jour une recette
     */
    public static function update(int $id, array $data): bool
    {
        $ingredientsArr = is_array($data['ingredients']) ? $data['ingredients'] : array_filter(array_map('trim', explode("\n", $data['ingredients'])));
        $etapesArr = is_array($data['etapes']) ? $data['etapes'] : array_filter(array_map('trim', explode("\n", $data['etapes'])));

        $pdo = self::getPDO();
        if ($pdo) {
            try {
                $sql = "UPDATE recettes SET
                        titre = :titre,
                        categorie = :categorie,
                        description = :description,
                        temps_prep = :temps_prep,
                        temps_cuisson = :temps_cuisson,
                        portions = :portions,
                        difficulte = :difficulte,
                        calories = :calories,
                        image = :image,
                        statut = :statut,
                        chef = :chef,
                        ingredients = :ingredients,
                        etapes = :etapes
                        WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                return $stmt->execute([
                    ':id' => $id,
                    ':titre' => $data['titre'],
                    ':categorie' => $data['categorie'] ?? 'Plats Principaux',
                    ':description' => $data['description'] ?? '',
                    ':temps_prep' => (int)($data['temps_prep'] ?? 15),
                    ':temps_cuisson' => (int)($data['temps_cuisson'] ?? 30),
                    ':portions' => (int)($data['portions'] ?? 4),
                    ':difficulte' => $data['difficulte'] ?? 'Facile',
                    ':calories' => (int)($data['calories'] ?? 350),
                    ':image' => $data['image'] ?? '',
                    ':statut' => $data['statut'] ?? 'Publié',
                    ':chef' => $data['chef'] ?? 'Chef Équipe',
                    ':ingredients' => implode("\n", $ingredientsArr),
                    ':etapes' => implode("\n", $etapesArr)
                ]);
            } catch (\Exception $e) {
                // Fallback to JSON
            }
        }

        $recipes = self::readJson();
        $updated = false;
        foreach ($recipes as &$r) {
            if ((int)$r['id'] === $id) {
                $r['titre'] = $data['titre'];
                $r['categorie'] = $data['categorie'] ?? $r['categorie'];
                $r['description'] = $data['description'] ?? $r['description'];
                $r['temps_prep'] = (int)($data['temps_prep'] ?? $r['temps_prep']);
                $r['temps_cuisson'] = (int)($data['temps_cuisson'] ?? $r['temps_cuisson']);
                $r['portions'] = (int)($data['portions'] ?? $r['portions']);
                $r['difficulte'] = $data['difficulte'] ?? $r['difficulte'];
                $r['calories'] = (int)($data['calories'] ?? $r['calories']);
                if (!empty($data['image'])) {
                    $r['image'] = $data['image'];
                }
                $r['statut'] = $data['statut'] ?? $r['statut'];
                $r['chef'] = $data['chef'] ?? $r['chef'];
                $r['ingredients'] = $ingredientsArr;
                $r['etapes'] = $etapesArr;
                $r['updated_at'] = date('Y-m-d H:i:s');
                $updated = true;
                break;
            }
        }

        if ($updated) {
            self::writeJson($recipes);
        }
        return $updated;
    }

    /**
     * Supprime une recette
     */
    public static function delete(int $id): bool
    {
        $pdo = self::getPDO();
        if ($pdo) {
            try {
                $stmt = $pdo->prepare("DELETE FROM recettes WHERE id = :id");
                return $stmt->execute([':id' => $id]);
            } catch (\Exception $e) {
                // Fallback to JSON
            }
        }

        $recipes = self::readJson();
        $initialCount = count($recipes);
        $recipes = array_filter($recipes, fn($r) => (int)$r['id'] !== $id);
        if (count($recipes) !== $initialCount) {
            self::writeJson(array_values($recipes));
            return true;
        }
        return false;
    }

    /**
     * Retourne les statistiques globales
     */
    public static function stats(): array
    {
        $all = self::all();
        $published = count(array_filter($all, fn($r) => ($r['statut'] ?? '') === 'Publié'));
        $drafts = count(array_filter($all, fn($r) => ($r['statut'] ?? '') === 'Brouillon'));
        $cats = array_unique(array_column($all, 'categorie'));
        return [
            'total' => count($all),
            'published' => $published,
            'drafts' => $drafts,
            'categories_count' => count($cats)
        ];
    }

    /**
     * Retourne la liste des catégories uniques
     */
    public static function getCategories(): array
    {
        return ['Plats Principaux', 'Entrées', 'Desserts', 'Plats Rapides', 'Soupes & Salades', 'Pâtisserie'];
    }

    private static function readJson(): array
    {
        if (!file_exists(self::$dataFile)) {
            return [];
        }
        $raw = file_get_contents(self::$dataFile);
        return json_decode($raw, true) ?: [];
    }

    private static function writeJson(array $data): void
    {
        file_put_contents(self::$dataFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}
