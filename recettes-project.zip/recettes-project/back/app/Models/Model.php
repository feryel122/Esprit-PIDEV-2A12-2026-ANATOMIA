<?php
namespace App\Models;

use PDO;
use PDOException;

abstract class Model
{
    protected static ?PDO $pdo = null;

    /**
     * Récupère la connexion PDO à MySQL si disponible
     */
    public static function getPDO(): ?PDO
    {
        if (self::$pdo === null) {
            try {
                if (defined('DB_HOST') && defined('DB_NAME')) {
                    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
                    self::$pdo = new PDO($dsn, DB_USER, DB_PASS, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                    ]);
                }
            } catch (PDOException $e) {
                // Si MySQL n'est pas encore démarré ou DB absente, on reste en mode fichier JSON
                self::$pdo = null;
            }
        }
        return self::$pdo;
    }
}
