<?php
/**
 * Système de routage Back-Office MVC
 * Workshop Template Integration - ESPRIT
 */

use App\Controllers\DashboardController;
use App\Controllers\RecetteController;

$page = $_GET['page'] ?? 'dashboard';

switch ($page) {
    case 'dashboard':
        $controller = new DashboardController();
        $controller->index();
        break;

    case 'recettes':
        $controller = new RecetteController();
        $controller->index();
        break;

    case 'recette-add':
        $controller = new RecetteController();
        $controller->create();
        break;

    case 'recette-store':
        $controller = new RecetteController();
        $controller->store();
        break;

    case 'recette-edit':
        $controller = new RecetteController();
        $controller->edit();
        break;

    case 'recette-update':
        $controller = new RecetteController();
        $controller->update();
        break;

    case 'recette-delete':
        $controller = new RecetteController();
        $controller->delete();
        break;

    default:
        // Page non trouvée -> rediriger vers le tableau de bord
        $controller = new DashboardController();
        $controller->index();
        break;
}
