(function ($) {
    "use strict";

    // Spinner removal
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 150);
    };
    spinner();

    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 600, 'easeInOutExpo');
        return false;
    });

    // Checkbox strikethrough for recipe ingredients
    $(document).on('change', '.ingredient-checkbox input[type="checkbox"]', function() {
        if ($(this).is(':checked')) {
            $(this).closest('.ingredient-checkbox').addClass('checked');
        } else {
            $(this).closest('.ingredient-checkbox').removeClass('checked');
        }
    });

})(jQuery);
