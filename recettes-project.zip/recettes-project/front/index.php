<?php
header('Location: recettes.php');
exit;
