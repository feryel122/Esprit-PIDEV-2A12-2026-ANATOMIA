<?php
/**
 * Front-Office: Page Détail de la Recette
 * Respecte l'intégration du Workshop (Partie 1)
 */

require_once __DIR__ . '/../back/app/Models/Recette.php';
use App\Models\Recette;

$id = (int)($_GET['id'] ?? 0);
$recipe = Recette::find($id);

if (!$recipe || ($recipe['statut'] ?? '') !== 'Publié') {
    // Si la recette n'existe pas ou n'est pas encore publiée
    header('Location: recettes.php');
    exit;
}

$pageTitle = htmlspecialchars($recipe['titre']) . " | Recettes Délices";
$currentPage = 'recettes';

// Ingrédients et étapes
$ingredients = is_array($recipe['ingredients']) ? $recipe['ingredients'] : array_filter(explode("\n", $recipe['ingredients']));
$etapes = is_array($recipe['etapes']) ? $recipe['etapes'] : array_filter(explode("\n", $recipe['etapes']));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <?php require_once __DIR__ . '/includes/head.php'; ?>
</head>
<body>
    <?php require_once __DIR__ . '/includes/spinner.php'; ?>
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <!-- Breadcrumb -->
    <div class="container mt-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-white p-3 rounded-3 shadow-sm border">
                <li class="breadcrumb-item"><a href="recettes.php" class="text-decoration-none text-primary"><i class="fa fa-home me-1"></i>Accueil</a></li>
                <li class="breadcrumb-item"><a href="recettes.php" class="text-decoration-none text-primary">Recettes</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars($recipe['titre']) ?></li>
            </ol>
        </nav>
    </div>

    <!-- Recipe Detail Container -->
    <div class="container py-3">
        <!-- Recipe Header Card -->
        <div class="recipe-detail-header mb-5">
            <div class="row g-4 align-items-center">
                <!-- Recipe Image -->
                <div class="col-lg-6">
                    <div class="position-relative overflow-hidden rounded-4 shadow-sm" style="height: 380px;">
                        <img src="<?= htmlspecialchars($recipe['image']) ?>" alt="<?= htmlspecialchars($recipe['titre']) ?>" class="w-100 h-100 object-fit-cover" onerror="this.src='https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800&q=80'">
                        <span class="recipe-category-badge fs-6 py-2 px-3">
                            <?= htmlspecialchars($recipe['categorie']) ?>
                        </span>
                    </div>
                </div>

                <!-- Recipe Header Information -->
                <div class="col-lg-6">
                    <div class="ps-lg-3">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <span class="badge bg-light text-primary border px-3 py-2 rounded-pill">
                                <i class="fa fa-user-circle me-1"></i> Par <?= htmlspecialchars($recipe['chef'] ?? 'Chef Équipe') ?>
                            </span>
                            <div class="text-warning">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-alt"></i>
                                <strong class="text-dark ms-1"><?= number_format($recipe['note'] ?? 4.8, 1) ?>/5</strong>
                            </div>
                        </div>

                        <h1 class="display-6 fw-bold mb-3"><?= htmlspecialchars($recipe['titre']) ?></h1>

                        <p class="lead text-muted mb-4 fs-6">
                            <?= htmlspecialchars($recipe['description']) ?>
                        </p>

                        <!-- Key Metrics Grid -->
                        <div class="row g-3 mb-4">
                            <div class="col-sm-3 col-6">
                                <div class="metric-box">
                                    <i class="fa fa-clock d-block"></i>
                                    <div class="label">Préparation</div>
                                    <div class="value"><?= (int)$recipe['temps_prep'] ?> min</div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-6">
                                <div class="metric-box">
                                    <i class="fa fa-fire d-block"></i>
                                    <div class="label">Cuisson</div>
                                    <div class="value"><?= (int)$recipe['temps_cuisson'] ?> min</div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-6">
                                <div class="metric-box">
                                    <i class="fa fa-user-friends d-block"></i>
                                    <div class="label">Portions</div>
                                    <div class="value"><?= (int)$recipe['portions'] ?> pers.</div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-6">
                                <div class="metric-box">
                                    <i class="fa fa-tachometer-alt d-block"></i>
                                    <div class="label">Niveau</div>
                                    <div class="value fs-6"><?= htmlspecialchars($recipe['difficulte']) ?></div>
                                </div>
                            </div>
                        </div>

                        <!-- Buttons Row -->
                        <div class="d-flex gap-2">
                            <button class="btn btn-outline-dark rounded-pill px-4" onclick="window.print()">
                                <i class="fa fa-print me-1"></i> Imprimer
                            </button>
                            <a href="recettes.php" class="btn btn-outline-secondary rounded-pill px-4">
                                <i class="fa fa-arrow-left me-1"></i> Retour aux recettes
                            </a>
                            <a href="../back/index.php?page=recette-edit&id=<?= $recipe['id'] ?>" class="btn btn-outline-primary rounded-pill px-4">
                                <i class="fa fa-edit me-1"></i> Modifier (Admin)
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recipe Content: Ingredients & Steps -->
        <div class="row g-5">
            <!-- Left Column: Ingrédients & Nutrition -->
            <div class="col-lg-5">
                <!-- Ingredients Checklist -->
                <div class="bg-white p-4 rounded-4 shadow-sm border mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                        <h4 class="fw-bold mb-0 text-primary">
                            <i class="fa fa-shopping-basket me-2"></i> Ingrédients
                        </h4>
                        <span class="badge bg-light text-dark border">
                            <?= count($ingredients) ?> éléments
                        </span>
                    </div>
                    <p class="text-muted small mb-3">
                        <i class="fa fa-info-circle me-1"></i> Cochez les ingrédients au fur et à mesure de votre préparation :
                    </p>

                    <div class="ingredients-list">
                        <?php foreach ($ingredients as $idx => $ing): ?>
                            <?php if (!empty(trim($ing))): ?>
                                <label class="ingredient-checkbox">
                                    <input type="checkbox" id="ing_<?= $idx ?>">
                                    <span><?= htmlspecialchars(trim($ing)) ?></span>
                                </label>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Nutrition Box -->
                <div class="bg-white p-4 rounded-4 shadow-sm border">
                    <h5 class="fw-bold mb-3 text-dark">
                        <i class="fa fa-heartbeat text-danger me-2"></i> Valeurs Nutritionnelles
                    </h5>
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <tbody>
                                <tr>
                                    <td class="text-muted">Énergie</td>
                                    <td class="text-end fw-bold text-danger"><?= (int)$recipe['calories'] ?> kcal</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Portion estimée</td>
                                    <td class="text-end fw-bold">1 personne</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Régime</td>
                                    <td class="text-end fw-bold text-success">Fait Maison</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Right Column: Preparation Steps -->
            <div class="col-lg-7">
                <div class="bg-white p-4 rounded-4 shadow-sm border">
                    <h4 class="fw-bold mb-4 pb-2 border-bottom text-primary">
                        <i class="fa fa-clipboard-list me-2"></i> Étapes de Préparation
                    </h4>

                    <div class="steps-list">
                        <?php foreach ($etapes as $num => $step): ?>
                            <?php if (!empty(trim($step))): ?>
                                <div class="step-card">
                                    <div class="step-number"><?= $num + 1 ?></div>
                                    <div class="step-content">
                                        <h6 class="fw-bold mb-1">Étape <?= $num + 1 ?></h6>
                                        <p class="text-muted"><?= htmlspecialchars(trim($step)) ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>

                    <!-- Chef's Tip Box -->
                    <div class="p-3 bg-light rounded-3 border-start border-4 border-warning mt-4">
                        <h6 class="fw-bold text-warning-emphasis mb-1">
                            <i class="fa fa-lightbulb me-1"></i> Astuce du Chef :
                        </h6>
                        <p class="small text-muted mb-0">
                            Pour préserver toutes les saveurs, laissez reposer quelques minutes après la fin de la cuisson avant de servir bien chaud avec votre accompagnement préféré.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require_once __DIR__ . '/includes/footer.php'; ?>
    <?php require_once __DIR__ . '/includes/scripts.php'; ?>
</body>
</html>
