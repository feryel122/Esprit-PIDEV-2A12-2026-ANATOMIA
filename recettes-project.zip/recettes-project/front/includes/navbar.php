<?php
// $currentPage doit être défini dans la page appelante (ex: $currentPage = 'recettes';)
if (!isset($currentPage)) {
    $currentPage = '';
}

function navActive($page, $currentPage) {
    return $page === $currentPage ? 'active' : '';
}
?>
<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm sticky-top p-0">
    <div class="container py-2">
        <a href="recettes.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary"><i class="fa fa-utensils me-3"></i>Recettes<span class="text-dark">Délices</span></h2>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="recettes.php" class="nav-item nav-link <?= navActive('recettes', $currentPage) ?>">
                    <i class="fa fa-book-open me-1"></i> Toutes les Recettes
                </a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="fa fa-th-large me-1"></i> Catégories
                    </a>
                    <div class="dropdown-menu fade-down m-0 shadow">
                        <a href="recettes.php?category=Plats+Principaux" class="dropdown-item">Plats Principaux</a>
                        <a href="recettes.php?category=Entrées" class="dropdown-item">Entrées & Salades</a>
                        <a href="recettes.php?category=Desserts" class="dropdown-item">Desserts & Pâtisserie</a>
                        <a href="recettes.php?category=Plats+Rapides" class="dropdown-item">Plats Rapides</a>
                    </div>
                </div>
                <a href="#about-section" class="nav-item nav-link <?= navActive('about', $currentPage) ?>">
                    À Propos
                </a>
            </div>
            <!-- Bouton vers le Back-Office -->
            <a href="../back/index.php" class="btn btn-primary py-2 px-4 d-none d-lg-block rounded-pill ms-3">
                <i class="fa fa-cog me-2"></i> Espace Admin <i class="fa fa-arrow-right ms-2"></i>
            </a>
        </div>
    </div>
</nav>
<!-- Navbar End -->
