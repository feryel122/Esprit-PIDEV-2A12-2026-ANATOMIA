<meta charset="utf-8">
<title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Recettes Délices | Front Office' ?></title>
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="recettes de cuisine, gastronomie tunisienne, délices culinaires" name="keywords">
<meta content="Plateforme de partage et découverte des meilleures recettes culinaires" name="description">

<!-- Favicon -->
<link href="https://cdn-icons-png.flaticon.com/512/3565/3565418.png" rel="icon">

<!-- Google Web Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

<!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css" rel="stylesheet">

<!-- Customized Bootstrap 5 Stylesheet -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Template Stylesheet -->
<link href="assets/css/style.css" rel="stylesheet">
