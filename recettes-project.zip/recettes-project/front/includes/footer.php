<!-- Footer Start -->
<div class="container-fluid footer pt-5 mt-5">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-4 col-md-6">
                <h4 class="text-white mb-3">Recettes Délices</h4>
                <p class="text-muted">
                    Projet Technologies Web 2026-2027 à ESPRIT. Module de gestion et consultation des recettes gastronomiques tunisiennes et internationales.
                </p>
                <div class="d-flex pt-2">
                    <a class="btn btn-outline-light btn-social me-2 rounded-circle" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social me-2 rounded-circle" href=""><i class="fab fa-instagram"></i></a>
                    <a class="btn btn-outline-light btn-social me-2 rounded-circle" href=""><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <h4 class="text-white mb-3">Navigation Rapide</h4>
                <a class="btn btn-link" href="recettes.php">Toutes les recettes</a>
                <a class="btn btn-link" href="recettes.php?category=Plats+Principaux">Plats Principaux</a>
                <a class="btn btn-link" href="recettes.php?category=Entrées">Entrées & Salades</a>
                <a class="btn btn-link" href="recettes.php?category=Desserts">Desserts gourmands</a>
                <a class="btn btn-link" href="../back/index.php">Administration Back-Office</a>
            </div>
            <div class="col-lg-4 col-md-6" id="about-section">
                <h4 class="text-white mb-3">À Propos du Projet</h4>
                <p class="text-muted">
                    Réalisé conformément aux directives du Workshop d'intégration de templates (Front-Office eLEARNING et Back-Office PlainAdmin MVC).
                </p>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>ESPRIT, Ariana, Tunisie</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>contact@recettes-esprit.tn</p>
            </div>
        </div>
    </div>
    <div class="container border-top border-secondary py-4">
        <div class="row">
            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0 text-muted">
                &copy; 2026-2027 <a class="border-bottom text-white text-decoration-none" href="#">Recettes Délices</a>, Tous droits réservés.
            </div>
            <div class="col-md-6 text-center text-md-end text-muted">
                Intégration Template MVC (Front eLEARNING / Back PlainAdmin)
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->

<!-- Back to Top -->
<a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
