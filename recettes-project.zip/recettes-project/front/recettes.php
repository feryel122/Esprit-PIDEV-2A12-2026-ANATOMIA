<?php
/**
 * Front-Office: Page Liste des Recettes
 * Respecte l'intégration du Workshop (Partie 1)
 */

$pageTitle = "Découvrez nos Recettes Gourmandes | Recettes Délices";
$currentPage = 'recettes';

// Chargement du modèle de données partagé
require_once __DIR__ . '/../back/app/Models/Recette.php';
use App\Models\Recette;

$search = trim($_GET['search'] ?? '');
$category = trim($_GET['category'] ?? '');

// Récupération des recettes publiées uniquement pour le Front
$allRecipes = Recette::all($search, $category);
$recipes = array_filter($allRecipes, fn($r) => ($r['statut'] ?? '') === 'Publié');
$categories = Recette::getCategories();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <?php require_once __DIR__ . '/includes/head.php'; ?>
</head>
<body>
    <?php require_once __DIR__ . '/includes/spinner.php'; ?>
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <!-- Header / Hero Section -->
    <div class="container-fluid page-header position-relative text-white mb-5">
        <div class="container text-center py-4">
            <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fw-bold mb-3 text-uppercase">
                <i class="fa fa-fire me-1"></i> Recettes Authentiques & Savoureuses
            </span>
            <h1 class="display-4 text-white animated slideInDown fw-bold mb-3">Le Plaisir de Cuisiner Chez Soi</h1>
            <p class="lead text-light mb-4 mx-auto" style="max-width: 700px;">
                Explorez nos meilleures recettes traditionnelles et contemporaines, faciles à réaliser avec des ingrédients frais.
            </p>

            <!-- Search Bar in Hero -->
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-8">
                    <form action="recettes.php" method="GET" class="position-relative">
                        <?php if (!empty($category)): ?>
                            <input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
                        <?php endif; ?>
                        <input class="form-control border-0 w-100 py-3 ps-4 pe-5 rounded-pill shadow" type="text" name="search" placeholder="Rechercher par ingrédient, nom de plat..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-primary py-2 px-4 position-absolute top-0 end-0 me-2 rounded-pill shadow-sm" style="margin-top: 6px;">
                            <i class="fa fa-search me-1"></i> Trouver
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container py-4">
        <!-- Categories Filter Bar -->
        <div class="row mb-5">
            <div class="col-12 text-center">
                <div class="d-flex flex-wrap justify-content-center gap-2">
                    <a href="recettes.php<?= !empty($search) ? '?search=' . urlencode($search) : '' ?>" class="filter-btn <?= empty($category) ? 'active' : '' ?>">
                        <i class="fa fa-border-all me-1"></i> Toutes les Recettes
                    </a>
                    <?php foreach ($categories as $cat): ?>
                        <a href="recettes.php?category=<?= urlencode($cat) ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" class="filter-btn <?= ($category === $cat) ? 'active' : '' ?>">
                            <?= htmlspecialchars($cat) ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Recipe Results Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
            <div>
                <h3 class="fw-bold mb-1">
                    <?= !empty($category) ? htmlspecialchars($category) : 'Toutes nos Délicieuses Recettes' ?>
                </h3>
                <p class="text-muted small mb-0">
                    <?= count($recipes) ?> recette(s) disponible(s) <?= !empty($search) ? 'pour la recherche "' . htmlspecialchars($search) . '"' : '' ?>
                </p>
            </div>
            <?php if (!empty($search) || !empty($category)): ?>
                <a href="recettes.php" class="btn btn-sm btn-outline-secondary rounded-pill">
                    <i class="fa fa-times me-1"></i> Effacer les filtres
                </a>
            <?php endif; ?>
        </div>

        <!-- Recipe Grid -->
        <div class="row g-4">
            <?php if (empty($recipes)): ?>
                <div class="col-12 text-center py-5">
                    <div class="p-5 bg-white rounded-4 shadow-sm border">
                        <i class="fa fa-utensils text-muted display-3 mb-3"></i>
                        <h4 class="fw-bold">Aucune recette trouvée</h4>
                        <p class="text-muted">Aucune recette ne correspond à votre recherche ou catégorie sélectionnée.</p>
                        <a href="recettes.php" class="btn btn-primary rounded-pill px-4 mt-2">
                            Réinitialiser la recherche
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($recipes as $r): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="recipe-item">
                            <!-- Image + Badges -->
                            <div class="recipe-img">
                                <a href="recette-detail.php?id=<?= $r['id'] ?>">
                                    <img src="<?= htmlspecialchars($r['image']) ?>" alt="<?= htmlspecialchars($r['titre']) ?>" onerror="this.src='https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=600&q=80'">
                                </a>
                                <span class="recipe-category-badge">
                                    <?= htmlspecialchars($r['categorie']) ?>
                                </span>
                                <span class="recipe-time-badge">
                                    <i class="fa fa-clock me-1"></i> <?= (int)$r['temps_prep'] + (int)$r['temps_cuisson'] ?> min
                                </span>
                            </div>

                            <!-- Body -->
                            <div class="recipe-body">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <small class="text-muted">
                                        <i class="fa fa-user-circle me-1 text-primary"></i> <?= htmlspecialchars($r['chef'] ?? 'Chef') ?>
                                    </small>
                                    <div class="text-warning small">
                                        <i class="fa fa-star"></i> <?= number_format($r['note'] ?? 4.8, 1) ?>
                                    </div>
                                </div>

                                <h4 class="recipe-title">
                                    <a href="recette-detail.php?id=<?= $r['id'] ?>">
                                        <?= htmlspecialchars($r['titre']) ?>
                                    </a>
                                </h4>

                                <p class="recipe-desc">
                                    <?= htmlspecialchars(mb_substr($r['description'] ?? '', 0, 110)) ?>...
                                </p>

                                <!-- Meta Info -->
                                <div class="recipe-meta">
                                    <span>
                                        <i class="fa fa-user-friends me-1 text-muted"></i> <?= (int)$r['portions'] ?> pers.
                                    </span>
                                    <span>
                                        <i class="fa fa-burn me-1 text-danger"></i> <?= (int)$r['calories'] ?> kcal
                                    </span>
                                    <span class="badge bg-light text-dark border">
                                        <?= htmlspecialchars($r['difficulte']) ?>
                                    </span>
                                </div>

                                <!-- Detail Link Button -->
                                <div class="mt-3 pt-2">
                                    <a href="recette-detail.php?id=<?= $r['id'] ?>" class="btn btn-outline-primary w-100 rounded-pill">
                                        Voir la recette <i class="fa fa-arrow-right ms-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php require_once __DIR__ . '/includes/footer.php'; ?>
    <?php require_once __DIR__ . '/includes/scripts.php'; ?>
</body>
</html>
