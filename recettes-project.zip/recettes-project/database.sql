-- Base de données pour le module Gestion des Recettes
-- Projet Technologies Web 2026-2027

CREATE DATABASE IF NOT EXISTS `recettes_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `recettes_db`;

-- Structure de la table des recettes
CREATE TABLE IF NOT EXISTS `recettes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `titre` VARCHAR(255) NOT NULL,
  `categorie` VARCHAR(100) NOT NULL,
  `description` TEXT NOT NULL,
  `temps_prep` INT NOT NULL DEFAULT 15,
  `temps_cuisson` INT NOT NULL DEFAULT 30,
  `portions` INT NOT NULL DEFAULT 4,
  `difficulte` ENUM('Facile', 'Moyen', 'Difficile') DEFAULT 'Facile',
  `calories` INT DEFAULT 350,
  `image` VARCHAR(500) DEFAULT '',
  `statut` ENUM('Publié', 'Brouillon') DEFAULT 'Publié',
  `chef` VARCHAR(150) DEFAULT 'Chef Invité',
  `note` DECIMAL(2,1) DEFAULT 4.5,
  `ingredients` TEXT NOT NULL,
  `etapes` TEXT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Données initiales
INSERT INTO `recettes` (`id`, `titre`, `categorie`, `description`, `temps_prep`, `temps_cuisson`, `portions`, `difficulte`, `calories`, `image`, `statut`, `chef`, `note`, `ingredients`, `etapes`) VALUES
(1, 'Couscous Tunisien traditionnel à l\'Agneau', 'Plats Principaux', 'Le plat emblématique de la gastronomie tunisienne avec légumes et viande d\'agneau.', 30, 60, 6, 'Moyen', 650, 'https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&w=800&q=80', 'Publié', 'Chef Mohamed', 4.9, '800g de semoule de blé fine\n1 kg d\'agneau\n3 carottes\n2 courgettes\n1 tasse pois chiches\n2 c.à.s concentré tomate\n1 c.à.s harissa\nHuile d\'olive, épices', '1. Faire revenir la viande avec épices et tomates.\n2. Mouiller et cuire la semoule à la vapeur.\n3. Ajouter légumes et laisser mijoter.\n4. Arroser la semoule et servir chaud.'),
(2, 'Ojja Tunisienne aux Merguez & Œufs', 'Plats Rapides', 'Sauce tomate relevée à l\'ail, carvi et harissa, surmontée de merguez et d\'œufs frais.', 15, 20, 4, 'Facile', 480, 'https://images.unsplash.com/photo-1590412200988-a436970781fa?auto=format&fit=crop&w=800&q=80', 'Publié', 'Chef Fatma', 4.8, '300g merguez\n4 œufs\n5 tomates mûres\n2 poivrons verts\n4 gousses d\'ail\nHarissa et carvi', '1. Dorer les merguez.\n2. Faire revenir ail et poivrons avec les tomates.\n3. Casser les œufs et cuire à feu doux.\n4. Servir chaud avec du pain.'),
(3, 'Salade Méchouia aux Poivrons Grillés', 'Entrées', 'Salade de poivrons et tomates grillés au feu de bois avec thon et œufs durs.', 25, 20, 4, 'Facile', 260, 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80', 'Publié', 'Chef Yassine', 4.7, '1 kg piments doux\n4 tomates\n1 oignon\nAil\nThon et olives\nHuile d\'olive et tabel', '1. Griller les légumes.\n2. Peler et épépiner.\n3. Hacher au couteau.\n4. Assaisonner avec huile d\'olive et dresser avec thon.');
