# Module Recettes - Projet Technologies Web (ESPRIT 2026-2027)

Ce projet implémente l'intégration complète des templates **Front-Office** et **Back-Office** pour le module **Recettes**, en respectant scrupuleusement les consignes pédagogiques du Workshop d'intégration et les règles de l'architecture **MVC (Modèle - Vue - Contrôleur)**.

---

## 📁 Architecture du Projet

```
recettes-project/
├── index.php                      # Point d'entrée principal (Redirige vers Front ou Back)
├── database.sql                   # Script SQL pour importer la table `recettes` dans phpMyAdmin
│
├── front/                         # MODULE FRONT-OFFICE (Conforme Atelier Partie 1 - eLEARNING)
│   ├── index.php                  # Redirection vers recettes.php
│   ├── recettes.php               # Front : Liste des recettes (Recherche, Filtres, Cartes dynamiques)
│   ├── recette-detail.php         # Front : Détail de la recette (Ingrédients à cocher, étapes, nutrition)
│   ├── includes/                  # Composants réutilisables
│   │   ├── head.php               # Métas, polices Google Fonts, CSS Bootstrap
│   │   ├── spinner.php            # Preloader spinner
│   │   ├── navbar.php             # Barre de navigation avec fonction dynamique navActive()
│   │   ├── footer.php             # Pied de page & bouton "Back to Top"
│   │   └── scripts.php            # Scripts JS (Bootstrap, jQuery, main.js)
│   └── assets/
│       ├── css/style.css          # Feuilles de styles personnalisées
│       └── js/main.js             # Interactions client (checklist, back-to-top)
│
└── back/                          # MODULE BACK-OFFICE (Conforme Atelier Partie 2 - PlainAdmin MVC)
    ├── index.php                  # Point d'entrée Back-Office (Session & Dispatching)
    └── app/
        ├── config.php             # Configuration générale & constantes DB
        ├── routes.php             # Système de routage centralisé (?page=...)
        ├── Controllers/
        │   ├── Controller.php     # Contrôleur abstrait de base (méthodes render & capture)
        │   ├── DashboardController.php # Statistiques & récapitulatif
        │   └── RecetteController.php   # CRUD complet (Liste, Ajout, Modification, Suppression)
        ├── Models/
        │   ├── Model.php          # Modèle parent avec gestionnaire PDO
        │   └── Recette.php        # Modèle Recette (persistance hybride JSON + PDO MySQL)
        ├── data/
        │   └── recettes.json      # Stockage de données prêt à l'emploi (6 recettes initiales)
        └── Views/
            ├── layout.php         # Layout maître assemblant head, sidebar, header, $content, footer
            ├── helpers.php        # Helpers pour le menu actif (isActive, isOpen, isCollapsed)
            ├── partials/          # Éléments réutilisables du Back-Office
            │   ├── head.php       # En-tête HTML & préchargeur
            │   ├── sidebar.php    # Menu latéral avec gestion dynamique de la page active
            │   ├── header.php     # Barre supérieure avec profil et recherche
            │   ├── footer.php     # Pied de page
            │   └── scripts.php    # Injection de scripts JS et $extraScripts
            ├── pages/             # Vues de contenu pur injectées dans le layout
            │   ├── dashboard.php  # Vue Tableau de bord (KPIs, dernières recettes)
            │   ├── recettes_list.php # Back : Table CRUD avec filtres et actions
            │   └── recette_form.php  # Back : Formulaire unifié (Ajout & Modification)
            └── assets/
                ├── css/main.css   # Styles PlainAdmin
                └── js/main.js     # Logique de bascule sidebar (menu-toggle)
```

---

## 🚀 Fonctionnalités Développées

### 1. Front-Office (Espace Public & Visiteurs)
- **Liste des recettes (`front/recettes.php`)** :
  - Recherche dynamique par mot-clé et nom d'ingrédient.
  - Filtres par catégorie (Plats Principaux, Entrées, Desserts, Plats Rapides).
  - Cartes culinaires avec badges de temps total, difficulté, calories et note du chef.
  - Bouton vers la vue détaillée.
- **Détail de la recette (`front/recette-detail.php`)** :
  - Grande photo du plat et fiche technique (temps de préparation, cuisson, portions, difficulté).
  - Liste interactive des ingrédients avec cases à cocher (checklist en cours de cuisine).
  - Étapes de préparation numérotées et astuce du chef.
  - Tableau des valeurs nutritionnelles.
  - Bouton d'impression de la recette et retour à la liste.
  - Lien direct vers la modification admin si besoin.

### 2. Back-Office (Espace Administration PlainAdmin)
- **Tableau de bord (`back/index.php?page=dashboard`)** :
  - 4 cartes d'indicateurs (Total recettes, Recettes publiées, Catégories actives, Brouillons).
  - Tableau récapitulatif des recettes récentes.
- **Liste des recettes (`back/index.php?page=recettes`)** :
  - Tableau de gestion avec miniatures d'images, temps, portions, badges de difficulté et statut.
  - Barre de recherche et filtrage par catégorie.
  - Messages Flash (succès après ajout, modification ou suppression).
- **Ajout de recette (`back/index.php?page=recette-add`)** :
  - Formulaire complet avec validation des champs obligatoires.
  - Prévisualisation instantanée de l'URL de l'image.
  - Saisie intuitive des ingrédients et étapes (une ligne par élément).
- **Modification de recette (`back/index.php?page=recette-edit&id=X`)** :
  - Même formulaire pré-rempli avec les données existantes.
  - Mise à jour immédiate.
- **Suppression de recette (`back/index.php?page=recette-delete&id=X`)** :
  - Boîte de dialogue modale de confirmation pour éviter les suppressions accidentelles.

---

## 🛠️ Comment Tester et Exécuter le Projet

### Option A : Avec le serveur intégré PHP (Rapide)
1. Ouvrez un terminal dans le dossier du projet :
   ```bash
   cd "C:\Users\ezerb\.gemini\antigravity\scratch\recettes-project"
   ```
2. Lancez le serveur local PHP :
   ```bash
   "C:\xampp\php\php.exe" -S localhost:8000
   ```
3. Ouvrez votre navigateur :
   - **Front-Office (Liste)** : `http://localhost:8000/front/recettes.php`
   - **Back-Office (Admin)** : `http://localhost:8000/back/index.php?page=dashboard`
   - **Back-Office (Liste Recettes)** : `http://localhost:8000/back/index.php?page=recettes`

### Option B : Dans XAMPP (Apache)
1. Copiez le dossier `recettes-project` vers votre dossier `C:\xampp\htdocs\recettes-project`.
2. Démarrez Apache et MySQL depuis le panneau de contrôle XAMPP.
3. Accédez à l'URL : `http://localhost/recettes-project/`.
4. (Optionnel) Pour utiliser MySQL plutôt que le stockage JSON : importez le fichier `database.sql` dans phpMyAdmin (`http://localhost/phpmyadmin/`). Le modèle basculera automatiquement sur MySQL dès que la base sera créée !
