<?php
/**
 * Portail Principal - Module Recettes
 * Projet Technologies Web 2026-2027 (ESPRIT)
 * Architecture MVC & Intégration Templates (Front eLEARNING & Back PlainAdmin)
 */

$requestPage = $_GET['page'] ?? '';

// Si un paramètre de page Back-Office est demandé, transférer vers le Back-Office
if (!empty($requestPage)) {
    header('Location: back/index.php?' . $_SERVER['QUERY_STRING']);
    exit;
}

// Par défaut, redirection directe vers le Front-Office des recettes
header('Location: front/recettes.php');
exit;
