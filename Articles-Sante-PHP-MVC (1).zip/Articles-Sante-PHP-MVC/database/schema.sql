CREATE DATABASE IF NOT EXISTS articles_sante CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE articles_sante;
CREATE TABLE IF NOT EXISTS categories (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nom VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS articles (
 id INT AUTO_INCREMENT PRIMARY KEY,
 titre VARCHAR(100) NOT NULL,
 description VARCHAR(220) NOT NULL,
 contenu TEXT NOT NULL,
 image VARCHAR(500) NULL,
 date_publication DATE NOT NULL,
 categorie_id INT NOT NULL,
 CONSTRAINT fk_article_categorie FOREIGN KEY (categorie_id) REFERENCES categories(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;
INSERT IGNORE INTO categories(nom) VALUES ('Nutrition'),('Sport'),('Sommeil'),('Prévention');
