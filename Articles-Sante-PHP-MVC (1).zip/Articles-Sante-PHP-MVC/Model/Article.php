<?php
class Article {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }
    public function getAll(): array { $sql='SELECT a.*, c.nom AS categorie FROM articles a INNER JOIN categories c ON a.categorie_id=c.id ORDER BY a.date_publication DESC, a.id DESC'; return $this->db->query($sql)->fetchAll(); }
    public function find(int $id): ?array { $q=$this->db->prepare('SELECT a.*, c.nom AS categorie FROM articles a INNER JOIN categories c ON a.categorie_id=c.id WHERE a.id=?'); $q->execute([$id]); return $q->fetch() ?: null; }
    public function create(array $data): bool { $sql='INSERT INTO articles(titre, description, contenu, image, date_publication, categorie_id) VALUES(:titre,:description,:contenu,:image,:date_publication,:categorie_id)'; return $this->db->prepare($sql)->execute($data); }
    public function update(int $id, array $data): bool { $data['id']=$id; $sql='UPDATE articles SET titre=:titre, description=:description, contenu=:contenu, image=:image, date_publication=:date_publication, categorie_id=:categorie_id WHERE id=:id'; return $this->db->prepare($sql)->execute($data); }
    public function delete(int $id): bool { $q=$this->db->prepare('DELETE FROM articles WHERE id=?'); return $q->execute([$id]); }
}
