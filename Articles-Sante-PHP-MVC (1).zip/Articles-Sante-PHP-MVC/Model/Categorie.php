<?php
class Categorie {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }
    public function getAll(): array { return $this->db->query('SELECT * FROM categories ORDER BY nom')->fetchAll(); }
    public function find(int $id): ?array { $q=$this->db->prepare('SELECT * FROM categories WHERE id=?'); $q->execute([$id]); return $q->fetch() ?: null; }
    public function create(string $nom): bool { $q=$this->db->prepare('INSERT INTO categories(nom) VALUES(?)'); return $q->execute([$nom]); }
    public function delete(int $id): bool { $q=$this->db->prepare('DELETE FROM categories WHERE id=?'); return $q->execute([$id]); }
    public function countArticles(int $id): int { $q=$this->db->prepare('SELECT COUNT(*) FROM articles WHERE categorie_id=?'); $q->execute([$id]); return (int)$q->fetchColumn(); }
}
