# Articles-Santé — PHP / POO / PDO / MVC

Projet de module avec conservation du thème graphique Vitalité et séparation MVC.

## Technologies
- HTML : structure des pages (dans les vues PHP)
- CSS : `assets/css/style.css`
- JavaScript : recherche/filtrage et validation côté client (`assets/js/`)
- PHP orienté objet : Models et Controllers
- PDO : accès à MySQL avec requêtes préparées

## Installation locale (XAMPP)
1. Copier le dossier `Articles-Sante-PHP-MVC` dans `C:/xampp/htdocs/`.
2. Démarrer Apache et MySQL depuis XAMPP.
3. Ouvrir phpMyAdmin, importer `database/schema.sql`.
4. Vérifier les identifiants dans `config/database.php` (par défaut XAMPP : utilisateur `root`, mot de passe vide).
5. Ouvrir `http://localhost/Articles-Sante-PHP-MVC/`.

## Fonctionnalités
- Front Office : liste, recherche, filtre par catégorie, détail d'un article.
- Back Office : tableau de bord, CRUD Articles, ajout/suppression Catégories.
- Jointure SQL Article/Catégorie dans les méthodes de lecture du Model Article.
- Règles métiers : champs obligatoires, longueurs, URL image, catégorie utilisée non supprimable.
- Validation côté navigateur et validation côté serveur PHP.

## Architecture
- `Model/` : classes Article et Categorie (PDO)
- `Controller/` : logique et validation
- `View/` : interfaces Front Office et Back Office
- `config/` : connexion PDO
- `database/` : script SQL de création des tables

## À savoir
Cette version utilise bien PDO avec MySQL : la base doit donc être créée et le serveur MySQL démarré. Le CRUD des utilisateurs, l'authentification et les permissions de l'équipe sont à intégrer dans le cadre de la partie collective du projet. Ne mettez pas cette version en production sans ajouter l'authentification et la protection des routes Back Office.
