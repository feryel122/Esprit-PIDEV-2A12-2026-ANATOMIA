<?php
class ArticleController {
    private Article $model;
    public function __construct(Article $model) { $this->model=$model; }
    public function index(): array { return $this->model->getAll(); }
    public function show(int $id): ?array { return $this->model->find($id); }
    public function save(array $input, ?int $id=null): array {
        $data=['titre'=>trim($input['titre'] ?? ''),'description'=>trim($input['description'] ?? ''),'contenu'=>trim($input['contenu'] ?? ''),'image'=>trim($input['image'] ?? ''),'date_publication'=>$input['date_publication'] ?? '', 'categorie_id'=>(int)($input['categorie_id'] ?? 0)];
        $errors=[];
        if(strlen($data['titre'])<5 || strlen($data['titre'])>100) $errors[]='Le titre doit contenir entre 5 et 100 caractères.';
        if(strlen($data['description'])<10 || strlen($data['description'])>220) $errors[]='La description doit contenir entre 10 et 220 caractères.';
        if(strlen($data['contenu'])<20) $errors[]='Le contenu doit contenir au moins 20 caractères.';
        if(!$data['categorie_id']) $errors[]='Veuillez choisir une catégorie.';
        if(!$data['date_publication']) $errors[]='La date est obligatoire.';
        if($data['image']!=='' && !filter_var($data['image'], FILTER_VALIDATE_URL)) $errors[]='URL de l’image invalide.';
        if(!$errors) { $id ? $this->model->update($id,$data) : $this->model->create($data); }
        return $errors;
    }
    public function delete(int $id): void { $this->model->delete($id); }
}
