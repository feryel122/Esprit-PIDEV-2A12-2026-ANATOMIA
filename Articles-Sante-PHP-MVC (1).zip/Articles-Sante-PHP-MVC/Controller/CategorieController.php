<?php
class CategorieController {
    private Categorie $model;
    public function __construct(Categorie $model) { $this->model=$model; }
    public function index(): array { return $this->model->getAll(); }
    public function save(string $nom): ?string { $nom=trim($nom); if(strlen($nom)<3 || strlen($nom)>50) return 'Le nom doit contenir entre 3 et 50 caractères.'; foreach($this->model->getAll() as $c) if(mb_strtolower($c['nom'])===mb_strtolower($nom)) return 'Cette catégorie existe déjà.'; $this->model->create($nom); return null; }
    public function delete(int $id): ?string { if($this->model->countArticles($id)>0) return 'Impossible de supprimer une catégorie utilisée par des articles.'; $this->model->delete($id); return null; }
}
