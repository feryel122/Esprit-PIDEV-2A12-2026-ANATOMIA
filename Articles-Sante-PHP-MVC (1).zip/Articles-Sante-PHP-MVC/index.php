<?php
session_start();
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/Model/Article.php';
require_once __DIR__.'/Model/Categorie.php';
require_once __DIR__.'/Controller/ArticleController.php';
require_once __DIR__.'/Controller/CategorieController.php';
try { $pdo=(new Database())->getConnection(); }
catch(PDOException $e) { http_response_code(500); die('Connexion à la base impossible. Vérifiez config/database.php et importez database/schema.sql.'); }
$articles=new ArticleController(new Article($pdo));
$categories=new CategorieController(new Categorie($pdo));
$page=$_GET['page'] ?? 'articles';
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function redirectTo(string $url): never { header('Location: '.$url); exit; }
$errors=[]; $message='';
if($_SERVER['REQUEST_METHOD']==='POST') {
  $action=$_POST['action'] ?? '';
  if($action==='article_save') { $id=isset($_POST['id'])?(int)$_POST['id']:null; $errors=$articles->save($_POST,$id); if(!$errors) redirectTo('index.php?page=admin-articles'); }
  elseif($action==='article_delete') { $articles->delete((int)$_POST['id']); redirectTo('index.php?page=admin-articles'); }
  elseif($action==='category_save') { $message=$categories->save($_POST['nom'] ?? '') ?? 'Catégorie ajoutée.'; }
  elseif($action==='category_delete') { $message=$categories->delete((int)$_POST['id']) ?? 'Catégorie supprimée.'; }
}
$allCategories=$categories->index();
if($page==='article-details') { $article=$articles->show((int)($_GET['id']??0)); require __DIR__.'/View/FrontOffice/article-details.php'; }
elseif($page==='admin-articles') { $allArticles=$articles->index(); require __DIR__.'/View/BackOffice/articles.php'; }
elseif($page==='article-form') { $id=isset($_GET['id'])?(int)$_GET['id']:null; $article=$id?$articles->show($id):null; require __DIR__.'/View/BackOffice/article-form.php'; }
elseif($page==='categories') { require __DIR__.'/View/BackOffice/categories.php'; }
elseif($page==='dashboard') { $allArticles=$articles->index(); require __DIR__.'/View/BackOffice/dashboard.php'; }
else { $allArticles=$articles->index(); require __DIR__.'/View/FrontOffice/articles.php'; }
