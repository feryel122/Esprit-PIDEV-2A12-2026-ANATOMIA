# ANATOMIA — Thème Corail

Projet PHP séparé en deux espaces :
- `FrontOffice/` : pages visibles par les visiteurs et composants communs dans `includes/`.
- `BackOffice/` : panneau d'administration organisé selon une structure MVC simple.

## Identité visuelle — Thème Corail

- Corail : `#E8806F`
- Vert tisane : `#3E6B4F`
- Brun profond : `#2B1B17`
- Crème : `#FBF1E8`
- Rouge organe : `#A8322A`

Les couleurs sont définies en variables CSS dans les feuilles de style du Front-Office et du Back-Office.

## Prérequis
- PHP 8 ou supérieur recommandé.
- XAMPP/WAMP, ou le serveur intégré de PHP.

## Lancer le Front-Office
Depuis le dossier du projet :
```bash
cd FrontOffice
php -S localhost:8000
```
Ouvrir `http://localhost:8000`.

## Lancer le Back-Office
Dans un autre terminal :
```bash
cd BackOffice
php -S localhost:8001
```
Ouvrir `http://localhost:8001`.

Les deux espaces sont indépendants et peuvent aussi être placés dans `htdocs` sous XAMPP.

## Organisation
### FrontOffice
- `index.php` gère la page demandée et charge les composants communs.
- `includes/` contient head, navbar, footer et scripts.
- `pages/` contient le contenu propre à chaque page.
- `assets/` contient CSS, JavaScript et images.

### BackOffice
- `index.php` et `app/routes.php` gèrent le routage simple.
- `app/Controllers/` contient les contrôleurs.
- `app/Models/` contiendra les classes d'accès aux données.
- `app/Views/layout.php` assemble les vues et les composants communs.
- `app/Views/partials/` contient les parties réutilisables.
- `app/Views/pages/` contient le contenu propre à chaque page.
- `assets/` contient les ressources statiques.

## À compléter par l'équipe
1. Ajouter les images et le contenu réel dans `FrontOffice/assets/images/` et les pages.
2. Intégrer le template Front-Office fourni par l'enseignant si nécessaire.
3. Ajouter la base de données et les modèles.
4. Développer les fonctionnalités CRUD et les contrôleurs associés.
5. Remplacer les données de démonstration du dashboard par les vraies statistiques.

