<?php
if (!isset($currentPage)) {
    $currentPage = '';
}

function navActive($page, $currentPage) {
    return $page === $currentPage ? 'active' : '';
}
?>

<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h2 class="m-0 text-primary">ANATOMIA</h2>
    </a>

    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">

            <a href="index.php" class="nav-item nav-link <?php echo navActive('index', $currentPage); ?>">Accueil</a>

            <a href="corps-humain.php" class="nav-item nav-link <?php echo navActive('corps-humain', $currentPage); ?>">Corps humain</a>

            <a href="recettes.php" class="nav-item nav-link <?php echo navActive('recettes', $currentPage); ?>">Recettes</a>

            <a href="medecins.php" class="nav-item nav-link <?php echo navActive('medecins', $currentPage); ?>">Médecins</a>

        </div>
    </div>
</nav>