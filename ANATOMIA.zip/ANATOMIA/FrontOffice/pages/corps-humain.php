<section class="page-banner">
    <div class="container">
        <p class="eyebrow">ANATOMIA</p>
        <h1>Corps humain</h1>
        <p>Explorez les principaux systèmes du corps humain.</p>
    </div>
</section>
<section class="section container">
    <div class="content-panel">
        <h2>Corps humain</h2>
        <p>Cette page accueillera vos fiches, illustrations et contenus pédagogiques sur l’anatomie.</p>
        <p class="muted">Zone de contenu prête à être personnalisée par votre équipe.</p>
    </div>
</section>
