<section class="page-banner">
    <div class="container">
        <p class="eyebrow">ANATOMIA</p>
        <h1>Utilisateurs</h1>
        <p>Espace communauté ANATOMIA.</p>
    </div>
</section>
<section class="section container">
    <div class="content-panel">
        <h2>Utilisateurs</h2>
        <p>Ajoutez ici les fonctionnalités et les informations liées aux utilisateurs.</p>
        <p class="muted">Zone de contenu prête à être personnalisée par votre équipe.</p>
    </div>
</section>
