<section class="page-banner">
    <div class="container">
        <p class="eyebrow">ANATOMIA</p>
        <h1>Services à proximité</h1>
        <p>Localisez les services utiles autour de vous.</p>
    </div>
</section>
<section class="section container">
    <div class="content-panel">
        <h2>Services à proximité</h2>
        <p>Intégrez ici votre carte et les points de service lorsque vos données seront prêtes.</p>
        <p class="muted">Zone de contenu prête à être personnalisée par votre équipe.</p>
    </div>
</section>
