<section class="hero">
    <div class="container hero-content">
        <p class="eyebrow">BIENVENUE SUR ANATOMIA</p>
        <h1>La santé commence par <span>la connaissance.</span></h1>
        <p>Découvrez le corps humain, explorez des conseils de bien-être et trouvez des informations utiles pour prendre soin de vous.</p>
        <a class="button" href="index.php?page=corps-humain">Explorer le corps humain</a>
    </div>
</section>
<section class="section container">
    <div class="section-heading">
        <p class="eyebrow">EXPLOREZ</p>
        <h2>Que souhaitez-vous découvrir ?</h2>
    </div>
    <div class="feature-grid">
        <article class="feature-card"><div class="feature-icon">✦</div><h3>Corps humain</h3><p>Découvrez les systèmes et les organes du corps humain.</p><a href="index.php?page=corps-humain">En savoir plus →</a></article>
        <article class="feature-card"><div class="feature-icon">♡</div><h3>Recettes</h3><p>Des idées de recettes pour une alimentation équilibrée.</p><a href="index.php?page=recettes">Découvrir →</a></article>
        <article class="feature-card"><div class="feature-icon">＋</div><h3>Médecins</h3><p>Retrouvez un espace pour consulter les informations des médecins.</p><a href="index.php?page=medecins">Consulter →</a></article>
    </div>
</section>
