<section class="page-banner">
    <div class="container">
        <p class="eyebrow">ANATOMIA</p>
        <h1>Recettes</h1>
        <p>Manger équilibré au quotidien.</p>
    </div>
</section>
<section class="section container">
    <div class="content-panel">
        <h2>Recettes</h2>
        <p>Ajoutez ici vos recettes, ingrédients, étapes de préparation et informations nutritionnelles.</p>
        <p class="muted">Zone de contenu prête à être personnalisée par votre équipe.</p>
    </div>
</section>
