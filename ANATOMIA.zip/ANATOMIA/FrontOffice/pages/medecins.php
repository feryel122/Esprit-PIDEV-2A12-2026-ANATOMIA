<section class="page-banner">
    <div class="container">
        <p class="eyebrow">ANATOMIA</p>
        <h1>Médecins</h1>
        <p>Un espace dédié aux professionnels de santé.</p>
    </div>
</section>
<section class="section container">
    <div class="content-panel">
        <h2>Médecins</h2>
        <p>Ajoutez ici la liste des médecins, leurs spécialités et leurs coordonnées.</p>
        <p class="muted">Zone de contenu prête à être personnalisée par votre équipe.</p>
    </div>
</section>
