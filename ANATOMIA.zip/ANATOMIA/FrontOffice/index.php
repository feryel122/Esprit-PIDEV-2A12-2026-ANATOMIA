<?php

function getRoutes(): array
{
    return [
        'home' => 'BodyController.php',
        'corps-humain' => 'BodyController.php',
        'recettes' => 'RecipeController.php',
        'medecins' => 'AppointmentController.php',
        'utilisateurs' => 'UserController.php',
        'map-services' => 'MapController.php',
        'tables' => 'TablesController.php',
    ];
}