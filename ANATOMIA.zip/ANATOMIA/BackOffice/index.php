<?php
require_once __DIR__ . '/app/routes.php';
$page = $_GET['page'] ?? 'dashboard';
$routes = getRoutes();
if (!isset($routes[$page])) {
    http_response_code(404);
    $page = 'dashboard';
}
$controllerFile = __DIR__ . '/app/Controllers/' . $routes[$page];
if (!is_file($controllerFile)) {
    http_response_code(500);
    exit('Controller introuvable. Vérifiez app/routes.php.');
}
require_once $controllerFile;
$className = pathinfo($controllerFile, PATHINFO_FILENAME);
$controller = new $className();
$controller->index();
