<?php

class Controller
{
    protected string $title = 'ANATOMIA';
    protected string $page = '';

    protected function capture(string $file, array $data = []): string
    {
        if (!file_exists($file)) {
            throw new RuntimeException("View not found: " . $file);
        }

        extract($data);

        ob_start();
        require $file;

        return ob_get_clean();
    }

    protected function render(
        string $view,
        array $data = [],
        ?string $scriptsView = null
    ): void {
        $content = $this->capture(
            __DIR__ . '/../Views/pages/' . $view . '.php',
            $data
        );

        $extraScripts = $scriptsView
            ? $this->capture(
                __DIR__ . '/../Views/pages/' . $scriptsView . '.php',
                $data
            )
            : '';

        $title = $this->title;
        $currentPage = $this->page;

        require __DIR__ . '/../Views/layout.php';
    }
}