<?php
require_once __DIR__ . '/Controller.php';
class SettingsController extends Controller
{
    public function index(): void
    {
        $this->render('settings', 'Paramètres', 'settings');
    }
}
