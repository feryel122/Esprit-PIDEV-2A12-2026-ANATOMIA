<?php
abstract class Controller
{
    protected function render(string $view, string $title, string $currentPage, array $data = []): void
    {
        $viewFile = __DIR__ . '/../Views/pages/' . $view . '.php';
        if (!is_file($viewFile)) {
            http_response_code(404);
            $content = '<section class="panel"><h2>Page introuvable</h2><p>La vue demandée n’existe pas encore.</p></section>';
        } else {
            extract($data, EXTR_SKIP);
            ob_start();
            require $viewFile;
            $content = ob_get_clean();
        }
        require __DIR__ . '/../Views/layout.php';
    }
}
