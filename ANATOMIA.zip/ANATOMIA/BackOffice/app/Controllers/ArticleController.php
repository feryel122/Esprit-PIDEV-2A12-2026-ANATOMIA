<?php
require_once __DIR__ . '/Controller.php';
class TablesController extends Controller
{
    public function index(): void
    {
        $this->render('tables', 'Tables', 'tables');
    }
}
