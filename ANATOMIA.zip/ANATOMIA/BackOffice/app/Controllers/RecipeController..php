<?php
require_once __DIR__ . '/Controller.php';
class DashboardController extends Controller
{
    public function index(): void
    {
        $this->render('dashboard', 'Tableau de bord', 'dashboard');
    }
}
