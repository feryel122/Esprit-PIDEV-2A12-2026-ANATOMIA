<?php

namespace App\Controllers;

class SettingsController extends Controller
{
    protected string $page = 'settings';
    protected string $title = 'Settings | PlainAdmin Demo';

    public function index(): void
    {
        $this->render('settings');
    }
}