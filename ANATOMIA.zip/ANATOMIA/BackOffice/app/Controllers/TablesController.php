<?php

namespace App\Controllers;

class TablesController extends Controller
{
    protected string $page = 'tables';
    protected string $title = 'Tables | PlainAdmin Demo';

    public function index(): void
    {
        $this->render('tables');
    }
}