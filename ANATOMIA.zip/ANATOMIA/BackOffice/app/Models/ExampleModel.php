<?php
class ExampleModel
{
    // Remplacez ces données de démonstration par une connexion à votre base de données.
    public function getStatistics(): array
    {
        return [
            'users' => 0,
            'doctors' => 0,
            'recipes' => 0,
            'services' => 0,
        ];
    }
}
