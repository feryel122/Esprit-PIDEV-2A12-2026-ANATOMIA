<?php
function getRoutes(): array
{
    return [
        'dashboard' => 'DashboardController.php',
        'tables' => 'TablesController.php',
        'settings' => 'SettingsController.php',
        'users' => 'UsersController.php',
    ];
}
