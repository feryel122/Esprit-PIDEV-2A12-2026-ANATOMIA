
<header class="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 col-md-5 col-6">
                <div class="header-left d-flex align-items-center">
                    <div class="menu-toggle-btn mr-15">
                        <button id="menu-toggle" class="main-btn primary-btn btn-hover">
                            <i class="lni lni-chevron-left me-2"></i> Menu
                        </button>
                    </div>

                    <div class="header-search d-none d-md-flex">
                        <form action="#">
                            <input type="text" placeholder="Search ..." />
                            <button>
                                <i class="lni lni-search-alt"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 col-md-7 col-6">
                <div class="header-right">
                    <!-- notification start -->
                    <div class="notification-box ml-15 d-none d-md-flex">
                        <button
                            class="dropdown-toggle"
                            type="button"
                            id="notification"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        >
                            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M11 20.1667C9.88317 20.1667 8.88718 19.63 8.23901 18.7917H13.761C13.113 19.63 12" fill="" />
                                <path d="M10.1157 2.74999C10.1157 2.24374 10.5117 1.83333 11 1.83333C11.4883 1.83333 11.8" fill="" />
                            </svg>
                            <span></span>
                        </button>

                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notification">
                            <li>
                            </li>
                        </ul>
                    </div>
                    <!-- notification end -->
                </div>
            </div>
        </div>
    </div>
</header>
