
<!-- All Javascript files linkup -->

<script src="app/Views/assets/js/bootstrap.bundle.min.js"></script>
<script src="app/Views/assets/js/Chart.min.js"></script>
<script src="app/Views/assets/js/dynamic-pie-chart.js"></script>
<script src="app/Views/assets/js/moment.min.js"></script>
<script src="app/Views/assets/js/fullcalendar.js"></script>
<script src="app/Views/assets/js/jvectormap.min.js"></script>
<script src="app/Views/assets/js/world-merc.js"></script>
<script src="app/Views/assets/js/polyfill.js"></script>
<script src="app/Views/assets/js/main.js"></script>

<?php if (!empty($extraScripts)): ?>
    <?= $extraScripts ?>
<?php endif; ?>
</body>
</html>
