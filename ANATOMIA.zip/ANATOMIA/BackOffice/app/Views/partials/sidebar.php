
<?php
// $currentPage est fourni par le Controller (voir app/Controllers/Controller.php)
$currentPage = $currentPage ?? 'dashboard';
?>

<aside class="sidebar-nav-wrapper">
    <div class="navbar-logo">
        <a href="index.php?page=dashboard">
            <img src="assets/images/logo/logo.svg" alt="logo" />
        </a>
    </div>

    <nav class="sidebar-nav">
        <ul>
            <li class="nav-item nav-item-has-children">
                <a
                    href="#0"
                    class="<?= isCollapsed(['dashboard'], $currentPage) ?>"
                    data-bs-toggle="collapse"
                    data-bs-target="#ddmenu_1"
                    aria-controls="ddmenu_1"
                    aria-expanded="<?= groupIsExpanded(['dashboard'], $currentPage) ?>"
                    aria-label="Toggle navigation"
                >
                    <span class="icon">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.74999 18.3333C12.2376 18.3333 15.1364 15.8128 15.7244 12.4941C15.8448 11.8143 15.8448 11.8143 15.8448 11.8143" />
                            <path d="M17.0833 10C17.7737 10 18.3432 9.43708 18.2408 8.75433C17.7005 5.14918 14.8508 2.299" />
                        </svg>
                    </span>

                    <span class="text">Dashboard</span>
                </a>

                <ul id="ddmenu_1" class="collapse <?= isOpen(['dashboard'], $currentPage) ?> dropdown-nav">
                    <li>
                        <a href="index.php?page=dashboard" class="<?= isActive('dashboard', $currentPage) ?>">
                            Dashboard
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>
</aside>
