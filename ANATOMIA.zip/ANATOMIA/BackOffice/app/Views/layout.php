
<?php
/**
 * Layout principal - inclut tous les blocs communs et injecte le contenu
 * propre à chaque page ($content).
 *
 * Variables attendues :
 * $title
 * $currentPage
 * $content
 * $extraScripts (optionnel)
 */
?>

<?php require_once __DIR__ . '/partials/head.php'; ?>

<?php require_once __DIR__ . '/partials/sidebar.php'; ?>

<div class="overlay"></div>

<!-- ======== main-wrapper start ======== -->
<main class="main-wrapper">

    <?php require_once __DIR__ . '/partials/header.php'; ?>

    <?= $content ?>

    <?php require_once __DIR__ . '/partials/footer.php'; ?>

</main>
<!-- ======== main-wrapper end ======== -->

<?php require_once __DIR__ . '/partials/scripts.php'; ?>
