<?php
$title = 'Settings';
$currentPage = 'settings';

require_once __DIR__ . '/../partials/head.php';
require_once __DIR__ . '/../partials/sidebar.php';
?>

<main>
    <?php require_once __DIR__ . '/../partials/header.php'; ?>

    <!-- Contenu original de Settings -->

    <?php require_once __DIR__ . '/../partials/footer.php'; ?>
</main>

<?php require_once __DIR__ . '/../partials/scripts.php'; ?>