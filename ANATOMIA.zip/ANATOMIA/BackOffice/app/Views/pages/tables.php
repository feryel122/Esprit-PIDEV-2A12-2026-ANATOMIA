<section class="table-components">
    <div class="container-fluid">
        