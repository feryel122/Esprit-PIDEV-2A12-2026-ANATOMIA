<section class="panel"><h2>Utilisateurs</h2><p>Ajoutez ici les fonctions de consultation, d'ajout, de modification et de suppression des utilisateurs.</p></section>
