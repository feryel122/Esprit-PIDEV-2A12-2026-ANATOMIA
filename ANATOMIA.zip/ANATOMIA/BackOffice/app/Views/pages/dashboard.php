<section class="stats-grid">
    <article class="stat-card"><span>Utilisateurs</span><strong>0</strong><small>À connecter à la base de données</small></article>
    <article class="stat-card"><span>Médecins</span><strong>0</strong><small>À connecter à la base de données</small></article>
    <article class="stat-card"><span>Recettes</span><strong>0</strong><small>À connecter à la base de données</small></article>
    <article class="stat-card"><span>Services</span><strong>0</strong><small>À connecter à la base de données</small></article>
</section>
<section class="panel"><div class="panel-heading"><div><h2>Bienvenue dans votre espace</h2><p>La structure d'administration ANATOMIA est prête.</p></div><span class="status">Projet initialisé</span></div><p>Vous pourrez ajouter ici vos statistiques, graphiques, tableaux et fonctionnalités de gestion.</p></section>
