// Point d'entrée JavaScript du Back-Office.
// Ajoutez ici les interactions de l'administration.
