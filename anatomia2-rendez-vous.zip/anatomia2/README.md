# Anatomia — module « Corps humain » + Rendez-vous (module 07)

PHP MVC suivant l'atelier « Intégration Template » · Front Office **MediLab** · Back Office **AdminLTE 4** · MySQL/MariaDB.

## Lancer
1. Adapter `app/config.php` (MySQL), puis : `php database/install.php` (tables + données de démo).
2. `php -S localhost:8000` à la racine, ouvrir `http://localhost:8000/index.php?page=body`
   (ou copier le dossier dans `htdocs` : `http://localhost/anatomia/index.php?page=body`).

| Rôle | Email | Mot de passe |
|---|---|---|
| Admin | admin@anatomia.tn | admin123 |
| Patient | sana@anatomia.tn | user123 |
| Médecin | amel@anatomia.tn (aussi karim@, leila@, walid@, nour@) | doctor123 |

## Structure (conforme à l'atelier)
```
index.php                      contrôleur frontal  (?page=<clé>)
app/routes.php                 clé de page -> [Controller, méthode]
app/helpers.php                url(), navActive(), flash(), csrf…
app/Controllers/               Controller.php (render + layout), Body, Appointment, Auth, Admin*
app/Models/                    Database, Auth, User, BodyPart, Appointment
app/Views/front/               pages MediLab : chaque page fait require_once includes/*
app/Views/front/includes/      head, spinner, navbar (lien .active via navActive), footer (+ back to top), scripts
app/Views/back/layout.php      assemble les partials et injecte $content (AdminLTE)
app/Views/back/partials/       head, header, sidebar (lien actif via $currentPage), footer, scripts
app/Views/back/pages/          contenu seul des pages back office
app/Views/assets/{front,back}  assets MediLab / AdminLTE
```

## Fonctionnalités
- **Corps humain** : schéma SVG cliquable → fiche (rôle, petits maux, bons réflexes) → médecins des spécialités concernées.
- **Rendez-vous** : réservation chez un médecin (créneau libre, lun–sam 8 h–18 h, pas d'auto-réservation), liste et annulation.
- **Propositions ouvertes** : un utilisateur (médecin compris) propose un rendez-vous sans choisir de médecin (`?page=appointment-propose`, statut `open`, `doctor_id` NULL, `specialty_id` renseigné).
  Les médecins voient les propositions des **autres** utilisateurs dans le back office (`?page=admin-proposals`, sa spécialité par défaut, bouton « Toutes ») et un seul peut l'**accepter** (UPDATE conditionnel -> statut `confirmed`).
- **Médecins = utilisateurs** : `users.role='doctor'` + profil 1-1 dans `doctors`. Le médecin voit ses rendez-vous reçus dans le back office
  (confirmer / annuler / terminer) et peut aussi réserver chez un confrère. L'admin voit tous les rendez-vous et gère les fiches du corps.
- Sécurité : mots de passe hachés, PDO préparé, échappement, CSRF, contrôle des rôles.

## Diagrammes
`docs/usecase.puml`, `docs/class.puml` (PlantUML).
