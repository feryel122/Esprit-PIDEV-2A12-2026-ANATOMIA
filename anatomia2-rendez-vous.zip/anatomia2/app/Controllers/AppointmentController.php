<?php
class AppointmentController extends Controller {

    /** Vérifie la date choisie : renvoie [timestamp|null, erreurs]. */
    private function checkDate(string $raw): array {
        $ts = strtotime($raw); $errors = [];
        if (!$ts || $ts < time() + 3600) $errors[] = 'Choisissez une date future (au moins 1 h à l\'avance).';
        else {
            $h = (int)date('G', $ts);
            if ($h < 8 || $h >= 18 || date('N', $ts) > 6) $errors[] = 'Les consultations ont lieu du lundi au samedi, de 8 h à 18 h.';
        }
        return [$ts ?: null, $errors];
    }

    /** Formulaire de prise de rendez-vous avec un médecin précis. */
    public function create(): void {
        $this->requireLogin();
        $doctor = User::doctor((int)($_GET['doctor'] ?? 0));
        if (!$doctor) { http_response_code(404); exit('Médecin introuvable.'); }
        $part = isset($_GET['part']) ? BodyPart::find((int)$_GET['part']) : null;
        $errors = []; $old = [];
        $this->page = 'appointment-new'; $this->title = 'Prendre rendez-vous';
        $this->render('front/appointment/create', compact('doctor', 'part', 'errors', 'old'));
    }
    public function store(): void {
        $me = $this->requireLogin();
        if (!$this->isPost()) $this->redirect('body');
        $this->checkCsrf();
        $doctor = User::doctor((int)($_POST['doctor_id'] ?? 0));
        if (!$doctor) { http_response_code(404); exit('Médecin introuvable.'); }
        $partId = (int)($_POST['body_part_id'] ?? 0) ?: null;
        $part   = $partId ? BodyPart::find($partId) : null;
        $reason = trim($_POST['reason'] ?? '');
        [$ts, $errors] = $this->checkDate($_POST['scheduled_at'] ?? '');

        if ((int)$doctor['id'] === (int)$me['id']) $errors[] = 'Vous ne pouvez pas prendre rendez-vous avec vous-même.';
        if ($reason === '') $errors[] = 'Indiquez le motif de la consultation.';
        $dt = $ts ? date('Y-m-d H:i:00', $ts) : '';
        if (!$errors && !Appointment::isFree((int)$doctor['id'], $dt)) $errors[] = 'Ce créneau est déjà pris, choisissez une autre heure.';

        if ($errors) {
            $old = $_POST;
            $this->page = 'appointment-new'; $this->title = 'Prendre rendez-vous';
            $this->render('front/appointment/create', compact('doctor', 'part', 'errors', 'old'));
            return;
        }
        Appointment::create((int)$me['id'], (int)$doctor['id'], $part['id'] ?? null, $dt, str_limit($reason, 255));
        flash('Demande envoyée à ' . $doctor['name'] . '. Vous serez prévenu(e) dès qu\'elle est confirmée.');
        $this->redirect('appointment-mine');
    }

    /** Proposer un rendez-vous SANS choisir de médecin : tous les médecins de la spécialité le voient. */
    public function propose(): void {
        $this->requireLogin();
        $specialties = Specialty::all();
        $part = isset($_GET['part']) ? BodyPart::find((int)$_GET['part']) : null;
        $errors = []; $old = [];
        $this->page = 'appointment-propose'; $this->title = 'Proposer un rendez-vous';
        $this->render('front/appointment/propose', compact('specialties', 'part', 'errors', 'old'));
    }
    public function storeProposal(): void {
        $me = $this->requireLogin();
        if (!$this->isPost()) $this->redirect('appointment-propose');
        $this->checkCsrf();
        $specialties = Specialty::all();
        $spec   = Specialty::find((int)($_POST['specialty_id'] ?? 0));
        $partId = (int)($_POST['body_part_id'] ?? 0) ?: null;
        $part   = $partId ? BodyPart::find($partId) : null;
        $reason = trim($_POST['reason'] ?? '');
        [$ts, $errors] = $this->checkDate($_POST['scheduled_at'] ?? '');
        if (!$spec) $errors[] = 'Choisissez une spécialité.';
        if ($reason === '') $errors[] = 'Indiquez le motif de la consultation.';

        if ($errors) {
            $old = $_POST;
            $this->page = 'appointment-propose'; $this->title = 'Proposer un rendez-vous';
            $this->render('front/appointment/propose', compact('specialties', 'part', 'errors', 'old'));
            return;
        }
        Appointment::createOpen((int)$me['id'], (int)$spec['id'], $part['id'] ?? null, date('Y-m-d H:i:00', $ts), str_limit($reason, 255));
        flash('Proposition publiée : les médecins en ' . $spec['name'] . ' peuvent maintenant la voir et l\'accepter.');
        $this->redirect('appointment-mine');
    }

    public function mine(): void {
        $me = $this->requireLogin();
        $appointments = Appointment::forPatient((int)$me['id']);
        $this->page = 'appointment-mine'; $this->title = 'Mes rendez-vous';
        $this->render('front/appointment/mine', compact('appointments'));
    }
    public function cancel(): void {
        $me = $this->requireLogin();
        $this->checkCsrf();
        $a = Appointment::find((int)($_POST['id'] ?? 0));
        if ($a && (int)$a['patient_id'] === (int)$me['id'] && in_array($a['status'], ['open', 'pending', 'confirmed'], true)) {
            Appointment::setStatus((int)$a['id'], 'cancelled');
            flash('Rendez-vous annulé.');
        }
        $this->redirect('appointment-mine');
    }
}
