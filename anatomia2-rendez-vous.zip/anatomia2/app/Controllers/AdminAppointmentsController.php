<?php
class AdminAppointmentsController extends Controller {
    /** Le médecin voit SES rendez-vous ; l'admin voit tous les rendez-vous du site. */
    public function index(): void {
        $me = $this->requireRole('doctor', 'admin');
        $status = $_GET['status'] ?? null;
        if (!in_array($status, ['open', 'pending', 'confirmed', 'cancelled', 'done'], true)) $status = null;
        $appointments = $me['role'] === 'doctor' ? Appointment::forDoctor((int)$me['id'], $status) : Appointment::all($status);
        $this->page = 'admin-appointments'; $this->title = $me['role'] === 'admin' ? 'Tous les rendez-vous du site' : 'Mes rendez-vous (patients)';
        $this->render('appointments/index', compact('appointments', 'status'), 'back');
    }
    public function status(): void {
        $me = $this->requireRole('doctor', 'admin');
        $this->checkCsrf();
        $a = Appointment::find((int)($_POST['id'] ?? 0));
        $new = $_POST['status'] ?? '';
        $allowed = ['confirmed', 'cancelled', 'done'];
        if ($a && $a['status'] !== 'open' && in_array($new, $allowed, true)
            && ($me['role'] === 'admin' || (int)$a['doctor_id'] === (int)$me['id'])) {
            Appointment::setStatus((int)$a['id'], $new);
            flash('Rendez-vous mis à jour.');
        }
        $this->redirect('admin-appointments');
    }

    /** Propositions ouvertes des autres utilisateurs : visibles par les médecins (et l'admin, en lecture). */
    public function proposals(): void {
        $me = $this->requireRole('doctor', 'admin');
        $doctor = $me['role'] === 'doctor' ? User::doctor((int)$me['id']) : null;
        $specialtyId = $doctor ? (int)$doctor['specialty_id'] : null;
        $scope = ($_GET['scope'] ?? 'mine') === 'all' || !$doctor ? 'all' : 'mine';
        $proposals = Appointment::openProposals((int)$me['id'], $scope === 'mine' ? $specialtyId : null);
        $this->page = 'admin-proposals'; $this->title = 'Propositions des utilisateurs';
        $this->render('appointments/proposals', compact('proposals', 'scope', 'doctor', 'specialtyId'), 'back');
    }
    public function claim(): void {
        $me = $this->requireRole('doctor');
        $this->checkCsrf();
        $doctor = User::doctor((int)$me['id']);
        $a = Appointment::find((int)($_POST['id'] ?? 0));
        if (!$a || $a['status'] !== 'open' || $a['doctor_id'] !== null) {
            flash('Cette proposition n\'est plus disponible.', 'warning');
        } elseif ((int)$a['patient_id'] === (int)$me['id']) {
            flash('Vous ne pouvez pas accepter votre propre proposition.', 'warning');
        } elseif ((int)$a['specialty_id'] !== (int)$doctor['specialty_id']) {
            flash('Cette proposition concerne une autre spécialité.', 'warning');
        } elseif (!Appointment::isFree((int)$me['id'], $a['scheduled_at'])) {
            flash('Vous avez déjà un rendez-vous à cette heure-là.', 'warning');
        } else {
            try {
                if (Appointment::claim((int)$a['id'], (int)$me['id'])) flash('Rendez-vous accepté : ' . $a['patient_name'] . ' est prévenu(e).');
                else flash('Un autre médecin vient de prendre cette proposition.', 'warning');
            } catch (PDOException $e) {
                flash('Ce créneau est déjà occupé dans votre agenda.', 'warning');
            }
        }
        $this->redirect('admin-proposals', ($_POST['scope'] ?? '') === 'all' ? ['scope' => 'all'] : []);
    }
}
