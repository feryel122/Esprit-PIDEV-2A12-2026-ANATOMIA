<?php
// $currentPage est fourni par le Controller (propriété $page)
$currentPage = $currentPage ?? 'admin-dashboard';
?>
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
  <div class="sidebar-brand">
    <a href="<?= url('admin-dashboard') ?>" class="brand-link">
      <img src="<?= back_asset('img/AdminLTELogo.png') ?>" alt="Logo" class="brand-image opacity-75 shadow">
      <span class="brand-text fw-light">Anatomia</span>
    </a>
  </div>
  <div class="sidebar-wrapper">
    <nav class="mt-2" aria-label="Navigation principale">
      <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false" id="navigation">
        <li class="nav-item"><a href="<?= url('admin-dashboard') ?>" class="nav-link <?= navActive('admin-dashboard', $currentPage) ?>">
          <i class="nav-icon bi bi-speedometer2"></i><p>Tableau de bord</p></a></li>
        <li class="nav-item"><a href="<?= url('admin-appointments') ?>" class="nav-link <?= navActive('admin-appointments', $currentPage) ?>">
          <i class="nav-icon bi bi-calendar-check"></i><p><?= $user['role'] === 'admin' ? 'Tous les rendez-vous' : 'Mes rendez-vous' ?></p></a></li>
        <li class="nav-item"><a href="<?= url('admin-proposals') ?>" class="nav-link <?= navActive('admin-proposals', $currentPage) ?>">
          <i class="nav-icon bi bi-inbox"></i><p>Propositions<?php if (!empty($openProposals)): ?> <span class="nav-badge badge text-bg-info me-3"><?= (int)$openProposals ?></span><?php endif; ?></p></a></li>
        <?php if ($user['role'] === 'admin'): ?>
        <li class="nav-header">CORPS HUMAIN</li>
        <li class="nav-item"><a href="<?= url('admin-body') ?>" class="nav-link <?= navActive('admin-body', $currentPage, true) ?>">
          <i class="nav-icon bi bi-person-standing"></i><p>Parties du corps</p></a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</aside>
