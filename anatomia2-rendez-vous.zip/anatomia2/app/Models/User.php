<?php
class User {
    public static function find(int $id): ?array {
        return Database::one('SELECT id,name,email,phone,role FROM users WHERE id=?', [$id]);
    }
    public static function findByEmail(string $email): ?array {
        return Database::one('SELECT * FROM users WHERE email=?', [$email]);
    }
    public static function create(string $name, string $email, string $pass, ?string $phone): int {
        return Database::insert('INSERT INTO users(name,email,password,phone,role) VALUES(?,?,?,?,?)',
            [$name, $email, password_hash($pass, PASSWORD_DEFAULT), $phone ?: null, 'user']);
    }
    /** Médecins (= utilisateurs role doctor) pouvant traiter une partie du corps. */
    public static function doctorsForBodyPart(int $bodyPartId): array {
        return Database::all(
            'SELECT u.id, u.name, d.city, d.bio, d.photo, s.name AS specialty
               FROM doctors d JOIN users u ON u.id=d.user_id JOIN specialties s ON s.id=d.specialty_id
              WHERE d.specialty_id IN (SELECT specialty_id FROM body_part_specialty WHERE body_part_id=?)
              ORDER BY s.name, u.name', [$bodyPartId]);
    }
    public static function doctor(int $userId): ?array {
        return Database::one('SELECT u.id,u.name,d.city,d.bio,d.photo,d.specialty_id,s.name AS specialty
            FROM doctors d JOIN users u ON u.id=d.user_id JOIN specialties s ON s.id=d.specialty_id WHERE u.id=?', [$userId]);
    }
}
