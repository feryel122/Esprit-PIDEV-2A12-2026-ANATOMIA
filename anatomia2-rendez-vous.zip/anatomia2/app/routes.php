<?php
// clé de page => [Controller, méthode]
return [
    // Front office (MediLab)
    'body'              => ['BodyController', 'index'],
    'body-show'         => ['BodyController', 'show'],
    'appointment-new'   => ['AppointmentController', 'create'],
    'appointment-store' => ['AppointmentController', 'store'],
    'appointment-propose'       => ['AppointmentController', 'propose'],
    'appointment-propose-store' => ['AppointmentController', 'storeProposal'],
    'appointment-mine'  => ['AppointmentController', 'mine'],
    'appointment-cancel'=> ['AppointmentController', 'cancel'],
    'login'             => ['AuthController', 'login'],
    'register'          => ['AuthController', 'register'],
    'logout'            => ['AuthController', 'logout'],

    // Back office (AdminLTE) — médecin & admin
    'admin-dashboard'          => ['AdminDashboardController', 'index'],
    'admin-appointments'       => ['AdminAppointmentsController', 'index'],
    'admin-appointments-status'=> ['AdminAppointmentsController', 'status'],
    'admin-proposals'          => ['AdminAppointmentsController', 'proposals'],
    'admin-proposals-claim'    => ['AdminAppointmentsController', 'claim'],
    // Back office — admin uniquement
    'admin-body'        => ['AdminBodyController', 'index'],
    'admin-body-create' => ['AdminBodyController', 'create'],
    'admin-body-edit'   => ['AdminBodyController', 'edit'],
    'admin-body-save'   => ['AdminBodyController', 'save'],
    'admin-body-delete' => ['AdminBodyController', 'delete'],
];
