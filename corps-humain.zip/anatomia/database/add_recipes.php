<?php
// Usage : php database/add_recipes.php
// Pour une base DÉJÀ installée : ajoute la table `recipes` et les recettes de démo
// sans toucher aux autres données (contrairement à install.php qui réinitialise tout).
require __DIR__ . '/../app/core/Database.php';
$db = Database::pdo();

$db->exec("CREATE TABLE IF NOT EXISTS recipes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  body_part_id INT NOT NULL,
  title VARCHAR(150) NOT NULL,
  benefit VARCHAR(255) NOT NULL,
  prep_minutes SMALLINT NOT NULL DEFAULT 15,
  servings TINYINT NOT NULL DEFAULT 2,
  icon VARCHAR(40) NOT NULL DEFAULT 'bi-cup-hot',
  ingredients TEXT NOT NULL,
  steps TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (body_part_id) REFERENCES body_parts(id) ON DELETE CASCADE
) ENGINE=InnoDB");

if ((int)Database::one('SELECT COUNT(*) AS n FROM recipes')['n'] > 0) {
    exit("La table recipes contient déjà des recettes : rien à faire.\n");
}
require __DIR__ . '/seed_recipes.inc.php';
