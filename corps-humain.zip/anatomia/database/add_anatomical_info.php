<?php
// Usage : php database/add_anatomical_info.php
// Ajoute la table anatomical_info et sa contrainte sur une base DÉJÀ installée, sans rien effacer.
require __DIR__ . '/../app/core/Database.php';
$db = Database::pdo();
$db->exec("CREATE TABLE IF NOT EXISTS anatomical_info (
  id INT AUTO_INCREMENT PRIMARY KEY,
  body_part_id INT NOT NULL,
  category ENUM('organe','os','muscle','articulation','autre') NOT NULL DEFAULT 'organe',
  name VARCHAR(100) NOT NULL,
  details VARCHAR(255) NOT NULL,
  FOREIGN KEY (body_part_id) REFERENCES body_parts(id) ON DELETE CASCADE
) ENGINE=InnoDB");
if (!Database::one('SELECT id FROM anatomical_info LIMIT 1')) {
    foreach (require __DIR__ . '/seed_anatomy.inc.php' as $slug => $rows) {
        $part = Database::one('SELECT id FROM body_parts WHERE slug=?', [$slug]);
        if (!$part) continue;
        foreach ($rows as [$c, $n, $d]) Database::run('INSERT INTO anatomical_info(body_part_id,category,name,details) VALUES(?,?,?,?)', [$part['id'], $c, $n, $d]);
    }
}
try { $db->exec("ALTER TABLE body_parts ADD CONSTRAINT chk_body_part_description CHECK (CHAR_LENGTH(TRIM(description)) >= 20)"); } catch (Throwable $e) { /* déjà présente ou non supportée */ }
echo "Table anatomical_info prête.\n";
