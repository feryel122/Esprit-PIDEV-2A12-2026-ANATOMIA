<?php
// Informations anatomiques par zone : slug => [[catégorie, nom, détails], ...]
return [
 'tete' => [
  ['organe','Cerveau',"Centre de commande du système nerveux : pensée, mémoire, mouvements et sens."],
  ['os','Crâne',"Boîte osseuse de 22 os qui protège le cerveau."],
  ['organe','Yeux',"Organes de la vision, protégés par les orbites."],
  ['organe','Oreilles',"Organes de l'audition et de l'équilibre."],
 ],
 'cou' => [
  ['os','Vertèbres cervicales',"Sept vertèbres qui soutiennent la tête et protègent la moelle épinière."],
  ['organe','Thyroïde',"Glande qui régule le métabolisme grâce à ses hormones."],
  ['organe','Larynx',"Siège des cordes vocales, il permet la voix et protège les voies respiratoires."],
 ],
 'thorax' => [
  ['organe','Cœur',"Muscle creux qui pompe le sang dans tout le corps."],
  ['organe','Poumons',"Organes des échanges gazeux : ils apportent l'oxygène et rejettent le CO2."],
  ['os','Cage thoracique',"Douze paires de côtes et le sternum protègent le cœur et les poumons."],
  ['muscle','Diaphragme',"Muscle principal de la respiration."],
 ],
 'abdomen' => [
  ['organe','Estomac',"Poche musculaire où commence la digestion des aliments."],
  ['organe','Foie',"Plus grosse glande du corps : filtre le sang et produit la bile."],
  ['organe','Intestins',"Intestin grêle et gros intestin : absorption des nutriments et de l'eau."],
  ['organe','Pancréas',"Produit les enzymes digestives et l'insuline."],
 ],
 'bras' => [
  ['os','Humérus',"Os du bras, entre l'épaule et le coude."],
  ['articulation','Épaule',"Articulation la plus mobile du corps."],
  ['articulation','Coude',"Articulation qui permet de plier et tendre le bras."],
  ['muscle','Biceps et triceps',"Muscles qui plient et étendent l'avant-bras."],
 ],
 'mains' => [
  ['os','Os de la main',"27 os par main : carpe, métacarpe et phalanges."],
  ['articulation','Poignet',"Articulation qui relie la main à l'avant-bras."],
  ['autre','Tendons fléchisseurs',"Cordons fibreux qui transmettent la force des muscles aux doigts."],
 ],
 'jambes' => [
  ['os','Fémur',"Plus long et plus solide os du corps."],
  ['articulation','Genou',"Articulation charnière stabilisée par quatre ligaments principaux."],
  ['muscle','Quadriceps',"Gros muscle de la cuisse qui étend le genou."],
  ['muscle','Mollet',"Muscles (triceps sural) qui permettent la marche et la course."],
 ],
 'pieds' => [
  ['os','Os du pied',"26 os par pied : tarse, métatarse et phalanges."],
  ['autre','Voûte plantaire',"Arche qui amortit les chocs et répartit le poids du corps."],
  ['articulation','Cheville',"Articulation entre la jambe et le pied, essentielle à l'équilibre."],
 ],
];
