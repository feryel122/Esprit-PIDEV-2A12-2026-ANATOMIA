<?php
// Insère les recettes de recipes_seed.php (les parties du corps doivent déjà exister).
$__ids = array_column(Database::all('SELECT id, slug FROM body_parts'), 'id', 'slug');
$__n = 0;
foreach ((require __DIR__ . '/recipes_seed.php') as $__slug => $__list) {
    if (!isset($__ids[$__slug])) continue;
    foreach ($__list as [$__title, $__benefit, $__min, $__serv, $__icon, $__ing, $__steps]) {
        Database::insert(
            'INSERT INTO recipes(body_part_id,title,benefit,prep_minutes,servings,icon,ingredients,steps) VALUES(?,?,?,?,?,?,?,?)',
            [$__ids[$__slug], $__title, $__benefit, $__min, $__serv, $__icon, implode("\n", $__ing), implode("\n", $__steps)]
        );
        $__n++;
    }
}
echo "$__n recettes ajoutées.\n";
