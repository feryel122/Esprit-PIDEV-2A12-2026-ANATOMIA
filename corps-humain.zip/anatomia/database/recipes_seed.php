<?php
// Recettes de démo : slug de la partie du corps => liste de recettes.
// [titre, bénéfice, minutes, portions, icône bootstrap-icons, ingrédients[], étapes[]]
return [
 'tete' => [
  ['Smoothie vert banane-épinards', "Riche en magnésium et en potassium, un allié des journées chargées et des maux de tête de fatigue.", 5, 1, 'bi-cup-straw',
   ['1 banane mûre', '1 poignée de jeunes pousses d\'épinards', '1 c. à soupe d\'amandes', '250 ml de lait ou de boisson végétale', '1 c. à café de miel (facultatif)'],
   ['Rincer les épinards.', 'Mettre tous les ingrédients dans un blender.', 'Mixer 1 minute jusqu\'à obtenir une texture lisse.', 'Boire frais, de préférence au petit-déjeuner.']],
  ['Salade de sardines, noix et citron', "Source d'oméga-3, ces bonnes graisses contribuent au fonctionnement normal du cerveau.", 10, 2, 'bi-egg-fried',
   ['1 boîte de sardines à l\'huile d\'olive', '2 poignées de salade verte', '6 noix décortiquées', '1 citron', '1 c. à soupe d\'huile d\'olive'],
   ['Égoutter les sardines et les émietter grossièrement.', 'Disposer la salade dans un saladier et ajouter les noix.', 'Ajouter les sardines, le jus de citron et l\'huile d\'olive.', 'Mélanger délicatement et servir aussitôt.']],
 ],
 'cou' => [
  ['Lait d\'or au curcuma', "Une boisson chaude réconfortante, appréciée pour apaiser les tensions et la gorge.", 10, 1, 'bi-cup-hot',
   ['250 ml de lait ou de boisson végétale', '1/2 c. à café de curcuma', '1 pincée de poivre noir', '1/2 c. à café de cannelle', '1 c. à café de miel'],
   ['Chauffer le lait à feu doux sans le faire bouillir.', 'Ajouter le curcuma, le poivre et la cannelle en fouettant.', 'Laisser infuser 3 minutes.', 'Verser dans une tasse et sucrer au miel.']],
  ['Infusion thym, citron et miel', "Le thym et le miel sont traditionnellement utilisés pour adoucir les gorges irritées.", 10, 2, 'bi-flower2',
   ['1 petit bouquet de thym frais', '500 ml d\'eau', '1/2 citron', '2 c. à café de miel'],
   ['Porter l\'eau à ébullition.', 'Verser sur le thym et laisser infuser 8 minutes.', 'Filtrer, ajouter le jus de citron.', 'Ajouter le miel quand l\'infusion a un peu tiédi.']],
 ],
 'thorax' => [
  ['Soupe de lentilles au cumin', "Riche en fibres et en protéines végétales, elle s'intègre bien à une alimentation favorable au cœur.", 35, 4, 'bi-heart-pulse',
   ['200 g de lentilles', '1 oignon', '2 carottes', '2 gousses d\'ail', '1 c. à café de cumin', '1 c. à soupe d\'huile d\'olive', '1 litre d\'eau'],
   ['Faire revenir l\'oignon et l\'ail dans l\'huile d\'olive.', 'Ajouter les carottes en rondelles et les lentilles rincées.', 'Verser l\'eau, ajouter le cumin et cuire 25 minutes.', 'Mixer en partie selon la texture souhaitée.']],
  ['Porridge pomme-cannelle', "L'avoine contient des fibres (bêta-glucanes) qui participent au maintien d'un cholestérol normal.", 10, 1, 'bi-apple',
   ['40 g de flocons d\'avoine', '200 ml de lait ou d\'eau', '1 pomme', '1/2 c. à café de cannelle', '1 c. à café de graines de lin'],
   ['Chauffer le lait avec les flocons 5 minutes en remuant.', 'Râper la pomme et l\'ajouter à mi-cuisson.', 'Verser dans un bol.', 'Saupoudrer de cannelle et de graines de lin.']],
 ],
 'abdomen' => [
  ['Infusion fenouil et menthe', "Traditionnellement consommée après le repas pour aider à réduire les ballonnements.", 10, 2, 'bi-cup-hot',
   ['1 c. à café de graines de fenouil', '1 petite poignée de menthe fraîche', '400 ml d\'eau chaude'],
   ['Écraser légèrement les graines de fenouil.', 'Les placer avec la menthe dans une théière.', 'Verser l\'eau chaude et laisser infuser 7 minutes.', 'Filtrer et boire tiède après le repas.']],
  ['Soupe douce carottes et riz', "Une recette simple et douce pour l'estomac, idéale lors d'une digestion difficile.", 30, 3, 'bi-basket2',
   ['4 carottes', '3 c. à soupe de riz', '1 litre d\'eau', '1 c. à café d\'huile d\'olive', '1 pincée de sel'],
   ['Éplucher et couper les carottes.', 'Cuire carottes et riz dans l\'eau salée 25 minutes.', 'Mixer jusqu\'à obtenir un velouté.', 'Ajouter un filet d\'huile d\'olive et servir tiède.']],
 ],
 'bras' => [
  ['Bol de saumon, quinoa et brocoli', "Protéines et oméga-3 pour soutenir les muscles et la récupération après l'effort.", 25, 2, 'bi-egg-fried',
   ['2 pavés de saumon', '150 g de quinoa', '1 brocoli', '1 citron', '1 c. à soupe d\'huile d\'olive'],
   ['Cuire le quinoa 12 minutes dans l\'eau bouillante.', 'Cuire le brocoli à la vapeur 8 minutes.', 'Cuire le saumon à la poêle 4 minutes de chaque côté.', 'Assembler dans un bol et arroser de citron.']],
  ['Smoothie cerise-yaourt', "Les cerises sont riches en antioxydants, appréciées après une séance de sport.", 5, 1, 'bi-cup-straw',
   ['1 poignée de cerises dénoyautées', '1 yaourt nature', '100 ml de lait', '1 c. à café de miel'],
   ['Mettre tous les ingrédients dans un blender.', 'Mixer 1 minute.', 'Servir bien frais.']],
 ],
 'mains' => [
  ['Salade orange, carotte et amandes', "La vitamine C participe à la formation du collagène, utile à la peau et aux articulations.", 10, 2, 'bi-apple',
   ['2 oranges', '2 carottes râpées', '1 poignée d\'amandes', '1 c. à soupe d\'huile d\'olive', '1 pincée de cannelle'],
   ['Peler les oranges à vif et les couper en rondelles.', 'Râper les carottes.', 'Mélanger avec les amandes concassées.', 'Assaisonner d\'huile d\'olive et de cannelle.']],
  ['Houmous maison', "Pois chiches riches en protéines et en zinc, avec des crudités à croquer.", 10, 4, 'bi-basket2',
   ['400 g de pois chiches cuits', '2 c. à soupe de tahini', '1 citron', '1 gousse d\'ail', '3 c. à soupe d\'huile d\'olive', '1/2 c. à café de cumin'],
   ['Égoutter les pois chiches en gardant un peu de jus.', 'Mixer avec le tahini, le citron, l\'ail et le cumin.', 'Ajouter l\'huile d\'olive et un peu de jus pour lisser.', 'Servir avec des bâtonnets de carotte ou de concombre.']],
 ],
 'jambes' => [
  ['Salade betterave, orange et noix', "La betterave est riche en nitrates naturels, un bon réflexe pour une alimentation favorable à la circulation.", 15, 2, 'bi-flower2',
   ['2 betteraves cuites', '1 orange', '6 noix', '1 c. à soupe d\'huile d\'olive', '1 c. à café de vinaigre de cidre'],
   ['Couper les betteraves en dés.', 'Peler l\'orange et la couper en quartiers.', 'Mélanger avec les noix.', 'Assaisonner avec l\'huile et le vinaigre.']],
  ['Smoothie dattes et banane', "Potassium et magnésium : un en-cas apprécié pour limiter les crampes après l'effort.", 5, 1, 'bi-cup-straw',
   ['1 banane', '3 dattes dénoyautées', '250 ml de lait', '1 c. à café de graines de chia'],
   ['Mettre tous les ingrédients dans un blender.', 'Mixer 1 minute.', 'Laisser reposer 2 minutes pour que le chia gonfle, puis boire.']],
 ],
 'pieds' => [
  ['Omelette aux épinards et fromage', "Œufs et fromage apportent protéines, calcium et vitamine D, utiles à des os solides.", 10, 1, 'bi-egg-fried',
   ['2 œufs', '1 poignée d\'épinards', '30 g de fromage râpé', '1 c. à café d\'huile d\'olive', 'Sel et poivre'],
   ['Faire tomber les épinards 2 minutes à la poêle.', 'Battre les œufs, saler, poivrer et verser sur les épinards.', 'Ajouter le fromage et cuire 3 minutes.', 'Replier et servir chaud.']],
  ['Bol yaourt, kiwi et graines de chia', "Vitamine C et calcium : un petit-déjeuner simple pour les os et les tissus.", 5, 1, 'bi-apple',
   ['1 yaourt nature', '1 kiwi', '1 c. à café de graines de chia', '1 c. à café de miel'],
   ['Verser le yaourt dans un bol.', 'Ajouter le kiwi en dés et les graines de chia.', 'Terminer avec un filet de miel.']],
 ],
];
