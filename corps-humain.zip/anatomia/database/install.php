<?php
// Usage : php database/install.php   (crée la base si besoin, les tables et des données de démo)
$cfg = (require __DIR__ . '/../app/config.php')['db'];
$dsn = $cfg['dsn'];
if (str_starts_with($dsn, 'mysql:') && preg_match('/dbname=([\w]+)/', $dsn, $m)) {
    $root = new PDO(preg_replace('/;?dbname=[\w]+/', '', $dsn), $cfg['user'], $cfg['pass']);
    $root->exec("CREATE DATABASE IF NOT EXISTS `{$m[1]}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
}
require __DIR__ . '/../app/core/Database.php';
$db = Database::pdo();
foreach (array_filter(array_map('trim', explode(';', file_get_contents(__DIR__ . '/schema.sql')))) as $sql) $db->exec($sql);

$pw = fn($p) => password_hash($p, PASSWORD_DEFAULT);
$ins = fn($sql, $p) => Database::insert($sql, $p);

// Spécialités
$spec = [];
foreach (['Médecine générale','Neurologie','Cardiologie','Pneumologie','Gastro-entérologie','ORL','Orthopédie','Dermatologie','Podologie','Ophtalmologie'] as $s)
    $spec[$s] = $ins('INSERT INTO specialties(name) VALUES(?)', [$s]);

// Utilisateurs : admin, 2 patients, 5 médecins (les médecins sont des utilisateurs)
$ins('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)', ['Admin Anatomia','admin@anatomia.tn',$pw('admin123'),'admin']);
$ins('INSERT INTO users(name,email,password,phone,role) VALUES(?,?,?,?,?)', ['Sana Ben Ali','sana@anatomia.tn',$pw('user123'),'20111222','user']);
$ins('INSERT INTO users(name,email,password,phone,role) VALUES(?,?,?,?,?)', ['Omar Trabelsi','omar@anatomia.tn',$pw('user123'),'20333444','user']);
$docs = [
  ['Dr Amel Gharbi','amel@anatomia.tn','Neurologie','Tunis','Neurologue, migraines et troubles du sommeil.'],
  ['Dr Karim Mansour','karim@anatomia.tn','Cardiologie','Tunis','Cardiologue, prévention cardiovasculaire.'],
  ['Dr Leila Jaziri','leila@anatomia.tn','Gastro-entérologie','Ariana','Digestion, reflux, intestin irritable.'],
  ['Dr Walid Chaouch','walid@anatomia.tn','Orthopédie','Sousse','Douleurs articulaires et sport.'],
  ['Dr Nour Haddad','nour@anatomia.tn','Médecine générale','Tunis','Médecin généraliste, suivi de famille.'],
];
$i = 1;
foreach ($docs as [$n,$e,$s,$c,$b]) {
    $id = $ins('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)', [$n,$e,$pw('doctor123'),'doctor']);
    $ins('INSERT INTO doctors(user_id,specialty_id,city,bio,photo) VALUES(?,?,?,?,?)', [$id,$spec[$s],$c,$b,'doctors/doctors-'.(($i++-1)%4+1).'.jpg']);
}

// Parties du corps (slug = zone cliquable du SVG)
$parts = [
 ['tete','Tête','Cerveau, yeux, oreilles, bouche : le centre de commande.',"La tête abrite le cerveau, qui coordonne tout le corps, ainsi que les organes des sens (vue, ouïe, odorat, goût).","Maux de tête et migraines, fatigue visuelle, sinusite, otites.","Dormir 7 à 8 h, s'hydrater, faire des pauses d'écran toutes les 20 minutes.",['Neurologie','ORL','Ophtalmologie','Médecine générale']],
 ['cou','Cou et gorge','Vertèbres cervicales, thyroïde, gorge.',"Le cou relie la tête au tronc. Il protège la moelle épinière et contient la gorge, le larynx et la thyroïde.","Torticolis, angine, maux de gorge, tensions cervicales.","Soigner sa posture devant l'écran, éviter les courants d'air, s'étirer régulièrement.",['ORL','Orthopédie','Médecine générale']],
 ['thorax','Thorax','Cœur et poumons.',"Le thorax protège le cœur, qui pompe le sang, et les poumons, qui apportent l'oxygène au corps.","Toux, essoufflement, palpitations, douleurs thoraciques, asthme.","Activité physique régulière, ne pas fumer, contrôle de la tension.",['Cardiologie','Pneumologie','Médecine générale']],
 ['abdomen','Abdomen','Estomac, foie, intestins.',"L'abdomen contient la plupart des organes de la digestion : estomac, foie, intestins, pancréas.","Reflux, ballonnements, constipation, maux de ventre, nausées.","Repas équilibrés et réguliers, fibres, eau, limiter les aliments gras et épicés.",['Gastro-entérologie','Médecine générale']],
 ['bras','Bras','Épaules, coudes, muscles.',"Les bras permettent de porter, pousser et tirer grâce à l'épaule, au coude et à de nombreux muscles.","Tendinites, douleurs d'épaule, crampes, fourmillements.","S'échauffer avant le sport, varier les gestes répétitifs, renforcement musculaire doux.",['Orthopédie','Médecine générale']],
 ['mains','Mains et poignets','Précision, toucher, articulations fines.',"Les mains comptent 27 os chacune et assurent la préhension et le toucher.","Syndrome du canal carpien, arthrose, engelures, eczéma.","Faire des pauses lors du travail sur clavier, bien se laver et hydrater les mains.",['Orthopédie','Dermatologie']],
 ['jambes','Jambes','Hanches, genoux, cuisses, mollets.',"Les jambes supportent le poids du corps et permettent la marche, la course et le saut.","Douleurs de genou, jambes lourdes, crampes, entorses.","Marcher 30 minutes par jour, chaussures adaptées, étirements après l'effort.",['Orthopédie','Médecine générale']],
 ['pieds','Pieds','Voûte plantaire, chevilles, orteils.',"Les pieds absorbent les chocs et assurent l'équilibre grâce à 26 os et un réseau de ligaments.","Fasciite plantaire, ampoules, ongles incarnés, pieds plats, mycoses.","Chaussures bien ajustées, séchage soigneux, hygiène quotidienne.",['Podologie','Orthopédie','Dermatologie']],
];
foreach ($parts as [$slug,$name,$sum,$desc,$issues,$prev,$sp]) {
    $id = $ins('INSERT INTO body_parts(slug,name,summary,description,common_issues,prevention) VALUES(?,?,?,?,?,?)', [$slug,$name,$sum,$desc,$issues,$prev]);
    foreach ($sp as $s) if (isset($spec[$s])) Database::run('INSERT INTO body_part_specialty VALUES(?,?)', [$id,$spec[$s]]);
}
// Un rendez-vous de démo : Sana -> Dr Amel (neurologie)
Database::run("INSERT INTO appointments(patient_id,doctor_id,body_part_id,scheduled_at,reason,status) VALUES(2,4,1,DATE_ADD(CURDATE(), INTERVAL 3 DAY) + INTERVAL 10 HOUR,'Migraines fréquentes','pending')");
echo "Base installée.\nComptes : admin@anatomia.tn/admin123 — sana@anatomia.tn/user123 — amel@anatomia.tn/doctor123\n";
