-- Anatomia — module Corps humain + Rendez-vous (MySQL / MariaDB)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS anatomical_info, recipes, appointments, doctors, body_part_specialty, body_parts, specialties, users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(30) NULL,
  role ENUM('user','doctor','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE specialties (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- Un médecin EST un utilisateur (role = 'doctor') : table de profil 1-1 avec users.
CREATE TABLE doctors (
  user_id INT PRIMARY KEY,
  specialty_id INT NOT NULL,
  city VARCHAR(80) NOT NULL,
  bio TEXT NULL,
  photo VARCHAR(255) NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (specialty_id) REFERENCES specialties(id)
) ENGINE=InnoDB;

CREATE TABLE body_parts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(50) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  summary VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  common_issues TEXT NULL,
  prevention TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_body_part_description CHECK (CHAR_LENGTH(TRIM(description)) >= 20)
) ENGINE=InnoDB;

-- Informations anatomiques d'une zone (organes, os, muscles...) : relation 1-N avec body_parts, utilisée par les JOIN
CREATE TABLE anatomical_info (
  id INT AUTO_INCREMENT PRIMARY KEY,
  body_part_id INT NOT NULL,
  category ENUM('organe','os','muscle','articulation','autre') NOT NULL DEFAULT 'organe',
  name VARCHAR(100) NOT NULL,
  details VARCHAR(255) NOT NULL,
  FOREIGN KEY (body_part_id) REFERENCES body_parts(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Recettes santé liées à une partie du corps (ingrédients et étapes : une ligne = un élément)
CREATE TABLE recipes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  body_part_id INT NOT NULL,
  title VARCHAR(150) NOT NULL,
  benefit VARCHAR(255) NOT NULL,
  prep_minutes SMALLINT NOT NULL DEFAULT 15,
  servings TINYINT NOT NULL DEFAULT 2,
  icon VARCHAR(40) NOT NULL DEFAULT 'bi-cup-hot',
  ingredients TEXT NOT NULL,
  steps TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (body_part_id) REFERENCES body_parts(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Une partie du corps -> les spécialités à consulter (lien "S'informer -> Consulter")
CREATE TABLE body_part_specialty (
  body_part_id INT NOT NULL,
  specialty_id INT NOT NULL,
  PRIMARY KEY (body_part_id, specialty_id),
  FOREIGN KEY (body_part_id) REFERENCES body_parts(id) ON DELETE CASCADE,
  FOREIGN KEY (specialty_id) REFERENCES specialties(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,   -- users.id (n'importe quel utilisateur, médecin inclus)
  doctor_id INT NOT NULL,    -- users.id d'un utilisateur role = 'doctor'
  body_part_id INT NULL,
  scheduled_at DATETIME NOT NULL,
  reason VARCHAR(255) NOT NULL,
  status ENUM('pending','confirmed','cancelled','done') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_doctor_slot (doctor_id, scheduled_at),
  FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES doctors(user_id) ON DELETE CASCADE,
  FOREIGN KEY (body_part_id) REFERENCES body_parts(id) ON DELETE SET NULL
) ENGINE=InnoDB;
