/**
 * Page « Explorer » — comportement côté navigateur.
 *   Étape 1 : choisir une partie du corps (SVG ou pastilles)
 *   Étape 2 : choisir « Recettes » ou « Médecins »
 *   Étape 3 : résultats
 *
 * Source des données (au choix) :
 *   - window.EXPLORE_DATA  → aperçu statique (explore.html + explore-data.js)
 *   - sinon fetch(data-api) → JSON fourni par PHP (?r=explore/data)
 * L'état est gardé dans l'adresse :  #tete   #tete-recipes   #tete-doctors
 */
(function () {
  'use strict';

  const root = document.getElementById('explore-app');
  if (!root) return;

  const cfg = {
    api:     root.dataset.api     || '',
    booking: root.dataset.booking || '',   // ex. index.php?r=appointment/create
    fiche:   root.dataset.fiche   || '',   // ex. index.php?r=body/show
    img:     root.dataset.img     || 'assets/front/img/'
  };
  const $ = (sel) => root.querySelector(sel);
  const esc = (v) => String(v).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const withParams = (base, params) =>
    base + (base.includes('?') ? '&' : '?') + new URLSearchParams(params).toString();
  const demo = () => alert('Aperçu statique : cette fonction existe dans la version PHP.');

  let DATA = { me: null, parts: [] };

  /* ---------- état (adresse) ---------- */
  function readState() {
    const m = location.hash.replace('#', '').match(/^(.*?)(?:-(recipes|doctors))?$/);
    const part = DATA.parts.find((p) => p.slug === m[1]) || null;
    return { part, view: part ? (m[2] || null) : null };
  }
  const link = (slug, view) => '#' + slug + (view ? '-' + view : '');

  /* ---------- morceaux d'HTML ---------- */
  function recipeCard(part, r, i) {
    const id = `recipe-${part.slug}-${i}`;
    return `
      <div class="col-12"><article class="recipe-card">
        <div class="d-flex gap-3">
          <div class="recipe-icon"><i class="bi ${esc(r.icon)}"></i></div>
          <div class="flex-grow-1">
            <h4 class="h5 mb-1">${esc(r.title)}</h4>
            <p class="mb-2">${esc(r.benefit)}</p>
            <div class="recipe-meta">
              <span><i class="bi bi-clock"></i> ${Number(r.min)} min</span>
              <span><i class="bi bi-people"></i> ${Number(r.serv)} pers.</span>
            </div>
            <button class="btn btn-sm text-white mt-3" style="background:var(--accent-color)" type="button"
                    data-bs-toggle="collapse" data-bs-target="#${id}" aria-expanded="false" aria-controls="${id}">Voir la recette</button>
          </div>
        </div>
        <div class="collapse" id="${id}"><div class="row gy-3 recipe-body">
          <div class="col-md-5"><h5 class="h6">Ingrédients</h5><ul class="mb-0">${r.ing.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>
          <div class="col-md-7"><h5 class="h6">Préparation</h5><ol class="mb-0">${r.steps.map((x) => `<li>${esc(x)}</li>`).join('')}</ol></div>
        </div></div>
      </article></div>`;
  }

  function doctorCard(part, d) {
    let action;
    if (DATA.me && Number(DATA.me) === Number(d.id)) {
      action = '<span class="small text-muted">C\'est votre profil.</span>';
    } else if (cfg.booking) {
      const href = withParams(cfg.booking, { doctor: d.id, part: part.id });
      action = `<a class="btn btn-sm text-white" style="background:var(--accent-color)" href="${esc(href)}">Prendre rendez-vous</a>`;
    } else {
      action = '<a class="btn btn-sm text-white" style="background:var(--accent-color)" href="#" data-demo>Prendre rendez-vous</a>';
    }
    return `
      <div class="col-md-6"><div class="doctor-card d-flex flex-column">
        <div class="d-flex gap-3 align-items-center mb-2">
          <img src="${esc(cfg.img + (d.photo || 'doctors/doctors-1.jpg'))}" alt="">
          <div><strong>${esc(d.name)}</strong><br><span class="text-success">${esc(d.spec)}</span><br>
            <small><i class="bi bi-geo-alt"></i> ${esc(d.city)}</small></div>
        </div>
        <p class="small flex-grow-1">${esc(d.bio || '')}</p>
        ${action}
      </div></div>`;
  }

  const emptyBox = (html) => `<div class="explore-empty">${html}</div>`;

  /* ---------- affichage ---------- */
  function render() {
    const { part, view } = readState();
    const step = !part ? 1 : (view ? 3 : 2);

    root.querySelectorAll('#steps li').forEach((li) => {
      const n = Number(li.dataset.s);
      li.classList.toggle('done', step >= n);
      li.classList.toggle('active', step === n);
    });
    root.querySelectorAll('#map a').forEach((a) => {
      a.classList.toggle('current', !!part && a.dataset.part === part.slug);
      a.setAttribute('href', link(a.dataset.part, view));
    });
    $('#chips').innerHTML = DATA.parts.map((p) =>
      `<a role="listitem" class="part-chip ${part && p.slug === part.slug ? 'active' : ''}" href="${link(p.slug, view)}">${esc(p.name)}</a>`).join('');

    if (!part) {
      $('#panel').innerHTML = emptyBox(`<i class="bi bi-person-standing"></i>
        <h2 class="h4">Par où voulez-vous commencer ?</h2>
        <p class="mb-0">Cliquez sur une partie du corps à gauche ou choisissez-en une ci-dessus. Vous pourrez ensuite voir des recettes bonnes pour cette zone ou trouver un médecin spécialisé.</p>`);
      return;
    }

    const ficheLink = cfg.fiche
      ? `<a class="small" href="${esc(withParams(cfg.fiche, { slug: part.slug }))}">Lire la fiche complète <i class="bi bi-arrow-right"></i></a>`
      : '<a class="small" href="#" data-demo>Lire la fiche complète <i class="bi bi-arrow-right"></i></a>';

    let out = `
      <div class="selected-part"><h2 class="h3 mb-1">${esc(part.name)}</h2><p class="mb-0">${esc(part.summary)}</p>${ficheLink}</div>
      <h3 class="h5 mt-4 mb-3">Que voulez-vous voir ?</h3>
      <div class="row g-3 mb-4">
        <div class="col-sm-6"><a class="choice-card ${view === 'recipes' ? 'active' : ''}" href="${link(part.slug, 'recipes')}"><i class="bi bi-cup-hot"></i><strong>Recettes santé</strong><span>Des idées simples à cuisiner pour aider cette zone.</span></a></div>
        <div class="col-sm-6"><a class="choice-card ${view === 'doctors' ? 'active' : ''}" href="${link(part.slug, 'doctors')}"><i class="bi bi-heart-pulse"></i><strong>Médecins</strong><span>Les spécialistes à consulter et la prise de rendez-vous.</span></a></div>
      </div>`;

    if (view === 'recipes') {
      out += `<h3 class="h5 mb-3">Recettes pour : ${esc(part.name)}</h3>`;
      out += part.recipes.length
        ? `<div class="row gy-3">${part.recipes.map((r, i) => recipeCard(part, r, i)).join('')}</div>
           <p class="explore-note"><i class="bi bi-info-circle"></i> Ces recettes soutiennent une bonne hygiène de vie et ne remplacent pas un avis médical.
             Un symptôme persiste ? <a href="${link(part.slug, 'doctors')}">Voir les médecins pour cette zone</a>.</p>`
        : emptyBox('<p class="mb-0">Aucune recette n\'est encore proposée pour cette zone.</p>');
    } else if (view === 'doctors') {
      out += `<h3 class="h5 mb-3">Médecins pour : ${esc(part.name)}</h3>`;
      out += part.doctors.length
        ? `<div class="row gy-4">${part.doctors.map((d) => doctorCard(part, d)).join('')}</div>
           <p class="explore-note"><i class="bi bi-lightbulb"></i> En attendant la consultation, découvrez aussi
             <a href="${link(part.slug, 'recipes')}">des recettes bonnes pour cette zone</a>.</p>`
        : emptyBox('<p class="mb-0">Aucun médecin n\'est encore référencé pour cette partie du corps.</p>');
    }
    $('#panel').innerHTML = out;
  }

  /* ---------- démarrage ---------- */
  function start(data) {
    DATA = data;
    // Seules les zones présentes en base restent cliquables.
    const known = new Set(DATA.parts.map((p) => p.slug));
    root.querySelectorAll('#map a').forEach((a) => { if (!known.has(a.dataset.part)) a.remove(); });
    render();
  }

  root.addEventListener('click', (e) => {
    if (e.target.closest('[data-demo]')) { e.preventDefault(); demo(); }
  });
  window.addEventListener('hashchange', render);

  if (window.EXPLORE_DATA) {
    start(window.EXPLORE_DATA);
  } else if (cfg.api) {
    fetch(cfg.api, { headers: { Accept: 'application/json' } })
      .then((r) => { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(start)
      .catch(() => {
        $('#panel').innerHTML = emptyBox('<p class="mb-0">Impossible de charger les données. Réessayez dans un instant.</p>');
      });
  }
})();
