/* Données d'exemple pour l'aperçu statique (public/explore.html).
   Dans l'application PHP, ces données viennent de ?r=explore/data. */
window.EXPLORE_DATA = {
 "me": null,
 "parts": [
  {
   "id": 1,
   "slug": "tete",
   "name": "Tête",
   "summary": "Cerveau, yeux, oreilles, bouche : le centre de commande.",
   "recipes": [
    {
     "title": "Smoothie vert banane-épinards",
     "benefit": "Riche en magnésium et en potassium, un allié des journées chargées et des maux de tête de fatigue.",
     "min": 5,
     "serv": 1,
     "icon": "bi-cup-straw",
     "ing": [
      "1 banane mûre",
      "1 poignée de jeunes pousses d'épinards",
      "1 c. à soupe d'amandes",
      "250 ml de lait ou de boisson végétale",
      "1 c. à café de miel (facultatif)"
     ],
     "steps": [
      "Rincer les épinards.",
      "Mettre tous les ingrédients dans un blender.",
      "Mixer 1 minute jusqu'à obtenir une texture lisse.",
      "Boire frais, de préférence au petit-déjeuner."
     ]
    },
    {
     "title": "Salade de sardines, noix et citron",
     "benefit": "Source d'oméga-3, ces bonnes graisses contribuent au fonctionnement normal du cerveau.",
     "min": 10,
     "serv": 2,
     "icon": "bi-egg-fried",
     "ing": [
      "1 boîte de sardines à l'huile d'olive",
      "2 poignées de salade verte",
      "6 noix décortiquées",
      "1 citron",
      "1 c. à soupe d'huile d'olive"
     ],
     "steps": [
      "Égoutter les sardines et les émietter grossièrement.",
      "Disposer la salade dans un saladier et ajouter les noix.",
      "Ajouter les sardines, le jus de citron et l'huile d'olive.",
      "Mélanger délicatement et servir aussitôt."
     ]
    }
   ],
   "doctors": [
    {
     "id": 4,
     "name": "Dr Amel Gharbi",
     "spec": "Neurologie",
     "city": "Tunis",
     "bio": "Neurologue, migraines et troubles du sommeil.",
     "photo": "doctors/doctors-1.jpg"
    },
    {
     "id": 8,
     "name": "Dr Nour Haddad",
     "spec": "Médecine générale",
     "city": "Tunis",
     "bio": "Médecin généraliste, suivi de famille.",
     "photo": "doctors/doctors-1.jpg"
    }
   ]
  },
  {
   "id": 2,
   "slug": "cou",
   "name": "Cou et gorge",
   "summary": "Vertèbres cervicales, thyroïde, gorge.",
   "recipes": [
    {
     "title": "Lait d'or au curcuma",
     "benefit": "Une boisson chaude réconfortante, appréciée pour apaiser les tensions et la gorge.",
     "min": 10,
     "serv": 1,
     "icon": "bi-cup-hot",
     "ing": [
      "250 ml de lait ou de boisson végétale",
      "1/2 c. à café de curcuma",
      "1 pincée de poivre noir",
      "1/2 c. à café de cannelle",
      "1 c. à café de miel"
     ],
     "steps": [
      "Chauffer le lait à feu doux sans le faire bouillir.",
      "Ajouter le curcuma, le poivre et la cannelle en fouettant.",
      "Laisser infuser 3 minutes.",
      "Verser dans une tasse et sucrer au miel."
     ]
    },
    {
     "title": "Infusion thym, citron et miel",
     "benefit": "Le thym et le miel sont traditionnellement utilisés pour adoucir les gorges irritées.",
     "min": 10,
     "serv": 2,
     "icon": "bi-flower2",
     "ing": [
      "1 petit bouquet de thym frais",
      "500 ml d'eau",
      "1/2 citron",
      "2 c. à café de miel"
     ],
     "steps": [
      "Porter l'eau à ébullition.",
      "Verser sur le thym et laisser infuser 8 minutes.",
      "Filtrer, ajouter le jus de citron.",
      "Ajouter le miel quand l'infusion a un peu tiédi."
     ]
    }
   ],
   "doctors": [
    {
     "id": 7,
     "name": "Dr Walid Chaouch",
     "spec": "Orthopédie",
     "city": "Sousse",
     "bio": "Douleurs articulaires et sport.",
     "photo": "doctors/doctors-4.jpg"
    },
    {
     "id": 8,
     "name": "Dr Nour Haddad",
     "spec": "Médecine générale",
     "city": "Tunis",
     "bio": "Médecin généraliste, suivi de famille.",
     "photo": "doctors/doctors-1.jpg"
    }
   ]
  },
  {
   "id": 3,
   "slug": "thorax",
   "name": "Thorax",
   "summary": "Cœur et poumons.",
   "recipes": [
    {
     "title": "Soupe de lentilles au cumin",
     "benefit": "Riche en fibres et en protéines végétales, elle s'intègre bien à une alimentation favorable au cœur.",
     "min": 35,
     "serv": 4,
     "icon": "bi-heart-pulse",
     "ing": [
      "200 g de lentilles",
      "1 oignon",
      "2 carottes",
      "2 gousses d'ail",
      "1 c. à café de cumin",
      "1 c. à soupe d'huile d'olive",
      "1 litre d'eau"
     ],
     "steps": [
      "Faire revenir l'oignon et l'ail dans l'huile d'olive.",
      "Ajouter les carottes en rondelles et les lentilles rincées.",
      "Verser l'eau, ajouter le cumin et cuire 25 minutes.",
      "Mixer en partie selon la texture souhaitée."
     ]
    },
    {
     "title": "Porridge pomme-cannelle",
     "benefit": "L'avoine contient des fibres (bêta-glucanes) qui participent au maintien d'un cholestérol normal.",
     "min": 10,
     "serv": 1,
     "icon": "bi-apple",
     "ing": [
      "40 g de flocons d'avoine",
      "200 ml de lait ou d'eau",
      "1 pomme",
      "1/2 c. à café de cannelle",
      "1 c. à café de graines de lin"
     ],
     "steps": [
      "Chauffer le lait avec les flocons 5 minutes en remuant.",
      "Râper la pomme et l'ajouter à mi-cuisson.",
      "Verser dans un bol.",
      "Saupoudrer de cannelle et de graines de lin."
     ]
    }
   ],
   "doctors": [
    {
     "id": 5,
     "name": "Dr Karim Mansour",
     "spec": "Cardiologie",
     "city": "Tunis",
     "bio": "Cardiologue, prévention cardiovasculaire.",
     "photo": "doctors/doctors-2.jpg"
    },
    {
     "id": 8,
     "name": "Dr Nour Haddad",
     "spec": "Médecine générale",
     "city": "Tunis",
     "bio": "Médecin généraliste, suivi de famille.",
     "photo": "doctors/doctors-1.jpg"
    }
   ]
  },
  {
   "id": 4,
   "slug": "abdomen",
   "name": "Abdomen",
   "summary": "Estomac, foie, intestins.",
   "recipes": [
    {
     "title": "Infusion fenouil et menthe",
     "benefit": "Traditionnellement consommée après le repas pour aider à réduire les ballonnements.",
     "min": 10,
     "serv": 2,
     "icon": "bi-cup-hot",
     "ing": [
      "1 c. à café de graines de fenouil",
      "1 petite poignée de menthe fraîche",
      "400 ml d'eau chaude"
     ],
     "steps": [
      "Écraser légèrement les graines de fenouil.",
      "Les placer avec la menthe dans une théière.",
      "Verser l'eau chaude et laisser infuser 7 minutes.",
      "Filtrer et boire tiède après le repas."
     ]
    },
    {
     "title": "Soupe douce carottes et riz",
     "benefit": "Une recette simple et douce pour l'estomac, idéale lors d'une digestion difficile.",
     "min": 30,
     "serv": 3,
     "icon": "bi-basket2",
     "ing": [
      "4 carottes",
      "3 c. à soupe de riz",
      "1 litre d'eau",
      "1 c. à café d'huile d'olive",
      "1 pincée de sel"
     ],
     "steps": [
      "Éplucher et couper les carottes.",
      "Cuire carottes et riz dans l'eau salée 25 minutes.",
      "Mixer jusqu'à obtenir un velouté.",
      "Ajouter un filet d'huile d'olive et servir tiède."
     ]
    }
   ],
   "doctors": [
    {
     "id": 6,
     "name": "Dr Leila Jaziri",
     "spec": "Gastro-entérologie",
     "city": "Ariana",
     "bio": "Digestion, reflux, intestin irritable.",
     "photo": "doctors/doctors-3.jpg"
    },
    {
     "id": 8,
     "name": "Dr Nour Haddad",
     "spec": "Médecine générale",
     "city": "Tunis",
     "bio": "Médecin généraliste, suivi de famille.",
     "photo": "doctors/doctors-1.jpg"
    }
   ]
  },
  {
   "id": 5,
   "slug": "bras",
   "name": "Bras",
   "summary": "Épaules, coudes, muscles.",
   "recipes": [
    {
     "title": "Bol de saumon, quinoa et brocoli",
     "benefit": "Protéines et oméga-3 pour soutenir les muscles et la récupération après l'effort.",
     "min": 25,
     "serv": 2,
     "icon": "bi-egg-fried",
     "ing": [
      "2 pavés de saumon",
      "150 g de quinoa",
      "1 brocoli",
      "1 citron",
      "1 c. à soupe d'huile d'olive"
     ],
     "steps": [
      "Cuire le quinoa 12 minutes dans l'eau bouillante.",
      "Cuire le brocoli à la vapeur 8 minutes.",
      "Cuire le saumon à la poêle 4 minutes de chaque côté.",
      "Assembler dans un bol et arroser de citron."
     ]
    },
    {
     "title": "Smoothie cerise-yaourt",
     "benefit": "Les cerises sont riches en antioxydants, appréciées après une séance de sport.",
     "min": 5,
     "serv": 1,
     "icon": "bi-cup-straw",
     "ing": [
      "1 poignée de cerises dénoyautées",
      "1 yaourt nature",
      "100 ml de lait",
      "1 c. à café de miel"
     ],
     "steps": [
      "Mettre tous les ingrédients dans un blender.",
      "Mixer 1 minute.",
      "Servir bien frais."
     ]
    }
   ],
   "doctors": [
    {
     "id": 7,
     "name": "Dr Walid Chaouch",
     "spec": "Orthopédie",
     "city": "Sousse",
     "bio": "Douleurs articulaires et sport.",
     "photo": "doctors/doctors-4.jpg"
    },
    {
     "id": 8,
     "name": "Dr Nour Haddad",
     "spec": "Médecine générale",
     "city": "Tunis",
     "bio": "Médecin généraliste, suivi de famille.",
     "photo": "doctors/doctors-1.jpg"
    }
   ]
  },
  {
   "id": 6,
   "slug": "mains",
   "name": "Mains et poignets",
   "summary": "Précision, toucher, articulations fines.",
   "recipes": [
    {
     "title": "Salade orange, carotte et amandes",
     "benefit": "La vitamine C participe à la formation du collagène, utile à la peau et aux articulations.",
     "min": 10,
     "serv": 2,
     "icon": "bi-apple",
     "ing": [
      "2 oranges",
      "2 carottes râpées",
      "1 poignée d'amandes",
      "1 c. à soupe d'huile d'olive",
      "1 pincée de cannelle"
     ],
     "steps": [
      "Peler les oranges à vif et les couper en rondelles.",
      "Râper les carottes.",
      "Mélanger avec les amandes concassées.",
      "Assaisonner d'huile d'olive et de cannelle."
     ]
    },
    {
     "title": "Houmous maison",
     "benefit": "Pois chiches riches en protéines et en zinc, avec des crudités à croquer.",
     "min": 10,
     "serv": 4,
     "icon": "bi-basket2",
     "ing": [
      "400 g de pois chiches cuits",
      "2 c. à soupe de tahini",
      "1 citron",
      "1 gousse d'ail",
      "3 c. à soupe d'huile d'olive",
      "1/2 c. à café de cumin"
     ],
     "steps": [
      "Égoutter les pois chiches en gardant un peu de jus.",
      "Mixer avec le tahini, le citron, l'ail et le cumin.",
      "Ajouter l'huile d'olive et un peu de jus pour lisser.",
      "Servir avec des bâtonnets de carotte ou de concombre."
     ]
    }
   ],
   "doctors": [
    {
     "id": 7,
     "name": "Dr Walid Chaouch",
     "spec": "Orthopédie",
     "city": "Sousse",
     "bio": "Douleurs articulaires et sport.",
     "photo": "doctors/doctors-4.jpg"
    }
   ]
  },
  {
   "id": 7,
   "slug": "jambes",
   "name": "Jambes",
   "summary": "Hanches, genoux, cuisses, mollets.",
   "recipes": [
    {
     "title": "Salade betterave, orange et noix",
     "benefit": "La betterave est riche en nitrates naturels, un bon réflexe pour une alimentation favorable à la circulation.",
     "min": 15,
     "serv": 2,
     "icon": "bi-flower2",
     "ing": [
      "2 betteraves cuites",
      "1 orange",
      "6 noix",
      "1 c. à soupe d'huile d'olive",
      "1 c. à café de vinaigre de cidre"
     ],
     "steps": [
      "Couper les betteraves en dés.",
      "Peler l'orange et la couper en quartiers.",
      "Mélanger avec les noix.",
      "Assaisonner avec l'huile et le vinaigre."
     ]
    },
    {
     "title": "Smoothie dattes et banane",
     "benefit": "Potassium et magnésium : un en-cas apprécié pour limiter les crampes après l'effort.",
     "min": 5,
     "serv": 1,
     "icon": "bi-cup-straw",
     "ing": [
      "1 banane",
      "3 dattes dénoyautées",
      "250 ml de lait",
      "1 c. à café de graines de chia"
     ],
     "steps": [
      "Mettre tous les ingrédients dans un blender.",
      "Mixer 1 minute.",
      "Laisser reposer 2 minutes pour que le chia gonfle, puis boire."
     ]
    }
   ],
   "doctors": [
    {
     "id": 7,
     "name": "Dr Walid Chaouch",
     "spec": "Orthopédie",
     "city": "Sousse",
     "bio": "Douleurs articulaires et sport.",
     "photo": "doctors/doctors-4.jpg"
    },
    {
     "id": 8,
     "name": "Dr Nour Haddad",
     "spec": "Médecine générale",
     "city": "Tunis",
     "bio": "Médecin généraliste, suivi de famille.",
     "photo": "doctors/doctors-1.jpg"
    }
   ]
  },
  {
   "id": 8,
   "slug": "pieds",
   "name": "Pieds",
   "summary": "Voûte plantaire, chevilles, orteils.",
   "recipes": [
    {
     "title": "Omelette aux épinards et fromage",
     "benefit": "Œufs et fromage apportent protéines, calcium et vitamine D, utiles à des os solides.",
     "min": 10,
     "serv": 1,
     "icon": "bi-egg-fried",
     "ing": [
      "2 œufs",
      "1 poignée d'épinards",
      "30 g de fromage râpé",
      "1 c. à café d'huile d'olive",
      "Sel et poivre"
     ],
     "steps": [
      "Faire tomber les épinards 2 minutes à la poêle.",
      "Battre les œufs, saler, poivrer et verser sur les épinards.",
      "Ajouter le fromage et cuire 3 minutes.",
      "Replier et servir chaud."
     ]
    },
    {
     "title": "Bol yaourt, kiwi et graines de chia",
     "benefit": "Vitamine C et calcium : un petit-déjeuner simple pour les os et les tissus.",
     "min": 5,
     "serv": 1,
     "icon": "bi-apple",
     "ing": [
      "1 yaourt nature",
      "1 kiwi",
      "1 c. à café de graines de chia",
      "1 c. à café de miel"
     ],
     "steps": [
      "Verser le yaourt dans un bol.",
      "Ajouter le kiwi en dés et les graines de chia.",
      "Terminer avec un filet de miel."
     ]
    }
   ],
   "doctors": [
    {
     "id": 7,
     "name": "Dr Walid Chaouch",
     "spec": "Orthopédie",
     "city": "Sousse",
     "bio": "Douleurs articulaires et sport.",
     "photo": "doctors/doctors-4.jpg"
    }
   ]
  }
 ]
};
