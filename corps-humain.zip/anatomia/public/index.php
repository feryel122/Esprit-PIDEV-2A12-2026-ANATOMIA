<?php
// Front controller : index.php?r=<controller>/<action>  (ou admin/<controller>/<action>)
declare(strict_types=1);
session_start();
$app = __DIR__ . '/../app';
require "$app/core/helpers.php";
foreach (['Database', 'Auth', 'Controller'] as $c) require "$app/core/$c.php";
foreach (glob("$app/models/*.php") as $m) require $m;

$parts = array_values(array_filter(explode('/', $_GET['r'] ?? 'body/index')));
$admin = ($parts[0] ?? '') === 'admin';
if ($admin) array_shift($parts);
$ctrl   = $parts[0] ?? 'body';
$action = $parts[1] ?? 'index';

$class = ($admin ? 'Admin' : '') . ucfirst(preg_replace('/\W/', '', $ctrl)) . 'Controller';
$file  = "$app/controllers/" . ($admin ? 'admin/' : '') . "$class.php";
$method = preg_replace('/\W/', '', $action);

if (!is_file($file)) { http_response_code(404); exit('Page introuvable.'); }
require $file;
if (!method_exists($class, $method)) { http_response_code(404); exit('Page introuvable.'); }
(new $class())->$method();
