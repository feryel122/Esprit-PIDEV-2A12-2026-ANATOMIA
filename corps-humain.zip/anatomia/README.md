# Anatomia — module « Corps humain » + Rendez-vous

PHP MVC (sans framework) · Front Office = **MediLab** · Back Office = **AdminLTE 4** · MySQL/MariaDB.

## Installation (XAMPP / WAMP)
1. Copier le dossier dans `htdocs`, démarrer Apache + MySQL.
2. Vérifier `app/config.php` (hôte, utilisateur, mot de passe MySQL).
3. Créer les tables et les données de démo : `php database/install.php`
4. Ouvrir `http://localhost/anatomia/public/` (ou `php -S localhost:8000 -t public`).

| Rôle | Email | Mot de passe |
|---|---|---|
| Admin | admin@anatomia.tn | admin123 |
| Patient | sana@anatomia.tn | user123 |
| Médecin | amel@anatomia.tn (aussi karim@, leila@, walid@, nour@) | doctor123 |

## Architecture MVC
- `public/index.php` : contrôleur frontal, routes `?r=controller/action` (`?r=admin/...` pour le back office).
- `app/models` : `User`, `BodyPart`, `Appointment` (requêtes PDO préparées).
- `app/controllers` : `BodyController`, `AppointmentController`, `AuthController` ; `controllers/admin/*` pour le back office.
- `app/views/layouts/front.php` (MediLab) et `back.php` (AdminLTE) : les templates ne sont intégrés qu'à ces deux endroits, toutes les pages en héritent.
- `public/assets/front` (MediLab) et `public/assets/back` (AdminLTE).

## Fonctionnalités
- **Corps humain** : schéma SVG cliquable → fiche de la partie (rôle, petits maux, bons réflexes) → médecins des spécialités concernées.
- **Rendez-vous** : un utilisateur connecté réserve chez un médecin (créneau libre, lun–sam 8 h–18 h, pas d'auto-réservation), consulte et annule ses demandes.
- **Les médecins sont des utilisateurs** : `users.role = 'doctor'` + profil 1-1 dans `doctors`. Un médecin se connecte, voit les rendez-vous reçus dans le back office (confirmer / annuler / terminer) **et** peut lui-même prendre rendez-vous chez un confrère.
- **Admin** : voit tous les rendez-vous du site, gère les fiches « parties du corps » (CRUD + spécialités liées).
- Sécurité : mots de passe hachés, requêtes préparées, échappement des sorties, jeton CSRF sur tous les POST, contrôle des rôles.

## Diagrammes
`docs/usecase.puml` et `docs/class.puml` (PlantUML — à coller sur plantuml.com ou dans VS Code).
