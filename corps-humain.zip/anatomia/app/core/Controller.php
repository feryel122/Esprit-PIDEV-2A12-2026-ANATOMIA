<?php
abstract class Controller {
    /** Rend une vue dans un layout : 'front' (MediLab) ou 'back' (AdminLTE). */
    protected function render(string $view, array $data = [], string $layout = 'front'): void {
        extract($data);
        $flash = flash();
        $user  = Auth::user();
        ob_start();
        require __DIR__ . "/../views/$view.php";
        $content = ob_get_clean();
        require __DIR__ . "/../views/layouts/$layout.php";
    }
    protected function redirect(string $route, array $params = []): never {
        header('Location: ' . url($route, $params)); exit;
    }
    protected function requireLogin(): array {
        $u = Auth::user();
        if (!$u) { flash('Connectez-vous pour continuer.', 'warning'); $this->redirect('auth/login'); }
        return $u;
    }
    protected function requireRole(string ...$roles): array {
        $u = $this->requireLogin();
        if (!in_array($u['role'], $roles, true)) { http_response_code(403); exit('Accès refusé.'); }
        return $u;
    }
    protected function checkCsrf(): void {
        if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['_csrf'] ?? '')) {
            http_response_code(419); exit('Session expirée, rechargez la page.');
        }
    }
    protected function isPost(): bool { return $_SERVER['REQUEST_METHOD'] === 'POST'; }
}
