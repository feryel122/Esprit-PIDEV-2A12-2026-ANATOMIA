<?php
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function url(string $route = 'body/index', array $params = []): string {
    $q = http_build_query(['r' => $route] + $params);
    return 'index.php?' . $q;
}
function front_asset(string $p): string { return 'assets/front/' . ltrim($p, '/'); }
function back_asset(string $p): string  { return 'assets/back/' . ltrim($p, '/'); }

function flash(?string $msg = null, string $type = 'success') {
    if ($msg !== null) { $_SESSION['flash'] = ['msg' => $msg, 'type' => $type]; return null; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}
function csrf_token(): string {
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(16));
}
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
function status_label(string $s): array {
    return [
        'pending'   => ['En attente', 'warning'],
        'confirmed' => ['Confirmé',   'success'],
        'cancelled' => ['Annulé',     'danger'],
        'done'      => ['Terminé',    'secondary'],
    ][$s] ?? [$s, 'light'];
}

/** Coupe proprement une chaîne UTF-8 (sans dépendre de mbstring). */
function str_limit(string $s, int $max): string {
    return preg_match('/^.{0,' . $max . '}/us', $s, $m) ? $m[0] : substr($s, 0, $max);
}
