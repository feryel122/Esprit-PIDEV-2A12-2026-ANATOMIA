<?php $title = $user['role'] === 'admin' ? 'Tous les rendez-vous du site' : 'Mes rendez-vous (patients)'; ?>
<div class="mb-3 btn-group">
  <?php foreach ([null => 'Tous', 'pending' => 'En attente', 'confirmed' => 'Confirmés', 'done' => 'Terminés', 'cancelled' => 'Annulés'] as $k => $l): ?>
    <a class="btn btn-sm <?= $status === ($k ?: null) ? 'btn-primary' : 'btn-outline-primary' ?>"
       href="<?= url('admin/appointments/index', $k ? ['status' => $k] : []) ?>"><?= $l ?></a>
  <?php endforeach; ?>
</div>
<div class="card"><div class="card-body p-0 table-responsive">
  <table class="table table-hover align-middle mb-0">
    <thead><tr><th>#</th><th>Date</th><th>Patient</th><?php if ($user['role'] === 'admin'): ?><th>Médecin</th><?php endif; ?><th>Zone</th><th>Motif</th><th>Statut</th><th class="text-end">Actions</th></tr></thead>
    <tbody>
    <?php foreach ($appointments as $a): [$lbl, $cls] = status_label($a['status']); ?>
      <tr>
        <td><?= (int)$a['id'] ?></td>
        <td><?= e(date('d/m/Y H:i', strtotime($a['scheduled_at']))) ?></td>
        <td><?= e($a['patient_name']) ?><br><small class="text-secondary"><?= e($a['patient_phone'] ?: $a['patient_email']) ?></small></td>
        <?php if ($user['role'] === 'admin'): ?><td><?= e($a['doctor_name']) ?><br><small class="text-secondary"><?= e($a['specialty']) ?></small></td><?php endif; ?>
        <td><?= e($a['body_part'] ?? '—') ?></td>
        <td><?= e($a['reason']) ?></td>
        <td><span class="badge text-bg-<?= $cls ?>"><?= $lbl ?></span></td>
        <td class="text-end">
          <form method="post" action="<?= url('admin/appointments/status') ?>" class="d-inline-flex gap-1">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <?php if ($a['status'] === 'pending'): ?><button name="status" value="confirmed" class="btn btn-sm btn-success">Confirmer</button><?php endif; ?>
            <?php if ($a['status'] === 'confirmed'): ?><button name="status" value="done" class="btn btn-sm btn-secondary">Terminé</button><?php endif; ?>
            <?php if (in_array($a['status'], ['pending', 'confirmed'], true)): ?><button name="status" value="cancelled" class="btn btn-sm btn-outline-danger">Annuler</button><?php endif; ?>
          </form>
        </td>
      </tr>
    <?php endforeach; if (!$appointments): ?>
      <tr><td colspan="8" class="text-center text-secondary py-4">Aucun rendez-vous.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div></div>
