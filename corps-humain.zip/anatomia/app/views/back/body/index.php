<?php $title = 'Parties du corps'; ?>
<div class="card">
  <div class="card-header"><h3 class="card-title">Fiches « Corps humain »</h3>
    <div class="card-tools"><a href="<?= url('admin/body/create') ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Ajouter</a></div></div>
  <div class="card-body p-0 table-responsive">
    <table class="table table-striped align-middle mb-0">
      <thead><tr><th>#</th><th>Nom</th><th>Slug</th><th>Résumé</th><th class="text-end">Actions</th></tr></thead>
      <tbody>
      <?php foreach ($parts as $p): ?>
        <tr><td><?= (int)$p['id'] ?></td><td><?= e($p['name']) ?></td><td><code><?= e($p['slug']) ?></code></td><td><?= e($p['summary']) ?></td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-primary" href="<?= url('admin/body/edit', ['id' => $p['id']]) ?>">Modifier</a>
            <form method="post" action="<?= url('admin/body/delete') ?>" class="d-inline" onsubmit="return confirm('Supprimer cette fiche ?')">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn btn-sm btn-outline-danger">Supprimer</button></form>
          </td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
