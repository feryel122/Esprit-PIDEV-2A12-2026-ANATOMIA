<?php $title = !empty($part['id']) ? 'Modifier : ' . ($part['name'] ?? '') : 'Nouvelle partie du corps'; $v = fn($k) => e($old[$k] ?? ''); ?>
<?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" action="<?= url('admin/body/save') ?>" class="card">
  <div class="card-body">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($part['id'] ?? 0) ?>">
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Nom</label><input name="name" class="form-control" value="<?= $v('name') ?>" required></div>
      <div class="col-md-6 mb-3"><label class="form-label">Slug (zone du schéma : tete, thorax…)</label><input name="slug" class="form-control" value="<?= $v('slug') ?>"></div>
    </div>
    <div class="mb-3"><label class="form-label">Résumé</label><input name="summary" class="form-control" maxlength="255" value="<?= $v('summary') ?>" required></div>
    <div class="mb-3"><label class="form-label">Description</label><textarea name="description" rows="4" class="form-control" required minlength="20" maxlength="5000" placeholder="Au moins 20 caractères"><?= $v('description') ?></textarea></div>
    <div class="mb-3"><label class="form-label">Petits maux fréquents</label><textarea name="common_issues" rows="2" class="form-control"><?= $v('common_issues') ?></textarea></div>
    <div class="mb-3"><label class="form-label">Bons réflexes</label><textarea name="prevention" rows="2" class="form-control"><?= $v('prevention') ?></textarea></div>
    <div class="mb-3"><label class="form-label d-block">Informations anatomiques</label>
      <div id="info-rows">
      <?php foreach (array_values($info) as $i => $r): ?>
        <div class="row g-2 mb-2 info-row">
          <div class="col-md-2"><select name="info[<?= $i ?>][category]" class="form-select">
            <?php foreach (BodyPart::categories() as $k => $lbl): ?><option value="<?= e($k) ?>" <?= ($r['category'] ?? '') === $k ? 'selected' : '' ?>><?= e($lbl) ?></option><?php endforeach; ?></select></div>
          <div class="col-md-3"><input name="info[<?= $i ?>][name]" class="form-control" maxlength="100" placeholder="Nom (ex. Cœur)" value="<?= e($r['name'] ?? '') ?>"></div>
          <div class="col-md-6"><input name="info[<?= $i ?>][details]" class="form-control" maxlength="255" placeholder="Détails" value="<?= e($r['details'] ?? '') ?>"></div>
          <div class="col-md-1"><button type="button" class="btn btn-outline-danger w-100 info-del">&times;</button></div>
        </div>
      <?php endforeach; ?>
      </div>
      <button type="button" id="info-add" class="btn btn-sm btn-outline-primary"><i class="bi bi-plus-lg"></i> Ajouter une information</button>
    </div>
    <div class="mb-3"><label class="form-label d-block">Spécialités à consulter</label>
      <?php foreach ($specialties as $s): ?>
        <div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="specialties[]" id="sp<?= (int)$s['id'] ?>" value="<?= (int)$s['id'] ?>" <?= in_array((int)$s['id'], array_map('intval', $selected), true) ? 'checked' : '' ?>>
          <label class="form-check-label" for="sp<?= (int)$s['id'] ?>"><?= e($s['name']) ?></label></div>
      <?php endforeach; ?></div>
  </div>
  <div class="card-footer"><button class="btn btn-primary">Enregistrer</button> <a class="btn btn-link" href="<?= url('admin/body/index') ?>">Annuler</a></div>
</form>

<template id="info-tpl">
  <div class="row g-2 mb-2 info-row">
    <div class="col-md-2"><select name="info[__I__][category]" class="form-select"><?php foreach (BodyPart::categories() as $k => $lbl): ?><option value="<?= e($k) ?>"><?= e($lbl) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-3"><input name="info[__I__][name]" class="form-control" maxlength="100" placeholder="Nom (ex. Cœur)"></div>
    <div class="col-md-6"><input name="info[__I__][details]" class="form-control" maxlength="255" placeholder="Détails"></div>
    <div class="col-md-1"><button type="button" class="btn btn-outline-danger w-100 info-del">&times;</button></div>
  </div>
</template>
<script>
(function () {
  const box = document.getElementById('info-rows');
  let n = box.querySelectorAll('.info-row').length + 1000;
  document.getElementById('info-add').addEventListener('click', () => {
    const html = document.getElementById('info-tpl').innerHTML.replaceAll('__I__', n++);
    box.insertAdjacentHTML('beforeend', html);
  });
  box.addEventListener('click', e => { if (e.target.closest('.info-del')) e.target.closest('.info-row').remove(); });
})();
</script>
