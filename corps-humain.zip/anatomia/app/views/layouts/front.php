<?php /** Layout FRONT OFFICE — template MediLab */ ?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($title ?? 'Anatomia') ?> — Anatomia</title>
  <link href="<?= front_asset('img/favicon.png') ?>" rel="icon">
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Poppins:wght@300;400;500;600;700&family=Raleway:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="<?= front_asset('vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
  <link href="<?= front_asset('vendor/bootstrap-icons/bootstrap-icons.css') ?>" rel="stylesheet">
  <link href="<?= front_asset('vendor/aos/aos.css') ?>" rel="stylesheet">
  <link href="<?= front_asset('css/main.css') ?>" rel="stylesheet">
  <link href="<?= front_asset('css/anatomia.css') ?>" rel="stylesheet">
</head>
<body class="index-page">

<header id="header" class="header sticky-top">
  <div class="branding d-flex align-items-center">
    <div class="container position-relative d-flex align-items-center justify-content-between">
      <a href="<?= url('body/index') ?>" class="logo d-flex align-items-center me-auto">
        <h1 class="sitename">Anatomia</h1>
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?= url('body/index') ?>">Corps humain</a></li>
          <?php if ($user): ?>
            <li><a href="<?= url('appointment/mine') ?>">Mes rendez-vous</a></li>
            <?php if (in_array($user['role'], ['doctor', 'admin'], true)): ?>
              <li><a href="<?= url('admin/dashboard/index') ?>"><?= $user['role'] === 'admin' ? 'Administration' : 'Espace médecin' ?></a></li>
            <?php endif; ?>
            <li><a href="<?= url('auth/logout') ?>">Déconnexion (<?= e(explode(' ', $user['name'])[0]) ?>)</a></li>
          <?php else: ?>
            <li><a href="<?= url('auth/login') ?>">Connexion</a></li>
            <li><a href="<?= url('auth/register') ?>">Inscription</a></li>
          <?php endif; ?>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
      <a class="cta-btn d-none d-sm-block" href="<?= url('body/index') ?>">Prendre rendez-vous</a>
    </div>
  </div>
</header>

<main class="main">
  <?php if ($flash): ?>
    <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible mb-0 rounded-0 text-center flash-bar" role="alert">
      <?= e($flash['msg']) ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
    </div>
  <?php endif; ?>
  <?= $content ?>
</main>

<footer id="footer" class="footer light-background">
  <div class="container copyright text-center mt-4">
    <p>© Anatomia — Projet intégré. Templates : MediLab (BootstrapMade) &amp; AdminLTE 4.</p>
  </div>
</footer>

<script src="<?= front_asset('vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= front_asset('vendor/aos/aos.js') ?>"></script>
<script src="<?= front_asset('js/main.js') ?>"></script>
</body>
</html>
