<?php /** Layout BACK OFFICE — template AdminLTE 4 */
$route = $_GET['r'] ?? '';
$active = fn(string $p) => str_starts_with($route, $p) ? ' active' : '';
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($title ?? 'Administration') ?> | Anatomia</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@300;400;600;700&display=fallback">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="<?= back_asset('css/adminlte.css') ?>">
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">

  <nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" data-lte-toggle="sidebar" href="#" role="button"><i class="bi bi-list"></i></a></li>
        <li class="nav-item d-none d-md-block"><a href="<?= url('body/index') ?>" class="nav-link">Voir le site</a></li>
      </ul>
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><span class="nav-link"><i class="bi bi-person-circle"></i>
          <?= e($user['name']) ?> <span class="badge text-bg-secondary"><?= e($user['role']) ?></span></span></li>
        <li class="nav-item"><a class="nav-link" href="<?= url('auth/logout') ?>" title="Déconnexion"><i class="bi bi-box-arrow-right"></i></a></li>
      </ul>
    </div>
  </nav>

  <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
      <a href="<?= url('admin/dashboard/index') ?>" class="brand-link">
        <img src="<?= back_asset('img/AdminLTELogo.png') ?>" alt="Logo" class="brand-image opacity-75 shadow">
        <span class="brand-text fw-light">Anatomia</span>
      </a>
    </div>
    <div class="sidebar-wrapper">
      <nav class="mt-2" aria-label="Navigation principale">
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false" id="navigation">
          <li class="nav-item"><a href="<?= url('admin/dashboard/index') ?>" class="nav-link<?= $active('admin/dashboard') ?>">
            <i class="nav-icon bi bi-speedometer2"></i><p>Tableau de bord</p></a></li>
          <li class="nav-item"><a href="<?= url('admin/appointments/index') ?>" class="nav-link<?= $active('admin/appointments') ?>">
            <i class="nav-icon bi bi-calendar-check"></i><p><?= $user['role'] === 'admin' ? 'Tous les rendez-vous' : 'Mes rendez-vous' ?></p></a></li>
          <?php if ($user['role'] === 'admin'): ?>
          <li class="nav-header">CORPS HUMAIN</li>
          <li class="nav-item"><a href="<?= url('admin/body/index') ?>" class="nav-link<?= $active('admin/body') ?>">
            <i class="nav-icon bi bi-person-standing"></i><p>Parties du corps</p></a></li>
          <?php endif; ?>
        </ul>
      </nav>
    </div>
  </aside>

  <main class="app-main">
    <div class="app-content-header"><div class="container-fluid">
      <h3 class="mb-0"><?= e($title ?? '') ?></h3>
    </div></div>
    <div class="app-content"><div class="container-fluid">
      <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible" role="alert"><?= e($flash['msg']) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button></div>
      <?php endif; ?>
      <?= $content ?>
    </div></div>
  </main>

  <footer class="app-footer"><strong>Anatomia</strong> — back office (AdminLTE 4).</footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.17.0/browser/overlayscrollbars.browser.es6.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.9/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
<script src="<?= back_asset('js/adminlte.js') ?>"></script>
</body>
</html>
