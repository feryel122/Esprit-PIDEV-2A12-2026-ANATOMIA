<?php /* Vue : uniquement le squelette HTML. Le comportement est dans assets/front/js/explore.js, le style dans css/explore.css. */ ?>
<div id="explore-app"
     data-api="<?= e(url('explore/data')) ?>"
     data-booking="<?= e(url('appointment/create')) ?>"
     data-fiche="<?= e(url('body/show')) ?>"
     data-img="<?= e(front_asset('img/')) ?>">

  <section class="page-head">
    <div class="container">
      <h1>Prenez soin de chaque partie du corps</h1>
      <p>Choisissez une zone, puis décidez : une recette qui aide la santé de cette zone, ou un médecin à consulter.</p>
      <ol class="explore-steps" id="steps" aria-label="Étapes">
        <li data-s="1"><span>1</span> Choisir une zone</li>
        <li data-s="2"><span>2</span> Recette ou médecin</li>
        <li data-s="3"><span>3</span> Résultats</li>
      </ol>
    </div>
  </section>

  <section class="pb-5">
    <div class="container">
      <div class="row gy-4 align-items-start">

        <div class="col-lg-4">
          <div class="explore-map-wrap">
            <svg class="body-map" id="map" viewBox="0 0 240 500" role="img" aria-label="Schéma du corps humain cliquable">
          <a href="#tete" data-part="tete" aria-label="Tête"><title>Tête</title><circle class="zone" cx="120" cy="52" r="34"/></a>
          <a href="#cou" data-part="cou" aria-label="Cou et gorge"><title>Cou et gorge</title><rect class="zone" x="105" y="84" width="30" height="22" rx="6"/></a>
          <a href="#thorax" data-part="thorax" aria-label="Thorax"><title>Thorax</title><rect class="zone" x="72" y="108" width="96" height="86" rx="26"/></a>
          <a href="#abdomen" data-part="abdomen" aria-label="Abdomen"><title>Abdomen</title><rect class="zone" x="78" y="196" width="84" height="76" rx="22"/></a>
          <a href="#bras" data-part="bras" aria-label="Bras"><title>Bras</title><rect class="zone" x="28" y="112" width="34" height="150" rx="17"/><rect class="zone" x="178" y="112" width="34" height="150" rx="17"/></a>
          <a href="#mains" data-part="mains" aria-label="Mains et poignets"><title>Mains et poignets</title><circle class="zone" cx="45" cy="282" r="17"/><circle class="zone" cx="195" cy="282" r="17"/></a>
          <a href="#jambes" data-part="jambes" aria-label="Jambes"><title>Jambes</title><rect class="zone" x="80" y="278" width="36" height="170" rx="16"/><rect class="zone" x="124" y="278" width="36" height="170" rx="16"/></a>
          <a href="#pieds" data-part="pieds" aria-label="Pieds"><title>Pieds</title><ellipse class="zone" cx="94" cy="472" rx="24" ry="13"/><ellipse class="zone" cx="146" cy="472" rx="24" ry="13"/></a>
            </svg>
            <p class="text-center small text-muted mt-2 mb-0"><i class="bi bi-hand-index"></i> Touchez une zone du corps</p>
          </div>
        </div>

        <div class="col-lg-8">
          <div class="part-chips" id="chips" role="list"></div>
          <div id="panel"><p class="text-muted">Chargement…</p></div>
        </div>

      </div>
    </div>
  </section>

</div>
