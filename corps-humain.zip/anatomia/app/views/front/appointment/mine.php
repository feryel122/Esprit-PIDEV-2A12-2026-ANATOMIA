<?php $title = 'Mes rendez-vous'; ?>
<section class="page-head"><div class="container"><h1>Mes rendez-vous</h1></div></section>
<section class="pb-5"><div class="container">
  <?php if (!$appointments): ?>
    <p>Vous n'avez pas encore de rendez-vous. <a href="<?= url('body/index') ?>">Choisissez une partie du corps</a> pour trouver un médecin.</p>
  <?php else: ?>
  <div class="table-responsive bg-white rounded-4 border p-2">
    <table class="table align-middle mb-0">
      <thead><tr><th>Date</th><th>Médecin</th><th>Zone</th><th>Motif</th><th>Statut</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($appointments as $a): [$lbl, $cls] = status_label($a['status']); ?>
        <tr>
          <td><?= e(date('d/m/Y H:i', strtotime($a['scheduled_at']))) ?></td>
          <td><?= e($a['doctor_name']) ?><br><small class="text-muted"><?= e($a['specialty']) ?></small></td>
          <td><?= e($a['body_part'] ?? '—') ?></td>
          <td><?= e($a['reason']) ?></td>
          <td><span class="badge text-bg-<?= $cls ?>"><?= $lbl ?></span></td>
          <td class="text-end">
            <?php if (in_array($a['status'], ['pending', 'confirmed'], true)): ?>
              <form method="post" action="<?= url('appointment/cancel') ?>" onsubmit="return confirm('Annuler ce rendez-vous ?')">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                <button class="btn btn-sm btn-outline-danger">Annuler</button></form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div></section>
