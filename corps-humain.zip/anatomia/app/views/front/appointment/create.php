<?php $title = 'Prendre rendez-vous'; ?>
<section class="page-head"><div class="container">
  <h1>Rendez-vous avec <?= e($doctor['name']) ?></h1>
  <p><?= e($doctor['specialty']) ?> — <?= e($doctor['city']) ?>. Consultations du lundi au samedi, de 8 h à 18 h.</p>
</div></section>
<section class="pb-5"><div class="container"><div class="row"><div class="col-lg-7">
  <?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
  <form method="post" action="<?= url('appointment/store') ?>" class="bg-white p-4 rounded-4 border">
    <?= csrf_field() ?>
    <input type="hidden" name="doctor_id" value="<?= (int)$doctor['id'] ?>">
    <input type="hidden" name="body_part_id" value="<?= (int)($part['id'] ?? 0) ?>">
    <?php if ($part): ?><p class="mb-3">Zone concernée : <strong><?= e($part['name']) ?></strong></p><?php endif; ?>
    <div class="mb-3"><label class="form-label" for="scheduled_at">Date et heure</label>
      <input type="datetime-local" class="form-control" id="scheduled_at" name="scheduled_at" step="1800" required
             min="<?= date('Y-m-d\TH:i', time() + 3600) ?>" value="<?= e($old['scheduled_at'] ?? '') ?>"></div>
    <div class="mb-3"><label class="form-label" for="reason">Motif de la consultation</label>
      <textarea class="form-control" id="reason" name="reason" rows="3" maxlength="255" required><?= e($old['reason'] ?? '') ?></textarea></div>
    <button class="btn text-white" style="background:var(--accent-color)">Envoyer la demande</button>
  </form>
</div></div></div></section>
