<?php
class BodyController extends Controller {
    /** Étape 1 « Cliquer » : le corps humain interactif. */
    public function index(): void {
        $parts = BodyPart::all();
        $this->render('front/body/index', compact('parts'));
    }
    /** Étapes 2 et 3 « S'informer » puis « Consulter » : fiche + médecins adaptés. */
    public function show(): void {
        $part = BodyPart::findBySlug($_GET['slug'] ?? '');
        if (!$part) { http_response_code(404); exit('Partie du corps introuvable.'); }
        $doctors = User::doctorsForBodyPart((int)$part['id']);
        $this->render('front/body/show', compact('part', 'doctors'));
    }
}
