<?php
class ExploreController extends Controller {
    /** Page « Explorer » : squelette HTML. Style et comportement sont dans explore.css / explore.js. */
    public function index(): void {
        $styles  = ['css/explore.css'];
        $scripts = ['js/explore.js'];
        $this->render('front/explore/index', compact('styles', 'scripts'));
    }

    /** API JSON lue par explore.js : parties du corps + recettes + médecins. */
    public function data(): void {
        $me = Auth::user();
        $parts = [];
        foreach (BodyPart::all() as $p) {
            $id = (int)$p['id'];
            $parts[] = [
                'id'      => $id,
                'slug'    => $p['slug'],
                'name'    => $p['name'],
                'summary' => $p['summary'],
                'recipes' => array_map(fn($r) => [
                    'title'   => $r['title'],
                    'benefit' => $r['benefit'],
                    'min'     => (int)$r['prep_minutes'],
                    'serv'    => (int)$r['servings'],
                    'icon'    => $r['icon'],
                    'ing'     => $r['ingredients'],
                    'steps'   => $r['steps'],
                ], Recipe::forBodyPart($id)),
                'doctors' => array_map(fn($d) => [
                    'id'    => (int)$d['id'],
                    'name'  => $d['name'],
                    'spec'  => $d['specialty'],
                    'city'  => $d['city'],
                    'bio'   => $d['bio'],
                    'photo' => $d['photo'] ?: 'doctors/doctors-1.jpg',
                ], User::doctorsForBodyPart($id)),
            ];
        }
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode(['me' => $me ? (int)$me['id'] : null, 'parts' => $parts], JSON_UNESCAPED_UNICODE);
    }
}
