<?php
class AdminBodyController extends Controller {
    public function index(): void {
        $this->requireRole('admin');
        $parts = BodyPart::allWithInfoCount();
        $this->render('back/body/index', compact('parts'), 'back');
    }
    public function create(): void {
        $this->requireRole('admin');
        $this->form(null, [], [], [], []);
    }
    public function edit(): void {
        $this->requireRole('admin');
        $p = BodyPart::find((int)($_GET['id'] ?? 0)) ?? exit('Introuvable.');
        $this->form($p, $p, BodyPart::specialtyIds((int)$p['id']), [], BodyPart::anatomy((int)$p['id']));
    }
    public function save(): void {
        $this->requireRole('admin');
        if (!$this->isPost()) $this->redirect('admin/body/index');
        $this->checkCsrf();
        $id = (int)($_POST['id'] ?? 0) ?: null;
        $d = [];
        foreach (['slug', 'name', 'summary', 'description', 'common_issues', 'prevention'] as $k) $d[$k] = trim($_POST[$k] ?? '');
        $d['slug'] = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $d['slug'] ?: $d['name']));
        $errors = [];
        if ($d['name'] === '' || $d['summary'] === '') $errors[] = 'Nom et résumé sont obligatoires.';
        // Règle métier : chaque zone doit avoir une description valide
        if ($d['description'] === '') $errors[] = 'La description est obligatoire.';
        elseif (str_len($d['description']) < 20) $errors[] = 'La description doit contenir au moins 20 caractères.';
        elseif (!preg_match('/\p{L}{3,}/u', $d['description'])) $errors[] = 'La description doit contenir du texte lisible.';
        elseif (str_len($d['description']) > 5000) $errors[] = 'La description est trop longue (5000 caractères max).';
        // Informations anatomiques : lignes (catégorie, nom, détails) — les lignes vides sont ignorées
        $info = [];
        $cats = array_keys(BodyPart::categories());
        foreach (($_POST['info'] ?? []) as $r) {
            $n = trim($r['name'] ?? ''); $t = trim($r['details'] ?? ''); $c = $r['category'] ?? 'autre';
            if ($n === '' && $t === '') continue;
            if ($n === '' || $t === '') { $errors[] = 'Chaque information anatomique doit avoir un nom et des détails.'; break; }
            $info[] = ['category' => in_array($c, $cats, true) ? $c : 'autre', 'name' => str_limit($n, 100), 'details' => str_limit($t, 255)];
        }
        $dup = Database::one('SELECT id FROM body_parts WHERE slug=? AND id<>?', [$d['slug'], $id ?? 0]);
        if ($dup) $errors[] = 'Ce slug existe déjà.';
        $sp = array_map('intval', $_POST['specialties'] ?? []);
        if ($errors) { $this->form($id ? ['id' => $id] + $d : null, $d, $sp, $errors, $info); return; }
        BodyPart::save($id, $d, $sp, $info);
        flash('Partie du corps enregistrée.');
        $this->redirect('admin/body/index');
    }
    public function delete(): void {
        $this->requireRole('admin');
        $this->checkCsrf();
        BodyPart::delete((int)($_POST['id'] ?? 0));
        flash('Partie du corps supprimée.');
        $this->redirect('admin/body/index');
    }
    private function form(?array $part, array $old, array $selected, array $errors, array $info): void {
        $specialties = BodyPart::allSpecialties();
        $this->render('back/body/form', compact('part', 'old', 'selected', 'errors', 'specialties', 'info'), 'back');
    }
}
