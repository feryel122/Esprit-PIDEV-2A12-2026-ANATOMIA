<?php
class AdminAppointmentsController extends Controller {
    /** Le médecin voit SES rendez-vous ; l'admin voit tous les rendez-vous du site. */
    public function index(): void {
        $me = $this->requireRole('doctor', 'admin');
        $status = $_GET['status'] ?? null;
        if (!in_array($status, ['pending', 'confirmed', 'cancelled', 'done'], true)) $status = null;
        $appointments = $me['role'] === 'doctor' ? Appointment::forDoctor((int)$me['id'], $status) : Appointment::all($status);
        $this->render('back/appointments/index', compact('appointments', 'status'), 'back');
    }
    public function status(): void {
        $me = $this->requireRole('doctor', 'admin');
        $this->checkCsrf();
        $a = Appointment::find((int)($_POST['id'] ?? 0));
        $new = $_POST['status'] ?? '';
        $allowed = ['confirmed', 'cancelled', 'done'];
        if ($a && in_array($new, $allowed, true) && ($me['role'] === 'admin' || (int)$a['doctor_id'] === (int)$me['id'])) {
            Appointment::setStatus((int)$a['id'], $new);
            flash('Rendez-vous mis à jour.');
        }
        $this->redirect('admin/appointments/index');
    }
}
