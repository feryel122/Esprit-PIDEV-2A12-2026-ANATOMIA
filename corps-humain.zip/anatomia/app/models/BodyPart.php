<?php
class BodyPart {
    public static function all(): array { return Database::all('SELECT * FROM body_parts ORDER BY id'); }
    /** JOIN zones + informations anatomiques (LEFT JOIN : une zone sans info reste listée). */
    public static function allWithInfoCount(): array {
        return Database::all('SELECT bp.*, COUNT(ai.id) AS info_count
            FROM body_parts bp LEFT JOIN anatomical_info ai ON ai.body_part_id = bp.id
            GROUP BY bp.id ORDER BY bp.id');
    }
    /** JOIN body_parts + anatomical_info pour une zone donnée (par slug). */
    public static function anatomyBySlug(string $slug): array {
        return Database::all('SELECT ai.id, ai.category, ai.name, ai.details, bp.name AS zone_name
            FROM anatomical_info ai JOIN body_parts bp ON bp.id = ai.body_part_id
            WHERE bp.slug = ? ORDER BY FIELD(ai.category, \'organe\',\'os\',\'articulation\',\'muscle\',\'autre\'), ai.name', [$slug]);
    }
    public static function anatomy(int $id): array {
        return Database::all('SELECT id, category, name, details FROM anatomical_info WHERE body_part_id=? ORDER BY id', [$id]);
    }
    public static function categories(): array { return ['organe' => 'Organe', 'os' => 'Os', 'articulation' => 'Articulation', 'muscle' => 'Muscle', 'autre' => 'Autre']; }
    public static function find(int $id): ?array { return Database::one('SELECT * FROM body_parts WHERE id=?', [$id]); }
    public static function findBySlug(string $s): ?array { return Database::one('SELECT * FROM body_parts WHERE slug=?', [$s]); }
    public static function allSpecialties(): array { return Database::all('SELECT * FROM specialties ORDER BY name'); }
    public static function specialtyIds(int $id): array {
        return array_column(Database::all('SELECT specialty_id FROM body_part_specialty WHERE body_part_id=?', [$id]), 'specialty_id');
    }
    public static function save(?int $id, array $d, array $specialties, array $info = []): int {
        $pdo = Database::pdo(); $pdo->beginTransaction();
        try {
        $p = [$d['slug'], $d['name'], $d['summary'], $d['description'], $d['common_issues'], $d['prevention']];
        if ($id) { Database::run('UPDATE body_parts SET slug=?,name=?,summary=?,description=?,common_issues=?,prevention=? WHERE id=?', [...$p, $id]); }
        else     { $id = Database::insert('INSERT INTO body_parts(slug,name,summary,description,common_issues,prevention) VALUES(?,?,?,?,?,?)', $p); }
        Database::run('DELETE FROM body_part_specialty WHERE body_part_id=?', [$id]);
        foreach ($specialties as $s) Database::run('INSERT INTO body_part_specialty VALUES(?,?)', [$id, (int)$s]);
        Database::run('DELETE FROM anatomical_info WHERE body_part_id=?', [$id]);
        foreach ($info as $r) Database::run('INSERT INTO anatomical_info(body_part_id,category,name,details) VALUES(?,?,?,?)', [$id, $r['category'], $r['name'], $r['details']]);
        $pdo->commit();
        } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
        return $id;
    }
    public static function delete(int $id): void { Database::run('DELETE FROM body_parts WHERE id=?', [$id]); }
}
