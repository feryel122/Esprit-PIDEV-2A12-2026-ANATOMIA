<?php
class Appointment {
    private const SELECT = 'SELECT a.*, p.name AS patient_name, p.email AS patient_email, p.phone AS patient_phone,
            d.name AS doctor_name, s.name AS specialty, b.name AS body_part
        FROM appointments a
        JOIN users p ON p.id=a.patient_id
        JOIN users d ON d.id=a.doctor_id
        JOIN doctors dd ON dd.user_id=a.doctor_id
        JOIN specialties s ON s.id=dd.specialty_id
        LEFT JOIN body_parts b ON b.id=a.body_part_id ';

    public static function find(int $id): ?array { return Database::one(self::SELECT . 'WHERE a.id=?', [$id]); }
    public static function forPatient(int $uid): array { return Database::all(self::SELECT . 'WHERE a.patient_id=? ORDER BY a.scheduled_at DESC', [$uid]); }
    public static function forDoctor(int $uid, ?string $status = null): array {
        return $status
            ? Database::all(self::SELECT . 'WHERE a.doctor_id=? AND a.status=? ORDER BY a.scheduled_at', [$uid, $status])
            : Database::all(self::SELECT . 'WHERE a.doctor_id=? ORDER BY a.scheduled_at', [$uid]);
    }
    public static function all(?string $status = null): array {
        return $status
            ? Database::all(self::SELECT . 'WHERE a.status=? ORDER BY a.scheduled_at', [$status])
            : Database::all(self::SELECT . 'ORDER BY a.scheduled_at');
    }
    public static function isFree(int $doctorId, string $dt): bool {
        return !Database::one("SELECT id FROM appointments WHERE doctor_id=? AND scheduled_at=? AND status<>'cancelled'", [$doctorId, $dt]);
    }
    public static function create(int $patient, int $doctor, ?int $bodyPart, string $dt, string $reason): int {
        Database::run("DELETE FROM appointments WHERE doctor_id=? AND scheduled_at=? AND status='cancelled'", [$doctor, $dt]);
        return Database::insert('INSERT INTO appointments(patient_id,doctor_id,body_part_id,scheduled_at,reason) VALUES(?,?,?,?,?)',
            [$patient, $doctor, $bodyPart, $dt, $reason]);
    }
    public static function setStatus(int $id, string $status): void {
        Database::run('UPDATE appointments SET status=? WHERE id=?', [$status, $id]);
    }
    public static function counts(?int $doctorId = null): array {
        $sql = 'SELECT status, COUNT(*) n FROM appointments' . ($doctorId ? ' WHERE doctor_id=?' : '') . ' GROUP BY status';
        $out = ['pending' => 0, 'confirmed' => 0, 'cancelled' => 0, 'done' => 0];
        foreach (Database::all($sql, $doctorId ? [$doctorId] : []) as $r) $out[$r['status']] = (int)$r['n'];
        return $out;
    }
}
