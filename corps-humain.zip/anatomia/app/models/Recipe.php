<?php
class Recipe {
    /** Recettes santé associées à une partie du corps (ingrédients/étapes déjà découpés en listes). */
    public static function forBodyPart(int $bodyPartId): array {
        $rows = Database::all('SELECT * FROM recipes WHERE body_part_id=? ORDER BY title', [$bodyPartId]);
        foreach ($rows as &$r) {
            $r['ingredients'] = array_values(array_filter(array_map('trim', explode("\n", $r['ingredients']))));
            $r['steps']       = array_values(array_filter(array_map('trim', explode("\n", $r['steps']))));
        }
        return $rows;
    }
}
