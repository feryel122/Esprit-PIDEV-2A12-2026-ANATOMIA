Healthy Map & Services — Feryel Argoubi
Les pages HTML sont préparées. Les fichiers CSS et JavaScript sont volontairement vides.
La carte interactive, les formulaires dynamiques et les traitements nécessitent une intégration ultérieure.
